# VORTEX PLAYER V47 – Liquid Glass Redesign

## Visual redesign

- New midnight / violet visual palette with subtle cyan ambience.
- Floating, blurred Liquid Glass bottom navigation with active-state glow for Library, Favourites and Settings.
- Glass library toolbar and search field.
- Refined folder and video cards with translucent gradients, fine borders and soft shadows.
- Matching glass top and playback-control panels in both the internal player and Android Open-with player.
- Updated translucent control-button surfaces for a consistent visual language.

## Preserved behaviour

- Existing tab actions and selected states.
- Video folders, grid/list view, search, favourites, sorting, multi-select and delete flows.
- Playback gestures, resume hint, speed, fit, rotation, subtitles, audio tracks, screenshots, bookmarks, repeat and sleep timer.
- V46 notification/audio-focus behaviour and Picture-in-Picture integration.
- Existing app data keys, package ID and signing workflow assumptions.

## Version

- App version: `2.3.0`
- Build number: `36`
- Android application ID: `com.vortex.player`
