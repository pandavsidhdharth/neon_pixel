# VORTEX PLAYER V41 — Clean subtitles & animated branding

- Removed subtitle vertical-position controls from the main player, Settings, and external-video player.
- Subtitle captions now remain anchored near the bottom of the video. The old saved position preference is retired.
- Kept subtitle text-size controls only: smaller/larger buttons and a live slider, with changes saved automatically.
- Redesigned the subtitle sheet with compact track rows, clear active-state indicators, a simple Off option, and a separate external SRT/VTT action.
- Simplified external-video subtitle settings to size-only controls and live preview behavior.
- Refined the splash wordmark animation: the existing VORTEX logo reveal now leads into a cleaner animated VORTEX / PLAYER brand lockup. App name and application ID remain unchanged.
- Hidden Videos and hide/unhide behavior were not changed.

Version: 2.0.23+30
Android application ID: com.vortex.player

Build note: Flutter/Dart SDK is not installed in this environment, so flutter analyze, APK build, and physical-device playback testing were not possible. Use the same signing key as the installed app; do not uninstall the current app.
