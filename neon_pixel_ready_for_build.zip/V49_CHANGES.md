# VORTEX PLAYER V49

- **Version:** `2.4.0+38`
- **Android application ID:** `com.vortex.player` (unchanged)
- **Android namespace:** `com.neonpixel.app` (unchanged)

## Complete visual refresh
- Unified the app around an obsidian / ion-cyan / molten-amber palette across Home, library, dialogs, player and splash.
- Replaced the previous ribbon logo with a new Ion-Core orbital V emblem, including a matching Android adaptive launcher foreground vector.
- Reworked splash colors and orbital animation to match the new logo; existing staged reveal and tap-to-skip behavior remain.
- Kept existing playback controls, library actions, PiP, subtitles, resume, audio focus and autoplay behavior intact.

## Upgrade safety
- `applicationId`, namespace and Gradle signing configuration were not changed.
- Version code incremented to 38. Same signing certificate as the installed V48 APK must still be confirmed before installing as an in-place update.

## Validation limits
- Source-level structure and XML checks can be run in this environment. Flutter/Dart/Gradle SDKs are not available here, so APK compilation and device rendering are not certified.
