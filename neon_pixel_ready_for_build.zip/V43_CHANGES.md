# V43 – Playback Resume UX Correction

- Removed all blocking Continue Watching / Resume / Start Over dialogs.
- Videos with saved progress now open and immediately play from the last saved position.
- Added a single-line English hint at the bottom of the player: “Want to start from the beginning?” with a compact “Start over” action.
- Selecting “Start over” seeks to zero while playback continues; otherwise playback continues uninterrupted.
- Hint auto-hides after 10 seconds so it does not obstruct viewing.
- Applied the same behavior to external/open-with video playback and queue selection.
- Version updated to 2.0.25+32; Android applicationId remains com.vortex.player.
