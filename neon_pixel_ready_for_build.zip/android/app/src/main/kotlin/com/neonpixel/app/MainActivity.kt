package com.neonpixel.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
