package com.neonpixel.app

import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : FlutterActivity() {
    private val brightnessChannelName = "vortex_player/brightness"
    private val systemVolumeChannelName = "vortex_player/system_volume"
    private val filesChannelName = "vortex_player/files"
    private val externalChannelName = "vortex_player/external"
    private val audioFocusChannelName = "vortex_player/audio_focus"
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private var pendingExternalVideo: Map<String, String>? = null
    private var preparingExternalTitle: String? = null
    private var externalRequestCounter = 0
    private var externalChannel: MethodChannel? = null
    private var audioFocusChannel: MethodChannel? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS ||
            change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT ||
            change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            mainHandler.post { audioFocusChannel?.invokeMethod("focusLost", null) }
        }
    }
    private var pendingSubtitleResult: MethodChannel.Result? = null
    private val subtitleRequestCode = 48210

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Remove stale temporary files (abandoned Open-with copies and cached video copies)
        // in the background. Anything touched in the last 30 minutes is left alone.
        ioExecutor.execute { cleanStaleCacheFiles() }
        // Allow landscape video to draw into the display-cutout side inset.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val params = window.attributes
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = params
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, brightnessChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getSystemBrightness" -> {
                        val windowBrightness = window.attributes.screenBrightness
                        val brightness = if (windowBrightness >= 0f) windowBrightness else {
                            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
                        }
                        result.success(brightness.toDouble())
                    }
                    "setBrightness" -> {
                        val value = call.argument<Double>("value")
                        if (value == null) result.error("INVALID_ARGUMENT", "Brightness value is required", null)
                        else {
                            val params = window.attributes
                            params.screenBrightness = value.toFloat().coerceIn(0.05f, 1.0f)
                            window.attributes = params
                            result.success(true)
                        }
                    }
                    "resetBrightness" -> {
                        val params = window.attributes
                        params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                        window.attributes = params
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }

        audioFocusChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, audioFocusChannelName)
        audioFocusChannel?.setMethodCallHandler { call, result ->
            val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
            when (call.method) {
                "request" -> {
                    val focusResult = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                                    .build()
                            )
                            .setOnAudioFocusChangeListener(audioFocusListener, mainHandler)
                            .setAcceptsDelayedFocusGain(false)
                            .setWillPauseWhenDucked(true)
                            .build()
                        audioFocusRequest = request
                        audioManager.requestAudioFocus(request)
                    } else {
                        @Suppress("DEPRECATION")
                        audioManager.requestAudioFocus(
                            audioFocusListener,
                            AudioManager.STREAM_MUSIC,
                            AudioManager.AUDIOFOCUS_GAIN
                        )
                    }
                    result.success(focusResult == AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
                }
                "abandon" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                        audioFocusRequest = null
                    } else {
                        @Suppress("DEPRECATION")
                        audioManager.abandonAudioFocus(audioFocusListener)
                    }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, systemVolumeChannelName)
            .setMethodCallHandler { call, result ->
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                val stream = AudioManager.STREAM_MUSIC
                val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
                when (call.method) {
                    "getSystemVolume" -> result.success(audio.getStreamVolume(stream).toDouble() / max.toDouble())
                    "setSystemVolume" -> {
                        val value = call.argument<Double>("value")
                        if (value == null) result.error("INVALID_ARGUMENT", "Volume value is required", null)
                        else {
                            val target = (value.coerceIn(0.0, 1.0) * max).roundToInt().coerceIn(0, max)
                            audio.setStreamVolume(stream, target, 0)
                            result.success(audio.getStreamVolume(stream).toDouble() / max.toDouble())
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, filesChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "pickSubtitleFile" -> {
                        if (pendingSubtitleResult != null) {
                            result.error("PICKER_BUSY", "A subtitle picker is already open", null)
                        } else {
                            pendingSubtitleResult = result
                            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "*/*"
                                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/x-subrip", "text/vtt", "text/plain"))
                            }
                            try {
                                startActivityForResult(intent, subtitleRequestCode)
                            } catch (error: Exception) {
                                pendingSubtitleResult = null
                                result.error("PICKER_FAILED", error.message, null)
                            }
                        }
                    }
                    "saveImage" -> {
                        val bytes = call.argument<ByteArray>("bytes")
                        val name = call.argument<String>("name") ?: "VORTEX_${System.currentTimeMillis()}.jpg"
                        if (bytes == null || bytes.isEmpty()) {
                            result.error("INVALID_ARGUMENT", "Image data is required", null)
                        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                            result.error("UNSUPPORTED", "Saving screenshots needs Android 10 or newer", null)
                        } else {
                            ioExecutor.execute {
                                val saved = try { saveImageToGallery(bytes, name) } catch (_: Exception) { false }
                                mainHandler.post {
                                    if (saved) result.success(true)
                                    else result.error("SAVE_FAILED", "Could not save the screenshot", null)
                                }
                            }
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        externalChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, externalChannelName)
        externalChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "consumePendingExternalVideo" -> {
                    result.success(pendingExternalVideo)
                    pendingExternalVideo = null
                }
                "getPreparingExternalTitle" -> result.success(preparingExternalTitle)
                "deleteExternalCacheFile" -> {
                    val path = call.argument<String>("path")
                    if (path != null) {
                        val file = File(path)
                        if (file.parentFile?.canonicalPath == cacheDir.canonicalPath && file.name.startsWith("video_")) file.delete()
                    }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
        handleIncomingVideoIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingVideoIntent(intent)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == subtitleRequestCode) {
            val result = pendingSubtitleResult
            pendingSubtitleResult = null
            val uri = if (resultCode == RESULT_OK) data?.data else null
            if (uri == null) {
                result?.success(null)
            } else if (queryDisplayName(uri)?.substringAfterLast('.', "")?.lowercase() !in setOf("srt", "vtt")) {
                result?.error("UNSUPPORTED_SUBTITLE", "Choose an .srt or .vtt subtitle file", null)
            } else {
                ioExecutor.execute {
                    val file = try { copyUriToCache(uri, "subtitle") } catch (_: Exception) { null }
                    mainHandler.post {
                        if (file != null) result?.success(file.absolutePath)
                        else result?.error("SUBTITLE_COPY_FAILED", "Could not read the selected subtitle file", null)
                    }
                }
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun handleIncomingVideoIntent(incoming: Intent?) {
        if (incoming == null) return
        val uri: Uri? = when (incoming.action) {
            Intent.ACTION_VIEW -> incoming.data
            Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                if (android.os.Build.VERSION.SDK_INT >= 33) incoming.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else incoming.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                @Suppress("DEPRECATION")
                val streams = if (android.os.Build.VERSION.SDK_INT >= 33)
                    incoming.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else incoming.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                streams?.firstOrNull()
            }
            else -> null
        }
        if (uri == null) return
        val mime = incoming.type ?: contentResolver.getType(uri).orEmpty()
        val name = queryDisplayName(uri).orEmpty()
        val extension = name.substringAfterLast('.', "").lowercase()
        val isVideo = mime.startsWith("video/") || extension in setOf("mp4", "mkv", "avi", "mov", "m4v", "webm", "3gp", "ts", "mpeg", "mpg")
        if (!isVideo) return
        val requestId = ++externalRequestCounter
        val shownName = if (name.isNotEmpty()) name else "video"
        // Large videos take a while to copy, so tell the app right away to show a progress hint.
        preparingExternalTitle = shownName
        externalChannel?.invokeMethod("externalVideoPreparing", mapOf("title" to shownName))
        ioExecutor.execute {
            val file = try { copyUriToCache(uri, "video") } catch (_: Exception) { null }
            mainHandler.post {
                if (requestId != externalRequestCounter) {
                    // A newer Open-with request replaced this one while it was being copied.
                    file?.delete()
                } else {
                    preparingExternalTitle = null
                    if (file != null) {
                        pendingExternalVideo = mapOf("path" to file.absolutePath, "title" to name.ifEmpty { file.name })
                        externalChannel?.invokeMethod("externalVideoAvailable", null)
                    } else {
                        externalChannel?.invokeMethod("externalVideoFailed", null)
                    }
                }
            }
        }
    }

    // Deletes temporary files in the app cache that have not been touched for 30 minutes.
    private fun cleanStaleCacheFiles() {
        try {
            val cutoff = System.currentTimeMillis() - 30L * 60L * 1000L
            cacheDir.listFiles()?.forEach { file ->
                if (file.isFile && file.lastModified() < cutoff) file.delete()
            }
        } catch (_: Exception) { }
    }

    // Stores a screenshot in Pictures/VORTEX. Android 10+ lets an app add its own images
    // to the gallery without any extra storage permission.
    private fun saveImageToGallery(bytes: ByteArray, name: String): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VORTEX")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val output = resolver.openOutputStream(uri) ?: throw IllegalStateException("Unable to open the gallery file")
            output.use { it.write(bytes) }
            val finished = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, finished, null, null)
            true
        } catch (_: Exception) {
            try { resolver.delete(uri, null, null) } catch (_: Exception) { }
            false
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) cursor.getString(0) else uri.lastPathSegment
        } catch (_: Exception) {
            uri.lastPathSegment
        } finally {
            cursor?.close()
        }
    }

    private fun copyUriToCache(uri: Uri, prefix: String): File {
        val originalName = queryDisplayName(uri) ?: "$prefix.bin"
        val safeName = originalName.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(100)
        val destination = File(cacheDir, "${prefix}_${System.currentTimeMillis()}_$safeName")
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Unable to open shared file")
        input.use { source -> destination.outputStream().use { output -> source.copyTo(output) } }
        return destination
    }

    override fun onDestroy() {
        pendingSubtitleResult?.let { it.error("ACTIVITY_DESTROYED", "Activity closed", null) }
        pendingSubtitleResult = null
        try {
            val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                audioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(audioFocusListener)
            }
        } catch (_: Exception) { }
        ioExecutor.shutdown()
        super.onDestroy()
    }
}
