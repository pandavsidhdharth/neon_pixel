package com.neonpixel.app

import android.provider.Settings
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val brightnessChannel = "vortex_player/brightness"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, brightnessChannel)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getSystemBrightness" -> {
                        val brightness = Settings.System.getInt(
                            contentResolver,
                            Settings.System.SCREEN_BRIGHTNESS,
                            128
                        ) / 255.0
                        result.success(brightness)
                    }
                    "setBrightness" -> {
                        val value = call.argument<Double>("value")
                        if (value == null) {
                            result.error("INVALID_ARGUMENT", "Brightness value is required", null)
                        } else {
                            val params = window.attributes
                            params.screenBrightness = value.toFloat().coerceIn(0.05f, 1.0f)
                            window.attributes = params
                            result.success(true)
                        }
                    }
                    "resetBrightness" -> {
                        val params = window.attributes
                        params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                        window.attributes = params
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
