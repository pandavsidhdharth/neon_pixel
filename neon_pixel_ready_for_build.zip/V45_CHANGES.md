# V45 – Fixes, faster playback start, and new player tools

Everything in the app stays English-only.

## Fixes

- **Playback speed menu** – choosing a speed now sticks. The menu used to close when the controls auto-hid, so the pick was lost. Speed labels are tidy (0.75×, 1×, 1.25×).
- **Hold-for-2× gesture** – releasing the long-press returns to the speed you had chosen and no longer overwrites your saved speed.
- **Lock mode** – the system Back button no longer exits the player while the controls are locked; a short message explains how to unlock.
- **Rotate button** – follows the real screen orientation, so it no longer needs a second tap.
- **Home Back button** – closes selection mode, then search, then the open folder, then Favourites, before leaving the app.
- **Refreshing** – pull-to-refresh and the automatic refresh keep the list on screen instead of showing a full-screen spinner. The library also refreshes by itself when you return to the app (if it has been away for 30 seconds or more).
- **Faster library loading** – favourites and recent history are loaded in parallel, and a failed lookup no longer blocks the list.
- **Sharper thumbnails** – grid cards and list tiles request higher-resolution previews.
- **Lighter progress saving** – while playing, only the resume position is saved (every 5 seconds); full statistics are saved when you pause or leave.
- **Open with** – Home shows a “Preparing” banner while a large video is being copied, shows a message if the copy fails, and throws away a copy that a newer request replaced.
- **Open-with player page** – now has the playback speed menu (remembered), an audio-track sheet, auto-hiding controls, and a Back button on the loading/error screens. Its resume key is also more robust.
- **Track names** – audio and subtitle tracks use English names such as “English” or “Hindi” instead of codes like “eng” or “hin”.
- **Intro** – tap anywhere to skip the intro animation; after it fades out, its animations are stopped so they no longer use CPU or battery.
- **Error screen** – gained a “Go back” button.

## Playback start and storage

- Videos are now played straight from shared storage when Android allows it, so playback no longer waits while a multi-gigabyte file is copied into the app cache. If the direct path cannot be read, the app falls back to the previous method automatically.
- Old temporary files in the app cache (older than 30 minutes) are cleaned up in the background at launch, so the cache no longer builds up.

## New features

- **Subtitle delay** – in the subtitle sheet, shift subtitles earlier or later with the − / + buttons (0.5 s per tap, up to ±10 s). Tap the value to reset it to 0.
- **Audio delay** – in the audio sheet, shift the sound earlier or later the same way. Both delays reset for each new video.
- **Save screenshot** – new entry in the player's “more” menu; saves the current frame to Pictures/VORTEX (Android 10 or newer, no extra permission).
- **Sort library** – six orders: Newest, Oldest, Name A-Z, Name Z-A, Longest, Shortest. Available from the toolbar and in Settings; the choice is remembered.
- **Video details** – now also shows Format and Folder, and file sizes above 1 GB are shown in GB.

## Version

- Version updated to `2.1.0+34`.
- Android applicationId remains `com.vortex.player`.

## Validation

- The Android Kotlin file was compiled here against stand-ins for the Android and Flutter classes using Kotlin 2.0.21, and passed.
- The Dart code passed source-level checks (bracket balance, every new identifier defined, a scan for non-English characters, and a line-by-line review of the full change set).
- The Flutter/Dart SDK and a device were not available in this environment, so the real APK compile (GitHub Actions) and on-device behaviour — direct-path playback, screenshot saving and the new menus on the OnePlus Nord 5 — have not been verified here.
