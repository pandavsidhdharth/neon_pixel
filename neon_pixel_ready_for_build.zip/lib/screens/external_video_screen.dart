part of '../main.dart';

class ExternalVideoPage extends StatefulWidget {
  final String path;
  final String title;
  const ExternalVideoPage({super.key, required this.path, required this.title});

  @override
  State<ExternalVideoPage> createState() => _ExternalVideoPageState();
}

class _ExternalVideoPageState extends State<ExternalVideoPage> with WidgetsBindingObserver {
  late final Player _player;
  late final VideoController _controller;
  StreamSubscription<bool>? _completedSubscription;
  Timer? _saveTimer;
  bool _loading = true;
  bool _playing = false;
  bool _controlsVisible = true;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _locked = false;
  double _subtitleScale = 1.25;
  double _doubleTapX = 0;
  int _fit = 0;
  String? _error;

  String get _resumeKey {
    final file = File(widget.path);
    final stableIdentity = '${widget.title.trim().toLowerCase()}|${file.existsSync() ? file.lengthSync() : 0}';
    return 'vortex_external_resume_${Uri.encodeComponent(stableIdentity)}';
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _audioFocusChannel.setMethodCallHandler((call) async {
      if (call.method == 'focusLost' && _player.state.playing) {
        await _player.pause();
        await _saveProgress();
        await _abandonAudioFocus();
      }
    });
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _player = Player();
    _controller = VideoController(_player);
    _player.stream.playing.listen((value) {
      if (mounted) setState(() => _playing = value);
    });
    _player.stream.position.listen((value) {
      if (mounted) setState(() => _position = value);
    });
    _player.stream.duration.listen((value) {
      if (mounted) setState(() => _duration = value);
    });
    unawaited(_open());
  }

  Future<void> _requestAudioFocus() async {
    try { await _audioFocusChannel.invokeMethod<bool>('request'); } catch (_) {}
  }

  Future<void> _abandonAudioFocus() async {
    try { await _audioFocusChannel.invokeMethod<void>('abandon'); } catch (_) {}
  }

  Future<void> _open() async {
    try {
      await _player.open(Media(widget.path), play: false);
      try {
        _duration = await _player.stream.duration
            .firstWhere((value) => value > Duration.zero)
            .timeout(const Duration(seconds: 6));
      } catch (_) {
        _duration = _player.state.duration;
      }
      final prefs = await SharedPreferences.getInstance();
      _subtitleScale = (prefs.getDouble('vortex_subtitle_scale') ?? 1.25).clamp(0.6, 2.5).toDouble();
      await prefs.remove('vortex_subtitle_position'); // Retire the old vertical-position setting.
      final saved = prefs.getInt(_resumeKey) ?? 0;
      final hasSaved = saved > 3000 &&
          (_duration <= Duration.zero || saved < _duration.inMilliseconds - 3000);
      var start = 0;
      if (hasSaved && mounted) {
        final choice = await _showResumePrompt(context, saved);
        if (!mounted) return;
        // X cancels the open-with launch; timeout defaults to the saved position.
        if (choice == null) {
          if (mounted) Navigator.of(context).maybePop();
          return;
        }
        start = choice;
      }
      if (start > 0) await _player.seek(Duration(milliseconds: start));
      await _requestAudioFocus();
      await _player.play();
      if (!mounted) return;
      setState(() { _loading = false; _position = Duration(milliseconds: start); });
      _saveTimer = Timer.periodic(const Duration(seconds: 2), (_) => unawaited(_saveProgress()));
      _completedSubscription = _player.stream.completed.listen((completed) async {
        if (completed && mounted) await _saveProgress(reset: true);
      });
    } catch (e) {
      if (mounted) setState(() { _loading = false; _error = 'Cannot open this video: $e'; });
    }
  }

  Future<void> _saveProgress({bool reset = false}) async {
    try {
      final position = reset ? 0 : _player.state.position.inMilliseconds;
      final duration = _player.state.duration.inMilliseconds;
      final safe = duration > 0 && position >= duration - 3000 ? 0 : position.clamp(0, 1 << 62).toInt();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_resumeKey, safe);
    } catch (_) {}
  }

  Future<void> _loadSubtitle() async {
    try {
      final path = await const MethodChannel('vortex_player/files').invokeMethod<String>('pickSubtitleFile');
      if (path == null || path.isEmpty) return;
      await _player.setSubtitleTrack(SubtitleTrack.uri(Uri.file(path).toString(), title: path.split('/').last));
      if (mounted) _message('Subtitle loaded.');
    } catch (e) {
      if (mounted) _message('Subtitle could not be loaded: $e');
    }
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));
  }


  Future<void> _openSubtitleSettings() async {
    var scale = _subtitleScale;
    Future<void> saveScale(StateSetter setSheetState, double value) async {
      scale = value.clamp(.6, 2.5).toDouble();
      setSheetState(() {});
      if (mounted) setState(() => _subtitleScale = scale);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('vortex_subtitle_scale', scale);
    }

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (sheetContext) => SafeArea(
        child: StatefulBuilder(
          builder: (context, setSheetState) => Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: Container(width: 38, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(20)))),
                const SizedBox(height: 16),
                Row(children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(color: _primary.withValues(alpha: .14), borderRadius: BorderRadius.circular(13)),
                    child: const Icon(Icons.format_size_rounded, color: _softAccent),
                  ),
                  const SizedBox(width: 11),
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Subtitle size', style: TextStyle(color: _white, fontSize: 16, fontWeight: FontWeight.w900)),
                    SizedBox(height: 2),
                    Text('Make captions comfortable to read', style: TextStyle(color: _muted, fontSize: 11)),
                  ])),
                  IconButton(onPressed: () => Navigator.pop(sheetContext), icon: const Icon(Icons.close_rounded, color: _muted)),
                ]),
                const SizedBox(height: 18),
                Row(children: [
                  _subtitleSizeButton(
                    icon: Icons.remove_rounded,
                    tooltip: 'Smaller text',
                    onTap: scale <= .6 ? null : () => unawaited(saveScale(setSheetState, scale - .1)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Slider(
                    value: scale,
                    min: .6,
                    max: 2.5,
                    divisions: 19,
                    activeColor: _primary,
                    inactiveColor: Colors.white12,
                    onChanged: (value) {
                      setSheetState(() => scale = value);
                      if (mounted) setState(() => _subtitleScale = value);
                    },
                    onChangeEnd: (value) async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.setDouble('vortex_subtitle_scale', value);
                    },
                  )),
                  const SizedBox(width: 12),
                  _subtitleSizeButton(
                    icon: Icons.add_rounded,
                    tooltip: 'Larger text',
                    onTap: scale >= 2.5 ? null : () => unawaited(saveScale(setSheetState, scale + .1)),
                  ),
                ]),
                Center(child: Text('${(scale * 100).round()}%', style: const TextStyle(color: _softAccent, fontSize: 12, fontWeight: FontWeight.w900))),
                const SizedBox(height: 8),
                const Text('Changes apply instantly and are saved automatically.', style: TextStyle(color: _muted, fontSize: 10.5)),
                const SizedBox(height: 12),
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(13),
                    onTap: () async {
                      Navigator.pop(sheetContext);
                      await _loadSubtitle();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: .035),
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: Colors.white.withValues(alpha: .07)),
                      ),
                      child: const Row(children: [
                        Icon(Icons.folder_open_rounded, color: _softAccent, size: 19),
                        SizedBox(width: 10),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('Load subtitle file', style: TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w800)),
                          SizedBox(height: 2),
                          Text('SRT or VTT', style: TextStyle(color: _muted, fontSize: 10)),
                        ])),
                        Icon(Icons.chevron_right_rounded, color: _muted, size: 20),
                      ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _subtitleSizeButton({required IconData icon, required String tooltip, required VoidCallback? onTap}) {
    return IconButton(
      tooltip: tooltip,
      onPressed: onTap,
      visualDensity: VisualDensity.compact,
      constraints: const BoxConstraints.tightFor(width: 36, height: 36),
      padding: EdgeInsets.zero,
      style: IconButton.styleFrom(
        backgroundColor: Colors.white.withValues(alpha: .07),
        foregroundColor: onTap == null ? Colors.white24 : _softAccent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
      ),
      icon: Icon(icon, size: 19),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      if (_player.state.playing) unawaited(_player.pause());
      unawaited(_saveProgress());
      unawaited(_abandonAudioFocus());
    }
  }

  Future<void> _togglePlay() async {
    if (_player.state.playing) {
      await _player.pause();
      await _saveProgress();
      await _abandonAudioFocus();
    } else {
      await _requestAudioFocus();
      await _player.play();
    }
  }

  Future<void> _seek(int seconds) async {
    final target = _player.state.position + Duration(seconds: seconds);
    final bounded = target < Duration.zero ? Duration.zero : (target > _duration ? _duration : target);
    await _player.seek(bounded);
    await _saveProgress();
  }

  Future<void> _rotate() async {
    final isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;
    await SystemChrome.setPreferredOrientations(isLandscape
        ? const [DeviceOrientation.portraitUp]
        : const [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _saveTimer?.cancel();
    unawaited(_saveProgress());
    unawaited(_abandonAudioFocus());
    _audioFocusChannel.setMethodCallHandler(null);
    unawaited(const MethodChannel('vortex_player/external').invokeMethod<void>('deleteExternalCacheFile', {'path': widget.path}).catchError((_) {}));
    unawaited(_completedSubscription?.cancel());
    unawaited(_player.dispose());
    SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp, DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope<Object?>(
      canPop: true,
      onPopInvokedWithResult: (didPop, result) { if (didPop) unawaited(_saveProgress()); },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(fit: StackFit.expand, children: [
          if (!_loading && _error == null)
            GestureDetector(
              onTap: () => setState(() => _controlsVisible = !_controlsVisible),
              onDoubleTapDown: (details) => _doubleTapX = details.localPosition.dx,
              onDoubleTap: () => _seek(_doubleTapX < MediaQuery.of(context).size.width / 2 ? -10 : 10),
              child: _fit == 2
                  ? Center(child: AspectRatio(aspectRatio: 16 / 9, child: Video(controller: _controller, controls: NoVideoControls, fit: BoxFit.contain, subtitleViewConfiguration: _vortexSubtitleViewConfiguration(context, scale: _subtitleScale))))
                  : Video(controller: _controller, controls: NoVideoControls, fit: _fit == 1 ? BoxFit.cover : BoxFit.contain, subtitleViewConfiguration: _vortexSubtitleViewConfiguration(context, scale: _subtitleScale)),
            ),
          if (_loading) const Center(child: CircularProgressIndicator(color: _primary)),
          if (_error != null) Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: _white)))),
          if (_controlsVisible && !_loading && _error == null)
            Positioned(left: 0, right: 0, top: 0, child: SafeArea(child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded, color: _white)),
                Expanded(child: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontWeight: FontWeight.w700))),
                IconButton(tooltip: 'Subtitles', onPressed: _openSubtitleSettings, icon: const Icon(Icons.subtitles_rounded, color: _primary)),
                IconButton(onPressed: _rotate, icon: const Icon(Icons.screen_rotation_rounded, color: _primary)),
              ]),
            ))),
          if (_controlsVisible && !_loading && _error == null)
            Positioned(left: 0, right: 0, bottom: 0, child: SafeArea(top: false, child: Container(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
              decoration: BoxDecoration(color: Colors.black.withValues(alpha: .24)),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Row(children: [
                  Text(_formatClock(_position), style: const TextStyle(color: _white, fontSize: 12)),
                  Expanded(child: Slider(
                    value: _position.inMilliseconds.clamp(0, _duration.inMilliseconds > 0 ? _duration.inMilliseconds : 1).toDouble(),
                    max: (_duration.inMilliseconds > 0 ? _duration.inMilliseconds : 1).toDouble(),
                    activeColor: _primary,
                    onChanged: (value) => setState(() => _position = Duration(milliseconds: value.round())),
                    onChangeEnd: (value) async { await _player.seek(Duration(milliseconds: value.round())); await _saveProgress(); },
                  )),
                  Text(_formatClock(_duration), style: const TextStyle(color: _white, fontSize: 12)),
                ]),
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  IconButton(onPressed: () => _seek(-10), icon: const Icon(Icons.replay_10_rounded, color: _white, size: 30)),
                  IconButton(onPressed: _togglePlay, icon: Icon(_playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded, color: _primary, size: 58)),
                  IconButton(onPressed: () => _seek(10), icon: const Icon(Icons.forward_10_rounded, color: _white, size: 30)),
                  IconButton(onPressed: () => setState(() => _fit = (_fit + 1) % 3), icon: const Icon(Icons.fit_screen_rounded, color: _primary)),
                ]),
              ]),
            ))),
        ]),
      ),
    );
  }
}

