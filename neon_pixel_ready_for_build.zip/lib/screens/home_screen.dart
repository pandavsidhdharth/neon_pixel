part of '../main.dart';

class VortexHome extends StatefulWidget {
  const VortexHome({super.key});

  @override
  State<VortexHome> createState() => _VortexHomeState();
}

/// Sorting choices for the video list. The index is saved as vortex_library_sort.
const List<String> _sortLabels = ['Newest', 'Oldest', 'Name A-Z', 'Name Z-A', 'Longest', 'Shortest'];

class _VortexHomeState extends State<VortexHome> with WidgetsBindingObserver {
  List<AssetEntity> _videos = [];
  List<AssetPathEntity> _folders = [];
  AssetPathEntity? _selectedFolder;
  final Set<String> _favorites = {};
  final Set<String> _selectedVideoIds = {};
  final Set<String> _selectedFolderIds = {};
  List<AssetEntity> _favoriteAssets = [];
  List<AssetEntity> _recentlyWatched = [];
  bool _showAllFavorites = false;
  final TextEditingController _searchController = TextEditingController();
  bool _loading = true;
  bool _searchOpen = false;
  bool _favoritesOnly = false;
  bool _grid = true;
  int _sortMode = 0; // Index into _sortLabels.
  DateTime? _lastLibraryLoad;
  String? _preparingExternalTitle; // Set while an "Open with" video is being copied.
  String? _error;
  String _query = '';
  String? _lastWatchedAssetId;
  String _lastWatchedTitle = '';
  int _lastWatchedPositionMs = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _externalChannel.setMethodCallHandler((call) async {
      if (call.method == 'externalVideoAvailable') {
        await _consumePendingExternalVideo();
      } else if (call.method == 'externalVideoPreparing') {
        final arguments = call.arguments;
        final title = (arguments is Map ? arguments['title']?.toString() : null) ?? 'video';
        if (mounted) setState(() => _preparingExternalTitle = title);
      } else if (call.method == 'externalVideoFailed') {
        if (mounted) setState(() => _preparingExternalTitle = null);
        _showMessage('Could not open that video. Please try again.');
      }
    });
    _loadFavorites();
    _loadLibraryPreferences();
    _loadVideos();
    _loadLastWatched();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _consumePendingExternalVideo();
      _checkExternalPreparing();
    });
  }

  // At a cold start the "preparing" message can arrive before the app is listening, so ask once.
  Future<void> _checkExternalPreparing() async {
    try {
      final title = await _externalChannel.invokeMethod<String>('getPreparingExternalTitle');
      if (title != null && title.isNotEmpty && mounted) setState(() => _preparingExternalTitle = title);
    } catch (_) {}
  }


  Future<void> _loadLibraryPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _grid = prefs.getBool('vortex_library_grid') ?? true;
      // Older versions only stored "newest first"; keep honouring that choice until a sort is picked.
      final legacyMode = (prefs.getBool('vortex_library_newest_first') ?? true) ? 0 : 1;
      _sortMode = (prefs.getInt('vortex_library_sort') ?? legacyMode).clamp(0, _sortLabels.length - 1).toInt();
    });
  }

  Future<void> _saveLibraryPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('vortex_library_grid', _grid);
    await prefs.setInt('vortex_library_sort', _sortMode);
    await prefs.setBool('vortex_library_newest_first', _sortMode != 1);
  }


  Future<void> _openSettings() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => VortexSettingsPage(onRefresh: _loadVideos, onAbout: _showAbout)));
    await _loadLibraryPreferences();
  }

  void _toggleVideoSelection(String id) {
    setState(() {
      if (!_selectedVideoIds.add(id)) _selectedVideoIds.remove(id);
    });
  }

  void _selectAllVisible(List<AssetEntity> items) {
    setState(() => _selectedVideoIds
      ..clear()
      ..addAll(items.map((asset) => asset.id)));
  }

  void _toggleFolderSelection(String id) {
    setState(() {
      if (!_selectedFolderIds.add(id)) _selectedFolderIds.remove(id);
    });
  }

  void _selectAllVisibleFolders(List<AssetPathEntity> folders) {
    setState(() => _selectedFolderIds
      ..clear()
      ..addAll(folders.map((folder) => folder.id)));
  }

  Future<void> _deleteSelectedFolders(List<AssetPathEntity> folders) async {
    final selected = folders.where((folder) => _selectedFolderIds.contains(folder.id)).toList();
    if (selected.isEmpty) return;
    final assets = <AssetEntity>[];
    for (final folder in selected) {
      final count = await folder.assetCountAsync;
      assets.addAll(await folder.getAssetListRange(start: 0, end: count));
    }
    final uniqueAssets = {for (final asset in assets) asset.id: asset}.values.toList();
    if (uniqueAssets.isEmpty) {
      setState(() => _selectedFolderIds.clear());
      _showMessage('Selected folders contain no videos.');
      return;
    }
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: _surface2,
        title: Text('Delete ${selected.length} selected folders?', style: const TextStyle(color: _white, fontWeight: FontWeight.w800)),
        content: Text(
          'This will delete ${uniqueAssets.length} videos inside the selected folders. Android may ask for confirmation.',
          style: const TextStyle(color: _muted, fontSize: 13, height: 1.4),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB3263D), foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('DELETE SELECTED'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    try {
      final deletedIds = await PhotoManager.editor.deleteWithIds(uniqueAssets.map((asset) => asset.id).toList());
      await _clearDeletedVideoData(deletedIds);
      if (mounted) setState(() => _selectedFolderIds.clear());
      await _loadVideos();
      await _loadLastWatched();
      await _loadFavorites();
      _showMessage(deletedIds.isEmpty ? 'Android did not approve deleting these videos.' : 'Deleted ${deletedIds.length} videos from selected folders.');
    } catch (e) {
      _showMessage('Could not delete selected folders: $e');
    }
  }

  Future<void> _deleteSelectedVideos(List<AssetEntity> items) async {
    final selected = items.where((asset) => _selectedVideoIds.contains(asset.id)).toList();
    if (selected.isEmpty) return;
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: _surface2,
        title: Text('Delete ${selected.length} selected videos?', style: const TextStyle(color: _white, fontWeight: FontWeight.w800)),
        content: const Text('Selected videos will be sent to Trash where supported. Android may ask for confirmation.', style: TextStyle(color: _muted, fontSize: 13, height: 1.4)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB3263D), foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('DELETE SELECTED'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    try {
      final deletedIds = await PhotoManager.editor.deleteWithIds(selected.map((asset) => asset.id).toList());
      await _clearDeletedVideoData(deletedIds);
      if (mounted) setState(() => _selectedVideoIds.clear());
      await _loadVideos();
      await _loadLastWatched();
      await _loadFavorites();
      _showMessage(deletedIds.isEmpty ? 'Android did not approve deleting the selected videos.' : 'Deleted ${deletedIds.length} selected videos.');
    } catch (e) {
      _showMessage('Could not delete selected videos: $e');
    }
  }

  Future<void> _consumePendingExternalVideo() async {
    try {
      final pending = await _externalChannel.invokeMethod<Map<dynamic, dynamic>>('consumePendingExternalVideo');
      if (pending == null || !mounted) return;
      if (_preparingExternalTitle != null) setState(() => _preparingExternalTitle = null);
      final path = pending['path']?.toString();
      final title = pending['title']?.toString() ?? 'External video';
      if (path != null && path.isNotEmpty) await _openExternalVideo(path, title);
    } catch (_) {}
  }

  Future<void> _openExternalVideo(String path, String title) async {
    if (!mounted) return;
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ExternalVideoPage(path: path, title: title),
    ));
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _searchController.dispose();
    super.dispose();
  }

  // Videos recorded or downloaded while the app was in the background show up on return.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed || !mounted || _loading) return;
    final last = _lastLibraryLoad;
    if (last != null && DateTime.now().difference(last) < const Duration(seconds: 30)) return;
    unawaited(_loadVideos(silent: true));
  }

  Future<void> _loadLastWatched() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    final lastId = prefs.getString('vortex_last_asset_id');
    final position = lastId == null
        ? (prefs.getInt('vortex_last_position_ms') ?? 0)
        : (prefs.getInt('vortex_resume_$lastId') ??
            prefs.getInt('vortex_last_position_ms') ?? 0);
    final ids = prefs.getStringList('vortex_recent_asset_ids') ?? <String>[];
    if (lastId != null && lastId.isNotEmpty) {
      ids.remove(lastId);
      ids.insert(0, lastId);
    }
    final recentIds = ids.take(12).toList();
    final fetched = await Future.wait(recentIds.map((id) => AssetEntity.fromId(id).catchError((_) => null)));
    final recent = <AssetEntity>[];
    for (var i = 0; i < recentIds.length; i++) {
      final asset = fetched[i];
      final savedPosition = prefs.getInt('vortex_resume_${recentIds[i]}') ?? 0;
      if (asset != null && savedPosition > 3000 &&
          (asset.duration <= 0 || savedPosition < asset.duration * 1000 - 3000)) {
        recent.add(asset);
      }
    }
    if (!mounted) return;
    setState(() {
      _lastWatchedAssetId = lastId;
      _lastWatchedTitle = prefs.getString('vortex_last_asset_title') ?? 'Last played video';
      _lastWatchedPositionMs = position;
      _recentlyWatched = recent;
    });
  }

  Future<void> _resumeLastWatched() async {
    final id = _lastWatchedAssetId;
    if (id == null || id.isEmpty) return;
    final asset = await AssetEntity.fromId(id);
    if (!mounted) return;
    if (asset == null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('vortex_last_asset_id');
      await prefs.remove('vortex_last_asset_title');
      await prefs.remove('vortex_last_position_ms');
      setState(() {
        _lastWatchedAssetId = null;
        _lastWatchedTitle = '';
        _lastWatchedPositionMs = 0;
      });
      _showMessage('Last played video is no longer available.');
      return;
    }
    await _openVideo(asset, resumeDirectly: true);
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final ids = prefs.getStringList('vortex_player_favorites') ?? <String>[];
    final fetched = await Future.wait(ids.map((id) => AssetEntity.fromId(id).catchError((_) => null)));
    final assets = fetched.whereType<AssetEntity>().toList();
    if (!mounted) return;
    setState(() {
      _favorites
        ..clear()
        ..addAll(ids);
      _favoriteAssets = assets;
    });
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('vortex_player_favorites', _favorites.toList());
  }

  Future<void> _loadVideos({bool silent = false}) async {
    // A silent refresh keeps the current list on screen instead of showing a full-page spinner.
    if (mounted && !silent) setState(() { _loading = true; _error = null; });
    try {
      final permission = await PhotoManager.requestPermissionExtend();
      if (!permission.isAuth && !permission.hasAccess) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = 'Allow video access so VORTEX can build your local video library.';
        });
        return;
      }
      final paths = await PhotoManager.getAssetPathList(
        type: RequestType.video,
        hasAll: false,
      );
      final selected = _selectedFolder;
      final clips = <AssetEntity>[];
      if (selected != null) {
        clips.addAll(await selected.getAssetListRange(start: 0, end: 5000));
      }
      clips.sort((a, b) => b.createDateTime.compareTo(a.createDateTime));
      if (!mounted) return;
      setState(() {
        _folders = paths;
        _videos = clips;
        _loading = false;
        _error = null;
      });
      _lastLibraryLoad = DateTime.now();
    } catch (e) {
      if (!mounted) return;
      // A failed background refresh must not replace a list that is already on screen.
      if (silent && (_folders.isNotEmpty || _videos.isNotEmpty)) return;
      setState(() { _loading = false; _error = 'Could not load video folders. Please try again.\n$e'; });
    }
  }

  Future<void> _openFolder(AssetPathEntity folder) async {
    setState(() { _selectedFolderIds.clear(); _selectedVideoIds.clear(); _selectedFolder = folder; _favoritesOnly = false; _query = ''; _searchController.clear(); });
    await _loadVideos();
  }

  Future<void> _leaveFolder() async {
    setState(() { _selectedFolderIds.clear(); _selectedVideoIds.clear(); _selectedFolder = null; _favoritesOnly = false; _query = ''; _searchController.clear(); });
    await _loadVideos();
  }

  List<AssetPathEntity> get _visibleFolders {
    final q = _query.trim().toLowerCase();
    var folders = List<AssetPathEntity>.from(_folders);
    if (q.isNotEmpty) folders = folders.where((folder) => folder.name.toLowerCase().contains(q)).toList();
    return folders;
  }

  List<AssetEntity> get _visibleVideos {
    var items = List<AssetEntity>.from(_selectedFolder == null && _showAllFavorites ? _favoriteAssets : _videos);
    if (_favoritesOnly) items = items.where((v) => _favorites.contains(v.id)).toList();
    final q = _query.trim().toLowerCase();
    if (q.isNotEmpty) items = items.where((v) => (v.title ?? '').toLowerCase().contains(q)).toList();
    items.sort(_compareVideos);
    return items;
  }

  int _compareVideos(AssetEntity a, AssetEntity b) {
    switch (_sortMode) {
      case 1:
        return a.createDateTime.compareTo(b.createDateTime);
      case 2:
        return (a.title ?? '').toLowerCase().compareTo((b.title ?? '').toLowerCase());
      case 3:
        return (b.title ?? '').toLowerCase().compareTo((a.title ?? '').toLowerCase());
      case 4:
        return b.duration.compareTo(a.duration);
      case 5:
        return a.duration.compareTo(b.duration);
      default:
        return b.createDateTime.compareTo(a.createDateTime);
    }
  }

  void _toggleFavorite(String id) {
    setState(() {
      if (!_favorites.add(id)) _favorites.remove(id);
    });
    _saveFavorites();
    // Keep the in-memory list in sync; do not reload every media item per tap.
    setState(() {
      if (_favorites.contains(id)) {
        AssetEntity? asset;
        for (final item in _videos) { if (item.id == id) { asset = item; break; } }
        if (asset != null && !_favoriteAssets.any((item) => item.id == id)) _favoriteAssets.add(asset);
      } else {
        _favoriteAssets.removeWhere((item) => item.id == id);
      }
    });
  }

  Future<void> _clearDeletedVideoData(List<String> ids) async {
    if (ids.isEmpty) return;
    final deleted = ids.toSet();
    final prefs = await SharedPreferences.getInstance();
    for (final id in deleted) {
      await prefs.remove('vortex_resume_$id');
      await prefs.remove('vortex_bookmarks_$id');
    }
    final recent = prefs.getStringList('vortex_recent_asset_ids') ?? <String>[];
    recent.removeWhere(deleted.contains);
    await prefs.setStringList('vortex_recent_asset_ids', recent);
    final favoriteIds = prefs.getStringList('vortex_player_favorites') ?? <String>[];
    favoriteIds.removeWhere(deleted.contains);
    await prefs.setStringList('vortex_player_favorites', favoriteIds);
    if (deleted.contains(prefs.getString('vortex_last_asset_id'))) {
      await prefs.remove('vortex_last_asset_id');
      await prefs.remove('vortex_last_asset_title');
      await prefs.remove('vortex_last_position_ms');
    }
    if (!mounted) return;
    setState(() {
      _videos.removeWhere((asset) => deleted.contains(asset.id));
      _favoriteAssets.removeWhere((asset) => deleted.contains(asset.id));
      _favorites.removeAll(deleted);
      _selectedVideoIds.removeAll(deleted);
    });
  }


  Future<void> _shareVideo(AssetEntity asset) async {
    final file = await asset.file;
    if (file == null) return;
    await Share.shareXFiles([XFile(file.path)], text: 'Shared with VORTEX PLAYER');
  }

  Future<void> _openVideo(AssetEntity asset, {bool resumeDirectly = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final savedForAsset = prefs.getInt('vortex_resume_${asset.id}') ?? 0;
    final durationMs = asset.duration * 1000;
    final hasSavedProgress = savedForAsset > 3000 &&
        (durationMs <= 0 || savedForAsset < durationMs - 3000);
    // Always continue this specific video from its saved position. The player
    // shows a small in-player "Start from beginning?" hint instead of blocking playback.
    final startPositionMs = hasSavedProgress
        ? savedForAsset
        : (resumeDirectly ? _lastWatchedPositionMs : 0);
    if (!mounted) return;
    final visible = _visibleVideos;
    final playlist = visible.any((item) => item.id == asset.id) ? visible : <AssetEntity>[asset];
    final index = playlist.indexWhere((item) => item.id == asset.id);
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => VideoPlayerPage(
        asset: asset,
        playlist: playlist,
        initialIndex: index < 0 ? 0 : index,
        initialPositionMs: startPositionMs,
        showStartOverHint: !resumeDirectly && hasSavedProgress,
        isFavorite: (id) => _favorites.contains(id),
        initiallyFavorite: _favorites.contains(asset.id),
        onFavorite: _toggleFavorite,
        onShare: (items) async {
          if (items.isNotEmpty) await _shareVideo(items.first);
        },
      ),
    ));
    await _loadLastWatched();
    await _loadFavorites();
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    final items = _visibleVideos;
    final selecting = _selectedVideoIds.isNotEmpty || _selectedFolderIds.isNotEmpty;
    return PopScope<Object?>(
      // Back steps out of selection, search, a folder or the Favourites tab before it closes the app.
      canPop: _selectedFolder == null && !_searchOpen && !selecting && !_showAllFavorites,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (selecting) {
          setState(() { _selectedFolderIds.clear(); _selectedVideoIds.clear(); });
        } else if (_searchOpen) {
          setState(() {
            _searchOpen = false;
            _query = '';
            _searchController.clear();
          });
        } else if (_selectedFolder != null) {
          _leaveFolder();
        } else if (_showAllFavorites) {
          setState(() => _showAllFavorites = false);
        }
      },
      child: Scaffold(
      backgroundColor: _bg,
      bottomNavigationBar: NavigationBar(
        height: 68,
        backgroundColor: _surface,
        indicatorColor: _primary.withValues(alpha: .18),
        selectedIndex: _showAllFavorites && _selectedFolder == null ? 1 : 0,
        onDestinationSelected: _selectNavigationTab,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.video_library_outlined), selectedIcon: Icon(Icons.video_library_rounded), label: 'Folders'),
          NavigationDestination(icon: Icon(Icons.favorite_border_rounded), selectedIcon: Icon(Icons.favorite_rounded), label: 'Favourites'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Settings'),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF17152B), _bg, Color(0xFF0D1522)], stops: [0, .38, 1]),
        ),
        child: SafeArea(
          child: Column(children: [
            _buildHeader(),
            if (_preparingExternalTitle != null) _buildPreparingBanner(),
            if (_searchOpen) _buildSearch(),
            if (!_showAllFavorites && _selectedFolder == null && _recentlyWatched.isNotEmpty) _buildContinueWatching(),
            const SizedBox(height: 8),
            _buildLibraryToolbar(),
            Expanded(child: _buildVideoLibrary(items)),
          ]),
        ),
      ),
      floatingActionButton: _lastWatchedAssetId != null && _lastWatchedPositionMs > 1500
          ? SizedBox(
              width: 58,
              height: 58,
              child: Material(
                color: Colors.transparent,
                shape: const CircleBorder(),
                elevation: 8,
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: _resumeLastWatched,
                  child: Ink(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [_primary, _secondary]),
                    ),
                    child: const Icon(Icons.play_arrow_rounded, color: _white, size: 34),
                  ),
                ),
              ),
            )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      ),
    );
  }

  Future<void> _selectNavigationTab(int index) async {
    if (index == 2) {
      await _openSettings();
      return;
    }
    if (index == 0) {
      if (_selectedFolder != null) {
        await _leaveFolder();
      } else if (_showAllFavorites || _searchOpen) {
        setState(() {
          _showAllFavorites = false;
          _searchOpen = false;
          _query = '';
          _searchController.clear();
        });
      }
      return;
    }
    setState(() {
      _selectedFolder = null;
      _showAllFavorites = true;
      _searchOpen = false;
      _favoritesOnly = false;
      _selectedFolderIds.clear();
      _selectedVideoIds.clear();
      _query = '';
      _searchController.clear();
    });
    await _loadFavorites();
  }

  // Shown while a video opened from another app is copied, so large files never look frozen.
  Widget _buildPreparingBanner() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 6),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
      decoration: BoxDecoration(
        color: _surface2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _primary.withValues(alpha: .35)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Preparing "${_preparingExternalTitle ?? 'video'}"', maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w800)),
        const SizedBox(height: 3),
        const Text('Large videos can take a moment to open.', style: TextStyle(color: _muted, fontSize: 10.5)),
        const SizedBox(height: 8),
        const ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(6)),
          child: LinearProgressIndicator(minHeight: 4, color: _primary, backgroundColor: Colors.white12),
        ),
      ]),
    );
  }

  Widget _buildContinueWatching() {
    return SizedBox(
      height: 132,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 4, 16, 8),
          child: Text('CONTINUE WATCHING', style: TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
        ),
        Expanded(child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: _recentlyWatched.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (context, index) {
            final asset = _recentlyWatched[index];
            return InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => _openVideo(asset),
              child: Container(
                width: 226,
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF1A1930), Color(0xFF141624)]),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white.withValues(alpha: .075)),
                  boxShadow: [BoxShadow(color: _primary.withValues(alpha: .07), blurRadius: 18, offset: const Offset(0, 7))],
                ),
                child: Row(children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(9),
                    child: SizedBox(width: 72, height: 74, child: AssetEntityImage(asset, isOriginal: false, thumbnailSize: _tileThumbnailSize, fit: BoxFit.cover)),
                  ),
                  const SizedBox(width: 9),
                  Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(asset.title ?? 'Video', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 5),
                    FutureBuilder<int>(
                      future: _savedVideoPositionMs(asset.id),
                      builder: (context, snapshot) => Text('Resume • ${_formatClock(Duration(milliseconds: snapshot.data ?? 0))}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _muted, fontSize: 11)),
                    ),
                  ])),
                ]),
              ),
            );
          },
        )),
      ]),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 16, 16, 12),
      child: Row(children: [
        if (_selectedFolder != null)
          IconButton(
            tooltip: 'Back to folders', onPressed: _leaveFolder,
            icon: const Icon(Icons.arrow_back_rounded, color: _white),
          ),
        Container(
          width: 48, height: 48,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_primary, _secondary]),
            boxShadow: [BoxShadow(color: _primary.withValues(alpha: .28), blurRadius: 18, offset: const Offset(0, 6))],
          ),
          padding: const EdgeInsets.all(3),
          child: const VortexLogoMark(size: 42),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          const Text('VORTEX', style: TextStyle(color: _white, fontSize: 20, height: 1, fontWeight: FontWeight.w900, letterSpacing: 2.0)),
          const SizedBox(height: 4),
          Text(
            _selectedFolder?.name ?? (_showAllFavorites ? 'Your favourites' : 'Your video library'),
            maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w600),
          ),
        ])),
        _headerAction(
          icon: _searchOpen ? Icons.close_rounded : Icons.search_rounded,
          tooltip: _searchOpen ? 'Close search' : 'Search videos',
          onTap: () => setState(() {
            _searchOpen = !_searchOpen;
            if (!_searchOpen) { _query = ''; _searchController.clear(); }
          }),
        ),
      ]),
    );
  }

  Widget _headerAction({required IconData icon, required String tooltip, required VoidCallback onTap, bool accent = false}) {
    return IconButton(
      tooltip: tooltip, onPressed: onTap,
      constraints: const BoxConstraints.tightFor(width: 40, height: 42), padding: EdgeInsets.zero,
      style: IconButton.styleFrom(
        backgroundColor: accent ? _primary.withValues(alpha: .18) : Colors.white.withValues(alpha: .055),
        foregroundColor: accent ? _softAccent : _white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      icon: Icon(icon, size: 20),
    );
  }

  Future<void> _showAbout() async {
    final info = await PackageInfo.fromPlatform();
    if (!mounted) return;
    final version = '${info.version}+${info.buildNumber}';
    showAboutDialog(
      context: context, applicationName: 'VORTEX PLAYER', applicationVersion: version,
      applicationIcon: const VortexLogoMark(size: 52),
      children: [
        const Text('A premium local video player with resume, playlists and subtitle support.'),
        TextButton.icon(
          onPressed: () => showLicensePage(context: context, applicationName: 'VORTEX PLAYER', applicationVersion: version),
          icon: const Icon(Icons.article_outlined), label: const Text('Open licenses'),
        ),
      ],
    );
  }

  Widget _buildSearch() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
      child: TextField(
        controller: _searchController,
        autofocus: true,
        onChanged: (v) => setState(() => _query = v),
        style: const TextStyle(color: _white, fontSize: 13),
        decoration: InputDecoration(
          hintText: _selectedFolder == null && !_showAllFavorites ? 'Search folder names…' : 'Search video names…',
          hintStyle: const TextStyle(color: _muted, fontSize: 12),
          prefixIcon: const Icon(Icons.search_rounded, color: _primary),
          filled: true, fillColor: _surface,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withValues(alpha: .05))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withValues(alpha: .06))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: _primary, width: 1)),
        ),
      ),
    );
  }

  Widget _buildLibraryToolbar() {
    final foldersMode = _selectedFolder == null && !_showAllFavorites;
    final selectionMode = _selectedVideoIds.isNotEmpty || _selectedFolderIds.isNotEmpty;
    final selectedCount = foldersMode ? _selectedFolderIds.length : _selectedVideoIds.length;
    final visibleCount = foldersMode ? _visibleFolders.length : _visibleVideos.length;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 6, 12, 13),
      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            selectionMode ? '$selectedCount SELECTED' : (_selectedFolder == null ? 'VIDEO FOLDERS' : 'VIDEOS'),
            style: const TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w800, letterSpacing: .35),
          ),
          const SizedBox(height: 3),
          Text(
            selectionMode ? 'Choose more items or remove selection' : (foldersMode ? '${_visibleFolders.length} video folders' : '${_visibleVideos.length} videos in this view'),
            style: const TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w500, letterSpacing: 0),
          ),
        ])),
        if (selectionMode) ...[
          IconButton(
            tooltip: selectedCount == visibleCount ? 'Clear selection' : 'Select all visible items',
            onPressed: () {
              if (selectedCount == visibleCount) {
                setState(() { _selectedFolderIds.clear(); _selectedVideoIds.clear(); });
              } else if (foldersMode) {
                _selectAllVisibleFolders(_visibleFolders);
              } else {
                _selectAllVisible(_visibleVideos);
              }
            },
            icon: Icon(selectedCount == visibleCount ? Icons.deselect_rounded : Icons.select_all_rounded, color: _primary),
          ),
          IconButton(
            tooltip: 'Delete selected items',
            onPressed: foldersMode
                ? () => _deleteSelectedFolders(_visibleFolders)
                : () => _deleteSelectedVideos(_visibleVideos),
            icon: const Icon(Icons.delete_outline_rounded, color: Color(0xFFFF7180)),
          ),
          IconButton(
            tooltip: 'Cancel selection',
            onPressed: () => setState(() { _selectedFolderIds.clear(); _selectedVideoIds.clear(); }),
            icon: const Icon(Icons.close_rounded, color: _white),
          ),
        ] else ...[
          if (_selectedFolder != null) ...[
            _FilterChip(label: 'ALL', active: !_favoritesOnly, onTap: () => setState(() => _favoritesOnly = false)),
            const SizedBox(width: 7),
            _FilterChip(label: '♥', active: _favoritesOnly, onTap: () => setState(() => _favoritesOnly = true)),
            const SizedBox(width: 8),
          ],
          if (!foldersMode)
            PopupMenuButton<int>(
              tooltip: 'Sort videos',
              color: _surface2,
              initialValue: _sortMode,
              onSelected: (mode) {
                setState(() => _sortMode = mode);
                unawaited(_saveLibraryPreferences());
              },
              icon: const Icon(Icons.sort_rounded, color: _primary, size: 22),
              itemBuilder: (_) => [
                for (var i = 0; i < _sortLabels.length; i++)
                  PopupMenuItem<int>(value: i, child: Text(_sortLabels[i])),
              ],
            ),
          IconButton(
            tooltip: _grid ? 'List view' : 'Grid view',
            onPressed: () { setState(() => _grid = !_grid); unawaited(_saveLibraryPreferences()); },
            style: IconButton.styleFrom(backgroundColor: Colors.white.withValues(alpha: .06), minimumSize: const Size(38, 38)),
            icon: Icon(_grid ? Icons.view_list_rounded : Icons.grid_view_rounded, color: _primary, size: 20),
          ),
        ],
      ]),
    );
  }

  Widget _animatedLibraryItem({required String id, required int index, required Widget child}) {
    final delay = index.clamp(0, 9).toInt() * 34;
    return TweenAnimationBuilder<double>(
      key: ValueKey<String>('library-entry-$id-${_grid ? 'grid' : 'list'}'),
      tween: Tween<double>(begin: 0, end: 1),
      duration: Duration(milliseconds: 380 + delay),
      curve: Curves.easeOutCubic,
      builder: (context, value, animatedChild) => Opacity(
        opacity: value,
        child: Transform.translate(
          offset: Offset(0, (1 - value) * 24),
          child: Transform.scale(
            scale: .965 + value * .035,
            child: animatedChild,
          ),
        ),
      ),
      child: child,
    );
  }

  Widget _buildVideoLibrary(List<AssetEntity> items) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _primary));
    if (_error != null) {
      return _VideoEmptyState(
        icon: Icons.video_library_rounded,
        title: 'VIDEO ACCESS REQUIRED',
        message: _error!,
        action: 'OPEN SETTINGS',
        onTap: () async { await PhotoManager.openSetting(); await _loadVideos(); },
      );
    }
    if (_selectedFolder == null && !_showAllFavorites) {
      final folders = _visibleFolders;
      if (folders.isEmpty) {
        return _VideoEmptyState(
          icon: Icons.folder_off_rounded,
          title: _query.isEmpty ? 'NO VIDEO FOLDERS' : 'NO MATCHING FOLDERS',
          message: _query.isEmpty ? 'Create or copy video folders on your phone, then refresh the library.' : 'Try another folder name.',
          action: 'REFRESH LIBRARY',
          onTap: _loadVideos,
        );
      }
      return RefreshIndicator(
        color: _primary,
        backgroundColor: _surface,
        onRefresh: () => _loadVideos(silent: true),
        child: _grid
            ? GridView.builder(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12,
                  childAspectRatio: 1.18,
                ),
                itemCount: folders.length,
                itemBuilder: (context, index) => _animatedLibraryItem(
                  id: folders[index].id,
                  index: index,
                  child: _FolderCard(
                    folder: folders[index],
                    grid: true,
                    selected: _selectedFolderIds.contains(folders[index].id),
                    onTap: () => _selectedFolderIds.isNotEmpty ? _toggleFolderSelection(folders[index].id) : _openFolder(folders[index]),
                    onLongPress: () => _toggleFolderSelection(folders[index].id),
                  ),
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                itemCount: folders.length,
                itemBuilder: (context, index) => _animatedLibraryItem(
                  id: folders[index].id,
                  index: index,
                  child: _FolderCard(
                    folder: folders[index],
                    selected: _selectedFolderIds.contains(folders[index].id),
                    onTap: () => _selectedFolderIds.isNotEmpty ? _toggleFolderSelection(folders[index].id) : _openFolder(folders[index]),
                    onLongPress: () => _toggleFolderSelection(folders[index].id),
                  ),
                ),
              ),
      );
    }
    if (items.isEmpty) {
      return _VideoEmptyState(
        icon: _favoritesOnly ? Icons.favorite_border_rounded : Icons.movie_creation_outlined,
        title: _favoritesOnly ? 'NO FAVOURITES YET' : 'NO VIDEOS FOUND',
        message: _favoritesOnly ? 'Tap the heart on any video to add it to your favourites.' : 'Videos saved on your phone will appear here automatically.',
        action: 'REFRESH LIBRARY',
        onTap: _loadVideos,
      );
    }
    return RefreshIndicator(
      color: _primary, backgroundColor: _surface, onRefresh: () => _loadVideos(silent: true),
      child: _grid
          ? GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 13, childAspectRatio: 1.06),
              itemCount: items.length,
              itemBuilder: (context, index) => _animatedLibraryItem(
                id: items[index].id,
                index: index,
                child: _VideoCard(
                  asset: items[index], favorite: _favorites.contains(items[index].id), selected: _selectedVideoIds.contains(items[index].id),
                  onTap: () => _selectedVideoIds.isNotEmpty ? _toggleVideoSelection(items[index].id) : _openVideo(items[index]),
                  onLongPress: () => _toggleVideoSelection(items[index].id),
                  onFavorite: () => _toggleFavorite(items[index].id),
                ),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) => _animatedLibraryItem(
                id: items[index].id,
                index: index,
                child: _VideoListTile(
                  asset: items[index], favorite: _favorites.contains(items[index].id), selected: _selectedVideoIds.contains(items[index].id),
                  onTap: () => _selectedVideoIds.isNotEmpty ? _toggleVideoSelection(items[index].id) : _openVideo(items[index]),
                  onLongPress: () => _toggleVideoSelection(items[index].id),
                  onFavorite: () => _toggleFavorite(items[index].id),
                ),
              ),
            ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(30), onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: active ? const LinearGradient(colors: [_primary, _secondary]) : null,
        color: active ? null : Colors.white.withValues(alpha: .055),
        border: Border.all(color: active ? Colors.transparent : Colors.white.withValues(alpha: .08)),
        boxShadow: active ? [BoxShadow(color: _primary.withValues(alpha: .20), blurRadius: 12)] : const [],
      ),
      child: Text(label, style: TextStyle(color: active ? _white : _muted, fontSize: 11, fontWeight: FontWeight.w900)),
    ),
  );
}

class _FolderCard extends StatelessWidget {
  final AssetPathEntity folder;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final bool selected;
  final bool grid;

  const _FolderCard({
    required this.folder,
    required this.onTap,
    required this.onLongPress,
    required this.selected,
    this.grid = false,
  });

  @override
  Widget build(BuildContext context) {
    final border = selected ? const Color(0xFF9B83FF) : _primary.withValues(alpha: .18);
    final icon = Container(
      width: grid ? 54 : 48,
      height: grid ? 54 : 48,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(colors: [_primary, _secondary]),
      ),
      child: Icon(grid ? Icons.video_library_rounded : Icons.folder_rounded,
          color: _white, size: grid ? 30 : 27),
    );
    if (!grid) {
      return Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: selected ? _primary.withValues(alpha: .12) : _surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: border, width: selected ? 1.7 : 1),
        ),
        child: ListTile(
          onTap: onTap,
          onLongPress: onLongPress,
          leading: Stack(alignment: Alignment.center, children: [icon, if (selected) const Icon(Icons.check_circle_rounded, color: Colors.white, size: 24)]),
          title: Text(folder.name, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _white, fontWeight: FontWeight.w800, fontSize: 13)),
          subtitle: FutureBuilder<int>(
            future: folder.assetCountAsync,
            builder: (context, snapshot) => Text('${snapshot.data ?? 0} videos',
              style: const TextStyle(color: _muted, fontSize: 11)),
          ),
          trailing: selected ? const Icon(Icons.check_circle_rounded, color: Color(0xFF9B83FF)) : const Icon(Icons.chevron_right_rounded, color: _muted),
        ),
      );
    }
    return Material(
      color: selected ? const Color(0xFF29204A) : _surface,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: border, width: selected ? 1.7 : 1),
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [_surface2.withValues(alpha: .92), _surface]),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [icon, const Spacer(), if (selected) const Icon(Icons.check_circle_rounded, color: Color(0xFF9B83FF), size: 27)]),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(folder.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                FutureBuilder<int>(
                  future: folder.assetCountAsync,
                  builder: (context, snapshot) => Text('${snapshot.data ?? 0} VIDEOS',
                    style: const TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.0)),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}

Future<int> _savedVideoPositionMs(String assetId) async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getInt('vortex_resume_$assetId') ?? 0;
}

class _VideoCard extends StatelessWidget {
  final AssetEntity asset;
  final bool favorite;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final VoidCallback onFavorite;
  const _VideoCard({required this.asset, required this.favorite, required this.selected, required this.onTap, required this.onLongPress, required this.onFavorite});

  @override
  Widget build(BuildContext context) => Material(
    color: _surface,
    borderRadius: BorderRadius.circular(22),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Stack(fit: StackFit.expand, children: [
          AssetEntityImage(asset, isOriginal: false, thumbnailSize: _cardThumbnailSize, fit: BoxFit.cover),
          const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0x99000000)]))),
          Center(child: Container(width: 50, height: 50, decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [_primary.withValues(alpha: .92), _secondary.withValues(alpha: .92)]), border: Border.all(color: Colors.white.withValues(alpha: .65), width: 1.2), boxShadow: [BoxShadow(color: _primary.withValues(alpha: .38), blurRadius: 22)]), child: const Icon(Icons.play_arrow_rounded, color: _white, size: 31))),
          if (selected) const Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(color: Color(0x553B091D)))),
          if (selected) const Positioned(left: 9, top: 9, child: Icon(Icons.check_circle_rounded, color: Color(0xFF9B83FF), size: 28)),
          Positioned(left: 9, bottom: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4), decoration: BoxDecoration(color: Colors.black.withValues(alpha: .70), borderRadius: BorderRadius.circular(7)), child: Text(_formatDuration(asset.duration), style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w800)))),
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: FutureBuilder<int>(
              future: _savedVideoPositionMs(asset.id),
              builder: (context, snapshot) {
                final saved = snapshot.data ?? 0;
                final totalMs = asset.duration * 1000;
                if (saved <= 1500 || totalMs <= 0) return const SizedBox(height: 3);
                final ratio = (saved / totalMs).clamp(0.0, 1.0).toDouble();
                return LinearProgressIndicator(value: ratio, minHeight: 3, backgroundColor: Colors.white24, valueColor: const AlwaysStoppedAnimation<Color>(_primary));
              },
            ),
          ),
          Positioned(right: 5, top: 5, child: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(onPressed: onFavorite, constraints: const BoxConstraints(minWidth: 42, minHeight: 42), padding: const EdgeInsets.all(9), style: IconButton.styleFrom(backgroundColor: Colors.black.withValues(alpha: .48)), icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: favorite ? _primary : _white, size: 18)),
          ])),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w700)),
          FutureBuilder<int>(
            future: _savedVideoPositionMs(asset.id),
            builder: (context, snapshot) {
              final saved = snapshot.data ?? 0;
              final totalMs = asset.duration * 1000;
              if (saved <= 1500 || totalMs <= 0 || saved >= totalMs - 3000) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text('Watched until ${_formatClock(Duration(milliseconds: saved))}', style: const TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w700)),
              );
            },
          ),
        ])),
      ]),
    ),
  );
}

class _VideoListTile extends StatelessWidget {
  final AssetEntity asset;
  final bool favorite;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final VoidCallback onFavorite;
  const _VideoListTile({required this.asset, required this.favorite, required this.selected, required this.onTap, required this.onLongPress, required this.onFavorite});
  @override
  Widget build(BuildContext context) => Material(
    color: _surface, borderRadius: BorderRadius.circular(16), clipBehavior: Clip.antiAlias,
    child: ListTile(
      onTap: onTap,
      onLongPress: onLongPress,
      selected: selected,
      selectedTileColor: _primary.withValues(alpha: .14),
      contentPadding: const EdgeInsets.all(7),
      leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: SizedBox(width: 82, height: 58, child: Stack(fit: StackFit.expand, children: [AssetEntityImage(asset, isOriginal: false, thumbnailSize: _tileThumbnailSize, fit: BoxFit.cover), const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 27)), if (selected) const DecoratedBox(decoration: BoxDecoration(color: Color(0x553B091D))), if (selected) const Icon(Icons.check_circle_rounded, color: Color(0xFF9B83FF))]))),
      title: Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w800)),
      subtitle: FutureBuilder<int>(
        future: _savedVideoPositionMs(asset.id),
        builder: (context, snapshot) {
          final saved = snapshot.data ?? 0;
          final totalMs = asset.duration * 1000;
          final watched = saved > 1500 && totalMs > 0 && saved < totalMs - 3000;
          return Text(
            watched
                ? '${_formatDuration(asset.duration)}  •  Watched until ${_formatClock(Duration(milliseconds: saved))}'
                : '${_formatDuration(asset.duration)}  •  ${_formatDate(asset.createDateTime)}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: watched ? _primary : _muted, fontSize: 11),
          );
        },
      ),
      trailing: IconButton(onPressed: onFavorite, icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: favorite ? _primary : _muted, size: 19)),
    ),
  );
}

class _VideoEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String action;
  final VoidCallback onTap;
  const _VideoEmptyState({required this.icon, required this.title, required this.message, required this.action, required this.onTap});
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(30),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 86, height: 86, decoration: BoxDecoration(shape: BoxShape.circle, color: _surface2, border: Border.all(color: _primary.withValues(alpha: .24)), boxShadow: [BoxShadow(color: _secondary.withValues(alpha: .13), blurRadius: 24)]), child: Icon(icon, color: _primary, size: 39)),
      const SizedBox(height: 18),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
      const SizedBox(height: 9),
      Text(message, textAlign: TextAlign.center, style: const TextStyle(color: _muted, height: 1.5, fontSize: 11)),
      const SizedBox(height: 18),
      FilledButton(onPressed: onTap, style: FilledButton.styleFrom(backgroundColor: _primary, foregroundColor: _white, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)), child: Text(action, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1))),
    ]),
  ));
}


class VortexSettingsPage extends StatefulWidget {
  final Future<void> Function()? onRefresh;
  final Future<void> Function()? onAbout;

  const VortexSettingsPage({super.key, this.onRefresh, this.onAbout});

  @override
  State<VortexSettingsPage> createState() => _VortexSettingsPageState();
}

class _VortexSettingsPageState extends State<VortexSettingsPage> {
  double _subtitleScale = 1.25;
  int _seekSeconds = 5;
  bool _grid = true;
  int _sortMode = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('vortex_subtitle_position'); // Retire the old vertical-position setting.
    if (!mounted) return;
    setState(() {
      _subtitleScale = (prefs.getDouble('vortex_subtitle_scale') ?? 1.25).clamp(.6, 2.5).toDouble();
      _seekSeconds = (prefs.getInt('vortex_swipe_seek_seconds') ?? 5).clamp(5, 60).toInt();
      _grid = prefs.getBool('vortex_library_grid') ?? true;
      final legacyMode = (prefs.getBool('vortex_library_newest_first') ?? true) ? 0 : 1;
      _sortMode = (prefs.getInt('vortex_library_sort') ?? legacyMode).clamp(0, _sortLabels.length - 1).toInt();
      _loading = false;
    });
  }

  Future<void> _saveDouble(String key, double value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(key, value);
  }

  Future<void> _saveInt(String key, int value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(key, value);
  }

  Future<void> _saveBool(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  Widget _sectionTitle(String title, String subtitle, IconData icon) => Padding(
    padding: const EdgeInsets.fromLTRB(2, 22, 2, 11),
    child: Row(children: [
      Container(width: 38, height: 38, decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(13),
        gradient: LinearGradient(colors: [_primary.withValues(alpha: .28), _cyan.withValues(alpha: .12)]),
      ), child: Icon(icon, color: _softAccent, size: 20)),
      const SizedBox(width: 11),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: .6)),
        const SizedBox(height: 3),
        Text(subtitle, style: const TextStyle(color: _muted, fontSize: 10.5, height: 1.25)),
      ])),
    ]),
  );

  Widget _card({required Widget child}) => Container(
    padding: const EdgeInsets.fromLTRB(16, 15, 16, 15),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF1A1930), Color(0xFF141624)]),
      border: Border.all(color: Colors.white.withValues(alpha: .075)),
      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .18), blurRadius: 20, offset: const Offset(0, 8))],
    ),
    child: child,
  );

  Widget _valueRow(String title, String value) => Row(children: [
    Expanded(child: Text(title, style: const TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w800))),
    Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: _primary.withValues(alpha: .15), borderRadius: BorderRadius.circular(10)),
      child: Text(value, style: const TextStyle(color: _softAccent, fontSize: 12, fontWeight: FontWeight.w900))),
  ]);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Color(0xFF1A1930), _bg, Color(0xFF0D0E19)], stops: [0, .40, 1])),
        child: SafeArea(child: Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(10, 7, 18, 8), child: Row(children: [
            IconButton(onPressed: () => Navigator.maybePop(context), icon: const Icon(Icons.arrow_back_rounded, color: _white)),
            const SizedBox(width: 6),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('SETTINGS', style: TextStyle(color: _white, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              Text('Make VORTEX feel the way you like', style: TextStyle(color: _muted, fontSize: 10.5)),
            ])),
            const VortexLogoMark(size: 42),
          ])),
          Expanded(child: _loading
            ? const Center(child: CircularProgressIndicator(color: _primary))
            : ListView(padding: const EdgeInsets.fromLTRB(17, 5, 17, 30), children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [Color(0xFF5B3EA6), Color(0xFF242044), Color(0xFF142236)]),
                  border: Border.all(color: Colors.white.withValues(alpha: .12)),
                  boxShadow: [BoxShadow(color: _primary.withValues(alpha: .17), blurRadius: 28, offset: const Offset(0, 10))],
                ),
                child: Row(children: [
                  const Icon(Icons.tune_rounded, color: _white, size: 30),
                  const SizedBox(width: 14),
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('YOUR PLAYER. YOUR STYLE.', style: TextStyle(color: _white, fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: .5)),
                    SizedBox(height: 5),
                    Text('Simple controls, clear previews and settings that stay saved.', style: TextStyle(color: Color(0xFFE3D9E5), fontSize: 11, height: 1.35)),
                  ])),
                ]),
              ),
              _sectionTitle('Subtitle appearance', 'Choose a comfortable subtitle text size.', Icons.subtitles_rounded),
              _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _valueRow('Text size', '${(_subtitleScale * 100).round()}%'),
                Slider(value: _subtitleScale, min: .6, max: 2.5, divisions: 19,
                  onChanged: (v) { setState(() => _subtitleScale = v); },
                  onChangeEnd: (v) => _saveDouble('vortex_subtitle_scale', v)),
                const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Small', style: TextStyle(color: _muted, fontSize: 10)),
                  Text('Large', style: TextStyle(color: _muted, fontSize: 10)),
                ]),
                const SizedBox(height: 14),
                Container(
                  height: 142, width: double.infinity,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: const Color(0xFF090A12), border: Border.all(color: Colors.white12)),
                  child: Stack(children: [
                    Positioned(left: 14, top: 12, child: Row(children: [
                      const Icon(Icons.play_circle_outline_rounded, color: Colors.white38, size: 15),
                      const SizedBox(width: 6),
                      Text('PREVIEW', style: TextStyle(color: Colors.white.withValues(alpha: .48), fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
                    ])),
                    Align(
                      alignment: const Alignment(0, .70),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 15),
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(color: Colors.black.withValues(alpha: .72), borderRadius: BorderRadius.circular(7)),
                        child: Text('Subtitle preview', textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, fontSize: (14 * _subtitleScale).clamp(9, 30).toDouble(), fontWeight: FontWeight.w800)),
                      ),
                    ),
                  ]),
                ),
                const SizedBox(height: 10),
                Row(children: [
                  const Icon(Icons.touch_app_outlined, color: _cyan, size: 17),
                  const SizedBox(width: 7),
                  const Expanded(child: Text('Changes are saved automatically and apply while watching.', style: TextStyle(color: _muted, fontSize: 10.5, height: 1.35))),
                ]),
                const SizedBox(height: 10),
                Align(alignment: Alignment.centerRight, child: TextButton.icon(
                  onPressed: () async {
                    setState(() => _subtitleScale = 1.25);
                    await _saveDouble('vortex_subtitle_scale', 1.25);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.remove('vortex_subtitle_position');
                  },
                  icon: const Icon(Icons.restart_alt_rounded, size: 17), label: const Text('Reset subtitle settings'),
                )),
              ])),
              _sectionTitle('Playback gestures', 'Choose how far a horizontal swipe skips.', Icons.swipe_rounded),
              _card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _valueRow('Swipe skip interval', '$_seekSeconds sec'),
                const SizedBox(height: 13),
                Wrap(spacing: 8, runSpacing: 8, children: [5, 10, 15, 20, 30, 45, 60].map((seconds) => ChoiceChip(
                  label: Text('${seconds}s'), selected: _seekSeconds == seconds,
                  selectedColor: _primary.withValues(alpha: .30), backgroundColor: Colors.white.withValues(alpha: .045),
                  labelStyle: TextStyle(color: _seekSeconds == seconds ? _white : _muted, fontSize: 11, fontWeight: FontWeight.w800),
                  side: BorderSide(color: _seekSeconds == seconds ? _primary.withValues(alpha: .8) : Colors.white12),
                  onSelected: (_) { setState(() => _seekSeconds = seconds); _saveInt('vortex_swipe_seek_seconds', seconds); },
                )).toList()),
                const SizedBox(height: 7),
                const Text('Left and right swipe use the same interval. Double-tap seek remains 10 seconds.', style: TextStyle(color: _muted, fontSize: 10.5, height: 1.35)),
              ])),
              _sectionTitle('Library layout', 'Choose how your videos are arranged.', Icons.video_library_rounded),
              _card(child: Column(children: [
                Row(children: [
                  const Expanded(child: Text('View style', style: TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w800))),
                  ChoiceChip(label: const Text('Grid'), selected: _grid, onSelected: (_) { setState(() => _grid = true); _saveBool('vortex_library_grid', true); }),
                  const SizedBox(width: 7),
                  ChoiceChip(label: const Text('List'), selected: !_grid, onSelected: (_) { setState(() => _grid = false); _saveBool('vortex_library_grid', false); }),
                ]),
                const Divider(color: Colors.white12, height: 24),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Sort videos', style: TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w800)),
                ),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Wrap(spacing: 8, runSpacing: 8, children: [
                    for (var i = 0; i < _sortLabels.length; i++)
                      ChoiceChip(
                        label: Text(_sortLabels[i]),
                        selected: _sortMode == i,
                        onSelected: (_) {
                          setState(() => _sortMode = i);
                          _saveInt('vortex_library_sort', i);
                          _saveBool('vortex_library_newest_first', i != 1);
                        },
                      ),
                  ]),
                ),
              ])),
              _sectionTitle('App actions', 'Useful options without extra menu buttons on the home screen.', Icons.apps_rounded),
              _card(child: Column(children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.refresh_rounded, color: _softAccent),
                  title: const Text('Refresh video library', style: TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w800)),
                  subtitle: const Text('Scan for videos and folders again', style: TextStyle(color: _muted, fontSize: 10)),
                  trailing: const Icon(Icons.chevron_right_rounded, color: _muted),
                  onTap: widget.onRefresh == null ? null : () async {
                    await widget.onRefresh!.call();
                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Video library refreshed'), behavior: SnackBarBehavior.floating));
                  },
                ),
                const Divider(color: Colors.white12, height: 1),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.info_outline_rounded, color: _softAccent),
                  title: const Text('About VORTEX PLAYER', style: TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w800)),
                  subtitle: const Text('Version and open-source licenses', style: TextStyle(color: _muted, fontSize: 10)),
                  trailing: const Icon(Icons.chevron_right_rounded, color: _muted),
                  onTap: widget.onAbout == null ? null : () => widget.onAbout!.call(),
                ),
              ])),
              const SizedBox(height: 25),
              Center(child: Text('VORTEX PLAYER  •  SETTINGS', style: TextStyle(color: _muted.withValues(alpha: .62), fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.8))),
              const SizedBox(height: 10),
            ])),
        ])),
      ),
    );
  }
}
