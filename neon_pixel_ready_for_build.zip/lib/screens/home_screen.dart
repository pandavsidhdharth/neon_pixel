part of '../main.dart';

class VortexHome extends StatefulWidget {
  const VortexHome({super.key});

  @override
  State<VortexHome> createState() => _VortexHomeState();
}

class _VortexHomeState extends State<VortexHome> {
  List<AssetEntity> _videos = [];
  List<AssetPathEntity> _folders = [];
  AssetPathEntity? _selectedFolder;
  final Set<String> _favorites = {};
  List<AssetEntity> _favoriteAssets = [];
  List<AssetEntity> _recentlyWatched = [];
  bool _showAllFavorites = false;
  final TextEditingController _searchController = TextEditingController();
  bool _loading = true;
  bool _searchOpen = false;
  bool _favoritesOnly = false;
  bool _grid = true;
  bool _newestFirst = true;
  String? _error;
  String _query = '';
  String? _lastWatchedAssetId;
  String _lastWatchedTitle = '';
  int _lastWatchedPositionMs = 0;

  @override
  void initState() {
    super.initState();
    _externalChannel.setMethodCallHandler((call) async {
      if (call.method == 'externalVideoAvailable') {
        await _consumePendingExternalVideo();
      }
    });
    _loadFavorites();
    _loadVideos();
    _loadLastWatched();
    WidgetsBinding.instance.addPostFrameCallback((_) => _consumePendingExternalVideo());
  }

  Future<void> _consumePendingExternalVideo() async {
    try {
      final pending = await _externalChannel.invokeMethod<Map<dynamic, dynamic>>('consumePendingExternalVideo');
      if (pending == null || !mounted) return;
      final path = pending['path']?.toString();
      final title = pending['title']?.toString() ?? 'External video';
      if (path != null && path.isNotEmpty) await _openExternalVideo(path, title);
    } catch (_) {}
  }

  Future<void> _openExternalVideo(String path, String title) async {
    if (!mounted) return;
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ExternalVideoPage(path: path, title: title),
    ));
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadLastWatched() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    final lastId = prefs.getString('vortex_last_asset_id');
    final position = lastId == null
        ? (prefs.getInt('vortex_last_position_ms') ?? 0)
        : (prefs.getInt('vortex_resume_$lastId') ??
            prefs.getInt('vortex_last_position_ms') ?? 0);
    final ids = prefs.getStringList('vortex_recent_asset_ids') ?? <String>[];
    if (lastId != null && lastId.isNotEmpty) {
      ids.remove(lastId);
      ids.insert(0, lastId);
    }
    final recent = <AssetEntity>[];
    for (final id in ids.take(12)) {
      final asset = await AssetEntity.fromId(id);
      final savedPosition = prefs.getInt('vortex_resume_$id') ?? 0;
      if (asset != null && savedPosition > 3000 &&
          (asset.duration <= 0 || savedPosition < asset.duration * 1000 - 3000)) {
        recent.add(asset);
      }
    }
    if (!mounted) return;
    setState(() {
      _lastWatchedAssetId = lastId;
      _lastWatchedTitle = prefs.getString('vortex_last_asset_title') ?? 'Last played video';
      _lastWatchedPositionMs = position;
      _recentlyWatched = recent;
    });
  }

  Future<void> _resumeLastWatched() async {
    final id = _lastWatchedAssetId;
    if (id == null || id.isEmpty) return;
    final asset = await AssetEntity.fromId(id);
    if (!mounted) return;
    if (asset == null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('vortex_last_asset_id');
      await prefs.remove('vortex_last_asset_title');
      await prefs.remove('vortex_last_position_ms');
      setState(() {
        _lastWatchedAssetId = null;
        _lastWatchedTitle = '';
        _lastWatchedPositionMs = 0;
      });
      _showMessage('Last played video is no longer available.');
      return;
    }
    await _openVideo(asset, resumeDirectly: true);
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final ids = prefs.getStringList('vortex_player_favorites') ?? <String>[];
    final assets = <AssetEntity>[];
    for (final id in ids) {
      final asset = await AssetEntity.fromId(id);
      if (asset != null) assets.add(asset);
    }
    if (!mounted) return;
    setState(() {
      _favorites
        ..clear()
        ..addAll(ids);
      _favoriteAssets = assets;
    });
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('vortex_player_favorites', _favorites.toList());
  }

  Future<void> _loadVideos() async {
    if (mounted) setState(() { _loading = true; _error = null; });
    try {
      final permission = await PhotoManager.requestPermissionExtend();
      if (!permission.isAuth && !permission.hasAccess) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = 'Allow video access so VORTEX can build your local video library.';
        });
        return;
      }
      final paths = await PhotoManager.getAssetPathList(
        type: RequestType.video,
        hasAll: false,
      );
      final selected = _selectedFolder;
      final clips = <AssetEntity>[];
      if (selected != null) {
        clips.addAll(await selected.getAssetListRange(start: 0, end: 5000));
      }
      clips.sort((a, b) => b.createDateTime.compareTo(a.createDateTime));
      if (!mounted) return;
      setState(() {
        _folders = paths;
        _videos = clips;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Could not load video folders. Please try again.\n$e'; });
    }
  }

  Future<void> _openFolder(AssetPathEntity folder) async {
    setState(() { _selectedFolder = folder; _favoritesOnly = false; _query = ''; _searchController.clear(); });
    await _loadVideos();
  }

  Future<void> _leaveFolder() async {
    setState(() { _selectedFolder = null; _favoritesOnly = false; _query = ''; _searchController.clear(); });
    await _loadVideos();
  }

  List<AssetPathEntity> get _visibleFolders {
    final q = _query.trim().toLowerCase();
    var folders = List<AssetPathEntity>.from(_folders);
    if (q.isNotEmpty) folders = folders.where((folder) => folder.name.toLowerCase().contains(q)).toList();
    return folders;
  }

  List<AssetEntity> get _visibleVideos {
    var items = List<AssetEntity>.from(_selectedFolder == null && _showAllFavorites ? _favoriteAssets : _videos);
    if (_favoritesOnly) items = items.where((v) => _favorites.contains(v.id)).toList();
    final q = _query.trim().toLowerCase();
    if (q.isNotEmpty) items = items.where((v) => (v.title ?? '').toLowerCase().contains(q)).toList();
    items.sort((a, b) => _newestFirst
        ? b.createDateTime.compareTo(a.createDateTime)
        : a.createDateTime.compareTo(b.createDateTime));
    return items;
  }

  void _toggleFavorite(String id) {
    setState(() {
      if (!_favorites.add(id)) _favorites.remove(id);
    });
    _saveFavorites();
    // Keep the in-memory list in sync; do not reload every media item per tap.
    setState(() {
      if (_favorites.contains(id)) {
        AssetEntity? asset;
        for (final item in _videos) { if (item.id == id) { asset = item; break; } }
        if (asset != null && !_favoriteAssets.any((item) => item.id == id)) _favoriteAssets.add(asset);
      } else {
        _favoriteAssets.removeWhere((item) => item.id == id);
      }
    });
  }

  Future<void> _clearDeletedVideoData(List<String> ids) async {
    if (ids.isEmpty) return;
    final deleted = ids.toSet();
    final prefs = await SharedPreferences.getInstance();
    for (final id in deleted) {
      await prefs.remove('vortex_resume_$id');
      await prefs.remove('vortex_bookmarks_$id');
    }
    final recent = prefs.getStringList('vortex_recent_asset_ids') ?? <String>[];
    recent.removeWhere(deleted.contains);
    await prefs.setStringList('vortex_recent_asset_ids', recent);
    final favoriteIds = prefs.getStringList('vortex_player_favorites') ?? <String>[];
    favoriteIds.removeWhere(deleted.contains);
    await prefs.setStringList('vortex_player_favorites', favoriteIds);
    if (deleted.contains(prefs.getString('vortex_last_asset_id'))) {
      await prefs.remove('vortex_last_asset_id');
      await prefs.remove('vortex_last_asset_title');
      await prefs.remove('vortex_last_position_ms');
    }
    if (!mounted) return;
    setState(() {
      _videos.removeWhere((asset) => deleted.contains(asset.id));
      _favoriteAssets.removeWhere((asset) => deleted.contains(asset.id));
      _favorites.removeAll(deleted);
    });
  }

  Future<void> _deleteVideo(AssetEntity asset) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: _surface2,
        title: const Text('Delete video?', style: TextStyle(color: _white, fontWeight: FontWeight.w800)),
        content: Text(
          '“${asset.title ?? 'Untitled video'}” will be removed from VORTEX. On Android 11 and newer it is moved to Trash; Android may ask you to confirm.',
          style: const TextStyle(color: _muted, fontSize: 13, height: 1.4),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB3263D), foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('DELETE'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    try {
      final deletedIds = await PhotoManager.editor.deleteWithIds([asset.id]);
      if (deletedIds.isEmpty) {
        await _loadVideos();
        _showMessage('Android did not approve deleting this video.');
        return;
      }
      await _clearDeletedVideoData(deletedIds);
      await _loadVideos();
      await _loadLastWatched();
      await _loadFavorites();
      _showMessage('Video removed from VORTEX.');
    } catch (e) {
      _showMessage('Could not delete video: $e');
    }
  }

  Future<void> _deleteFolderVideos(AssetPathEntity folder) async {
    try {
      final count = await folder.assetCountAsync;
      final assets = await folder.getAssetListRange(start: 0, end: count);
      if (assets.isEmpty) {
        _showMessage('This folder has no videos to delete.');
        return;
      }
      final approved = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          backgroundColor: _surface2,
          title: Text('Delete folder “${folder.name}”?', style: const TextStyle(color: _white, fontWeight: FontWeight.w800)),
          content: Text(
            'This will remove all ${assets.length} videos inside this folder from VORTEX. On Android 11 and newer, the videos are moved to Trash. Android may ask you to confirm.',
            style: const TextStyle(color: _muted, fontSize: 13, height: 1.4),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB3263D), foregroundColor: Colors.white),
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('DELETE ALL'),
            ),
          ],
        ),
      );
      if (approved != true) return;
      final deletedIds = await PhotoManager.editor.deleteWithIds(assets.map((asset) => asset.id).toList());
      await _clearDeletedVideoData(deletedIds);
      await _loadVideos();
      await _loadLastWatched();
      await _loadFavorites();
      if (deletedIds.isEmpty) {
        _showMessage('Android did not approve deleting this folder’s videos.');
      } else {
        _showMessage('Removed ${deletedIds.length} videos from “${folder.name}”.');
      }
    } catch (e) {
      _showMessage('Could not delete folder videos: $e');
    }
  }

  Future<void> _shareVideo(AssetEntity asset) async {
    final file = await asset.file;
    if (file == null) return;
    await Share.shareXFiles([XFile(file.path)], text: 'Shared with VORTEX PLAYER');
  }

  Future<int?> _chooseStartPosition(AssetEntity asset) async {
    final prefs = await SharedPreferences.getInstance();
    final savedMs = prefs.getInt('vortex_resume_${asset.id}') ?? 0;
    final durationMs = asset.duration * 1000;
    final isIncomplete = savedMs > 3000 && (durationMs <= 0 || savedMs < durationMs - 3000);
    if (!isIncomplete) return 0;
    if (!mounted) return null;
    return _showResumePrompt(context, savedMs);
  }

  Future<void> _openVideo(AssetEntity asset, {bool resumeDirectly = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final savedForAsset = prefs.getInt('vortex_resume_${asset.id}') ?? 0;
    final startPositionMs = resumeDirectly
        ? (savedForAsset > 0 ? savedForAsset : _lastWatchedPositionMs)
        : await _chooseStartPosition(asset);
    if (!mounted || startPositionMs == null) return;
    final visible = _visibleVideos;
    final playlist = visible.any((item) => item.id == asset.id) ? visible : <AssetEntity>[asset];
    final index = playlist.indexWhere((item) => item.id == asset.id);
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => VideoPlayerPage(
        asset: asset,
        playlist: playlist,
        initialIndex: index < 0 ? 0 : index,
        initialPositionMs: startPositionMs,
        isFavorite: (id) => _favorites.contains(id),
        initiallyFavorite: _favorites.contains(asset.id),
        onFavorite: _toggleFavorite,
        onShare: (items) async {
          if (items.isNotEmpty) await _shareVideo(items.first);
        },
      ),
    ));
    await _loadLastWatched();
    await _loadFavorites();
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    final items = _visibleVideos;
    return PopScope<Object?>(
      canPop: _selectedFolder == null && !_searchOpen,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (_searchOpen) {
          setState(() {
            _searchOpen = false;
            _query = '';
            _searchController.clear();
          });
        } else if (_selectedFolder != null) {
          _leaveFolder();
        }
      },
      child: Scaffold(
      backgroundColor: _bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF210A15), _bg, Color(0xFF10060C)], stops: [0, .42, 1]),
        ),
        child: SafeArea(
          child: Column(children: [
            _buildHeader(),
            if (_searchOpen) _buildSearch(),
            if (!_showAllFavorites && _selectedFolder == null && _recentlyWatched.isNotEmpty) _buildContinueWatching(),
            const SizedBox(height: 8),
            _buildLibraryToolbar(),
            Expanded(child: _buildVideoLibrary(items)),
          ]),
        ),
      ),
      floatingActionButton: _lastWatchedAssetId != null && _lastWatchedPositionMs > 1500
          ? SizedBox(
              width: 58,
              height: 58,
              child: Material(
                color: Colors.transparent,
                shape: const CircleBorder(),
                elevation: 8,
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: _resumeLastWatched,
                  child: Ink(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [_primary, _secondary]),
                    ),
                    child: const Icon(Icons.play_arrow_rounded, color: _white, size: 34),
                  ),
                ),
              ),
            )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      ),
    );
  }

  Widget _buildContinueWatching() {
    return SizedBox(
      height: 124,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 4, 16, 8),
          child: Text('CONTINUE WATCHING', style: TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
        ),
        Expanded(child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: _recentlyWatched.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (context, index) {
            final asset = _recentlyWatched[index];
            return InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => _openVideo(asset),
              child: Container(
                width: 210,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _primary.withValues(alpha: .18)),
                ),
                child: Row(children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(9),
                    child: SizedBox(width: 72, height: 74, child: AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover)),
                  ),
                  const SizedBox(width: 9),
                  Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(asset.title ?? 'Video', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 5),
                    FutureBuilder<int>(
                      future: _savedVideoPositionMs(asset.id),
                      builder: (context, snapshot) => Text('Resume • ${_formatClock(Duration(milliseconds: snapshot.data ?? 0))}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _muted, fontSize: 11)),
                    ),
                  ])),
                ]),
              ),
            );
          },
        )),
      ]),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 16, 8),
      child: Row(children: [
        if (_selectedFolder != null)
          IconButton(
            tooltip: 'Back to folders',
            onPressed: _leaveFolder,
            icon: const Icon(Icons.arrow_back_rounded, color: _primary),
          ),
        const VortexLogoMark(size: 50),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('VORTEX', style: TextStyle(color: _white, fontSize: 22, height: 1, fontWeight: FontWeight.w900, letterSpacing: 2.1)),
          const SizedBox(height: 4),
          Text('PREMIUM VIDEO PLAYER', style: TextStyle(color: _primary.withValues(alpha: .9), fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 2.0)),
        ])),
        IconButton(
          tooltip: _searchOpen ? 'Close search' : 'Search videos',
          onPressed: () => setState(() {
            _searchOpen = !_searchOpen;
            if (!_searchOpen) { _query = ''; _searchController.clear(); }
          }),
          style: IconButton.styleFrom(backgroundColor: Colors.white.withValues(alpha: .07)),
          icon: Icon(_searchOpen ? Icons.close_rounded : Icons.search_rounded, color: _white),
        ),
        const SizedBox(width: 6),
        PopupMenuButton<String>(
          color: _surface2,
          icon: const Icon(Icons.more_vert_rounded, color: _white),
          onSelected: (v) {
            if (v == 'refresh') _loadVideos();
            if (v == 'about') _showAbout();
            if (v == 'newest') setState(() => _newestFirst = true);
            if (v == 'oldest') setState(() => _newestFirst = false);
            if (v == 'grid') setState(() => _grid = true);
            if (v == 'list') setState(() => _grid = false);
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'newest', child: Text('Newest first')),
            PopupMenuItem(value: 'oldest', child: Text('Oldest first')),
            PopupMenuDivider(),
            PopupMenuItem(value: 'grid', child: Text('Grid view')),
            PopupMenuItem(value: 'list', child: Text('List view')),
            PopupMenuDivider(),
            PopupMenuItem(value: 'refresh', child: Text('Refresh library')),
            PopupMenuItem(value: 'about', child: Text('About VORTEX')), 
          ],
        ),
      ]),
    );
  }

  Future<void> _showAbout() async {
    final info = await PackageInfo.fromPlatform();
    if (!mounted) return;
    final version = '${info.version}+${info.buildNumber}';
    showAboutDialog(
      context: context, applicationName: 'VORTEX PLAYER', applicationVersion: version,
      applicationIcon: const VortexLogoMark(size: 52),
      children: [
        const Text('A premium local video player with resume, playlists and subtitle support.'),
        TextButton.icon(
          onPressed: () => showLicensePage(context: context, applicationName: 'VORTEX PLAYER', applicationVersion: version),
          icon: const Icon(Icons.article_outlined), label: const Text('Open licenses'),
        ),
      ],
    );
  }

  Widget _buildSearch() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
      child: TextField(
        controller: _searchController,
        autofocus: true,
        onChanged: (v) => setState(() => _query = v),
        style: const TextStyle(color: _white, fontSize: 13),
        decoration: InputDecoration(
          hintText: _selectedFolder == null && !_showAllFavorites ? 'Search folder names…' : 'Search video names…',
          hintStyle: const TextStyle(color: _muted, fontSize: 12),
          prefixIcon: const Icon(Icons.search_rounded, color: _primary),
          filled: true, fillColor: _surface,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withValues(alpha: .05))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withValues(alpha: .06))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: _primary, width: 1)),
        ),
      ),
    );
  }

  Widget _buildLibraryToolbar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 2, 18, 12),
      child: Row(children: [
        Expanded(child: Text(
          _selectedFolder == null ? 'VIDEO FOLDERS' : 'VIDEOS',
          style: const TextStyle(color: _white, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.4),
        )),
        if (_selectedFolder == null) ...[
          _FilterChip(label: _showAllFavorites ? 'FOLDERS' : '♥ FAVOURITES', active: _showAllFavorites, onTap: () => setState(() => _showAllFavorites = !_showAllFavorites)),
          const SizedBox(width: 8),
        ] else ...[
          _FilterChip(label: 'ALL', active: !_favoritesOnly, onTap: () => setState(() => _favoritesOnly = false)),
          const SizedBox(width: 7),
          _FilterChip(label: '♥', active: _favoritesOnly, onTap: () => setState(() => _favoritesOnly = true)),
          const SizedBox(width: 8),
        ],
        IconButton(
          tooltip: _grid ? 'List view' : 'Grid view',
          onPressed: () => setState(() => _grid = !_grid),
          style: IconButton.styleFrom(backgroundColor: Colors.white.withValues(alpha: .06), minimumSize: const Size(38, 38)),
          icon: Icon(_grid ? Icons.view_list_rounded : Icons.grid_view_rounded, color: _primary, size: 20),
        ),
      ]),
    );
  }

  Widget _buildVideoLibrary(List<AssetEntity> items) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _primary));
    if (_error != null) {
      return _VideoEmptyState(
        icon: Icons.video_library_rounded,
        title: 'VIDEO ACCESS REQUIRED',
        message: _error!,
        action: 'OPEN SETTINGS',
        onTap: () async { await PhotoManager.openSetting(); await _loadVideos(); },
      );
    }
    if (_selectedFolder == null && !_showAllFavorites) {
      final folders = _visibleFolders;
      if (folders.isEmpty) {
        return _VideoEmptyState(
          icon: Icons.folder_off_rounded,
          title: _query.isEmpty ? 'NO VIDEO FOLDERS' : 'NO MATCHING FOLDERS',
          message: _query.isEmpty ? 'Create or copy video folders on your phone, then refresh the library.' : 'Try another folder name.',
          action: 'REFRESH LIBRARY',
          onTap: _loadVideos,
        );
      }
      return RefreshIndicator(
        color: _primary,
        backgroundColor: _surface,
        onRefresh: _loadVideos,
        child: _grid
            ? GridView.builder(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12,
                  childAspectRatio: 1.18,
                ),
                itemCount: folders.length,
                itemBuilder: (context, index) => _FolderCard(
                  folder: folders[index],
                  grid: true,
                  onTap: () => _openFolder(folders[index]),
                  onDelete: () => _deleteFolderVideos(folders[index]),
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                itemCount: folders.length,
                itemBuilder: (context, index) => _FolderCard(
                  folder: folders[index],
                  onTap: () => _openFolder(folders[index]),
                  onDelete: () => _deleteFolderVideos(folders[index]),
                ),
              ),
      );
    }
    if (items.isEmpty) {
      return _VideoEmptyState(
        icon: _favoritesOnly ? Icons.favorite_border_rounded : Icons.movie_creation_outlined,
        title: _favoritesOnly ? 'NO FAVOURITES YET' : 'NO VIDEOS FOUND',
        message: _favoritesOnly ? 'Tap the heart on any video to add it to your favourites.' : 'Videos saved on your phone will appear here automatically.',
        action: 'REFRESH LIBRARY',
        onTap: _loadVideos,
      );
    }
    return RefreshIndicator(
      color: _primary, backgroundColor: _surface, onRefresh: _loadVideos,
      child: _grid
          ? GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 13, childAspectRatio: 1.06),
              itemCount: items.length,
              itemBuilder: (context, index) => _VideoCard(
                asset: items[index], favorite: _favorites.contains(items[index].id),
                onTap: () => _openVideo(items[index]), onFavorite: () => _toggleFavorite(items[index].id),
                onDelete: () => _deleteVideo(items[index]),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) => _VideoListTile(
                asset: items[index], favorite: _favorites.contains(items[index].id),
                onTap: () => _openVideo(items[index]), onFavorite: () => _toggleFavorite(items[index].id),
                onDelete: () => _deleteVideo(items[index]),
              ),
            ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(30), onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: active ? const LinearGradient(colors: [_primary, _secondary]) : null,
        color: active ? null : Colors.white.withValues(alpha: .055),
        border: Border.all(color: active ? Colors.transparent : Colors.white.withValues(alpha: .08)),
        boxShadow: active ? [BoxShadow(color: _primary.withValues(alpha: .20), blurRadius: 12)] : const [],
      ),
      child: Text(label, style: TextStyle(color: active ? Colors.black : _muted, fontSize: 11, fontWeight: FontWeight.w900)),
    ),
  );
}

class _FolderCard extends StatelessWidget {
  final AssetPathEntity folder;
  final VoidCallback onTap;
  final bool grid;
  final VoidCallback onDelete;
  const _FolderCard({required this.folder, required this.onTap, required this.onDelete, this.grid = false});

  @override
  Widget build(BuildContext context) {
    final icon = Container(
      width: grid ? 54 : 48,
      height: grid ? 54 : 48,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(colors: [_primary, _secondary]),
      ),
      child: Icon(grid ? Icons.video_library_rounded : Icons.folder_rounded,
          color: _white, size: grid ? 30 : 27),
    );
    if (!grid) {
      return Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: _surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _primary.withValues(alpha: .16)),
        ),
        child: ListTile(
          onTap: onTap,
          leading: icon,
          title: Text(folder.name, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _white, fontWeight: FontWeight.w800, fontSize: 13)),
          subtitle: FutureBuilder<int>(
            future: folder.assetCountAsync,
            builder: (context, snapshot) => Text('${snapshot.data ?? 0} videos',
              style: const TextStyle(color: _muted, fontSize: 11)),
          ),
          trailing: IconButton(
            tooltip: 'Delete folder videos',
            onPressed: onDelete,
            icon: const Icon(Icons.delete_outline_rounded, color: Color(0xFFFF7180)),
          ),
        ),
      );
    }
    return Material(
      color: _surface,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _primary.withValues(alpha: .18)),
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [_surface2.withValues(alpha: .92), _surface]),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [
                icon,
                const Spacer(),
                IconButton(
                  tooltip: 'Delete folder videos',
                  onPressed: onDelete,
                  style: IconButton.styleFrom(backgroundColor: Colors.black.withValues(alpha: .35)),
                  icon: const Icon(Icons.delete_outline_rounded, color: Color(0xFFFF7180), size: 20),
                ),
              ]),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(folder.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                FutureBuilder<int>(
                  future: folder.assetCountAsync,
                  builder: (context, snapshot) => Text('${snapshot.data ?? 0} VIDEOS',
                    style: const TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.0)),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}

Future<int> _savedVideoPositionMs(String assetId) async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getInt('vortex_resume_$assetId') ?? 0;
}

class _VideoCard extends StatelessWidget {
  final AssetEntity asset;
  final bool favorite;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  final VoidCallback onDelete;
  const _VideoCard({required this.asset, required this.favorite, required this.onTap, required this.onFavorite, required this.onDelete});

  @override
  Widget build(BuildContext context) => Material(
    color: _surface,
    borderRadius: BorderRadius.circular(18),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Stack(fit: StackFit.expand, children: [
          AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover),
          const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0x99000000)]))),
          Center(child: Container(width: 43, height: 43, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black.withValues(alpha: .50), border: Border.all(color: _primary.withValues(alpha: .8), width: 1.2), boxShadow: [BoxShadow(color: _primary.withValues(alpha: .25), blurRadius: 16)]), child: const Icon(Icons.play_arrow_rounded, color: _white, size: 28))),
          Positioned(left: 9, bottom: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4), decoration: BoxDecoration(color: Colors.black.withValues(alpha: .70), borderRadius: BorderRadius.circular(7)), child: Text(_formatDuration(asset.duration), style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w800)))),
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: FutureBuilder<int>(
              future: _savedVideoPositionMs(asset.id),
              builder: (context, snapshot) {
                final saved = snapshot.data ?? 0;
                final totalMs = asset.duration * 1000;
                if (saved <= 1500 || totalMs <= 0) return const SizedBox(height: 3);
                final ratio = (saved / totalMs).clamp(0.0, 1.0).toDouble();
                return LinearProgressIndicator(value: ratio, minHeight: 3, backgroundColor: Colors.white24, valueColor: const AlwaysStoppedAnimation<Color>(_primary));
              },
            ),
          ),
          Positioned(right: 5, top: 5, child: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(onPressed: onFavorite, constraints: const BoxConstraints(minWidth: 42, minHeight: 42), padding: const EdgeInsets.all(9), style: IconButton.styleFrom(backgroundColor: Colors.black.withValues(alpha: .48)), icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: favorite ? _primary : _white, size: 18)),
            PopupMenuButton<String>(
              tooltip: 'Video actions',
              color: _surface2,
              onSelected: (value) { if (value == 'delete') onDelete(); },
              itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: ListTile(dense: true, leading: Icon(Icons.delete_outline_rounded, color: Color(0xFFFF7180)), title: Text('Delete video')))],
              icon: const Icon(Icons.more_vert_rounded, color: _white, size: 21),
            ),
          ])),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w700)),
          FutureBuilder<int>(
            future: _savedVideoPositionMs(asset.id),
            builder: (context, snapshot) {
              final saved = snapshot.data ?? 0;
              final totalMs = asset.duration * 1000;
              if (saved <= 1500 || totalMs <= 0 || saved >= totalMs - 3000) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text('Watched until ${_formatClock(Duration(milliseconds: saved))}', style: const TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w700)),
              );
            },
          ),
        ])),
      ]),
    ),
  );
}

class _VideoListTile extends StatelessWidget {
  final AssetEntity asset;
  final bool favorite;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  final VoidCallback onDelete;
  const _VideoListTile({required this.asset, required this.favorite, required this.onTap, required this.onFavorite, required this.onDelete});
  @override
  Widget build(BuildContext context) => Material(
    color: _surface, borderRadius: BorderRadius.circular(16), clipBehavior: Clip.antiAlias,
    child: ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.all(7),
      leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: SizedBox(width: 82, height: 58, child: Stack(fit: StackFit.expand, children: [AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover), const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 27))]))),
      title: Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w800)),
      subtitle: FutureBuilder<int>(
        future: _savedVideoPositionMs(asset.id),
        builder: (context, snapshot) {
          final saved = snapshot.data ?? 0;
          final totalMs = asset.duration * 1000;
          final watched = saved > 1500 && totalMs > 0 && saved < totalMs - 3000;
          return Text(
            watched
                ? '${_formatDuration(asset.duration)}  •  Watched until ${_formatClock(Duration(milliseconds: saved))}'
                : '${_formatDuration(asset.duration)}  •  ${_formatDate(asset.createDateTime)}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: watched ? _primary : _muted, fontSize: 11),
          );
        },
      ),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(onPressed: onFavorite, icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: favorite ? _primary : _muted, size: 19)),
        PopupMenuButton<String>(
          tooltip: 'Video actions',
          color: _surface2,
          onSelected: (value) { if (value == 'delete') onDelete(); },
          itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: ListTile(dense: true, leading: Icon(Icons.delete_outline_rounded, color: Color(0xFFFF7180)), title: Text('Delete video')))],
          icon: const Icon(Icons.more_vert_rounded, color: _muted),
        ),
      ]),
    ),
  );
}

class _VideoEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String action;
  final VoidCallback onTap;
  const _VideoEmptyState({required this.icon, required this.title, required this.message, required this.action, required this.onTap});
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(30),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 86, height: 86, decoration: BoxDecoration(shape: BoxShape.circle, color: _surface2, border: Border.all(color: _primary.withValues(alpha: .24)), boxShadow: [BoxShadow(color: _secondary.withValues(alpha: .13), blurRadius: 24)]), child: Icon(icon, color: _primary, size: 39)),
      const SizedBox(height: 18),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
      const SizedBox(height: 9),
      Text(message, textAlign: TextAlign.center, style: const TextStyle(color: _muted, height: 1.5, fontSize: 11)),
      const SizedBox(height: 18),
      FilledButton(onPressed: onTap, style: FilledButton.styleFrom(backgroundColor: _primary, foregroundColor: _white, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)), child: Text(action, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1))),
    ]),
  ));
}

