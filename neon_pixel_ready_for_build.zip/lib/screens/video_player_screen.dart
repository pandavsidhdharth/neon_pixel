part of '../main.dart';

class VideoPlayerPage extends StatefulWidget {
  final AssetEntity asset;
  final List<AssetEntity> playlist;
  final int initialIndex;
  final int initialPositionMs;
  final bool Function(String) isFavorite;
  final bool initiallyFavorite;
  final void Function(String) onFavorite;
  final Future<void> Function(List<AssetEntity>) onShare;

  const VideoPlayerPage({
    super.key,
    required this.asset,
    required this.playlist,
    required this.initialIndex,
    required this.initialPositionMs,
    required this.isFavorite,
    required this.initiallyFavorite,
    required this.onFavorite,
    required this.onShare,
  });

  @override
  State<VideoPlayerPage> createState() => _VideoPlayerPageState();
}

class _VideoPlayerPageState extends State<VideoPlayerPage> with WidgetsBindingObserver {
  late AssetEntity _currentAsset;
  late int _currentIndex;
  bool _locked = false;
  int _fitMode = 0; // Safe default: CONTAIN, so portrait never crops video.
  bool _userSelectedFit = false;
  Orientation? _lastFitOrientation;
  Player? _player;
  VideoController? _videoController;
  StreamSubscription<bool>? _playingSubscription;
  StreamSubscription<String>? _errorSubscription;
  StreamSubscription<bool>? _completedSubscription;
  Timer? _progressSaveTimer;
  String? _error;
  bool _loading = true;
  bool _isMuted = false;
  int _initialPositionMs = 0;
  bool _favorite = false;
  double _volume = 1.0; // 0..1 system volume; >1 applies player-side gain.
  double _volumeBeforeMute = 0.7;
  bool _volumeInitialised = false;
  double _speed = 1.0;
  double _temporarySpeedValue = 2.0;
  double _subtitleScale = 1.25;
  double _subtitlePosition = 95.0; // 0 = higher on screen, 100 = near bottom.
  bool _subtitleMoveMode = true;
  int _seekIntervalSeconds = 5;
  int _repeatMode = 0; // 0 off, 1 one, 2 all.
  bool _settingsLoaded = false;
  bool _isSwitchingVideo = false;
  bool _completionHandled = false;
  bool _forceLandscape = false;
  Duration? _dragPosition;
  bool _controlsVisible = true;
  bool _showRemainingTime = false;
  Timer? _controlsTimer;

  // Gesture controls: left-side vertical drag = brightness, right-side = volume.
  static const MethodChannel _brightnessChannel = MethodChannel('vortex_player/brightness');
  static const MethodChannel _systemVolumeChannel = MethodChannel('vortex_player/system_volume');
  static const MethodChannel _fileChannel = MethodChannel('vortex_player/files');
  double _brightness = 0.5;
  double _gestureStartValue = 0.5;
  double _gestureStartY = 0.0;
  double _subtitleDragStartValue = 95.0;
  String? _gestureKind;
  bool _temporarySpeedActive = false;
  bool _showGestureHud = false;
  String _gestureHudText = '';
  Timer? _gestureHudTimer;
  Timer? _sideGestureTimer;
  Timer? _speedHudTimer;
  bool _showSideGestureHud = false;
  String? _sideGestureKind;
  bool _showTopSpeedHud = false;
  String _topSpeedHudText = '2×';
  double _horizontalDragDx = 0.0;
  Duration _horizontalStartPosition = Duration.zero;
  Offset? _doubleTapPosition;
  List<int> _bookmarks = [];
  Timer? _sleepTimer;
  int? _sleepTimerMinutes;
  DateTime? _sleepTimerEndsAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _audioFocusChannel.setMethodCallHandler((call) async {
      if (call.method == 'focusLost') {
        final activePlayer = _player;
        if (activePlayer != null && activePlayer.state.playing) {
          await activePlayer.pause();
          await _savePlaybackProgress();
          await _abandonAudioFocus();
        }
      }
    });
    _currentAsset = widget.asset;
    _currentIndex = widget.playlist.isEmpty ? 0 : widget.initialIndex.clamp(0, widget.playlist.length - 1).toInt();
    _favorite = widget.initiallyFavorite;
    _initialPositionMs = widget.initialPositionMs;
    unawaited(_loadBookmarks());
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _readSystemBrightness();
    _initialiseVideo();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final orientation = MediaQuery.of(context).orientation;
    if (_lastFitOrientation != orientation) {
      _lastFitOrientation = orientation;
      if (!_userSelectedFit) _fitMode = orientation == Orientation.portrait ? 0 : 1;
    }
  }

  Future<void> _loadBookmarks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final values = (prefs.getStringList('vortex_bookmarks_${_currentAsset.id}') ?? [])
          .map((value) => int.tryParse(value))
          .whereType<int>()
          .toSet()
          .toList()
        ..sort();
      if (mounted) setState(() => _bookmarks = values);
    } catch (_) {}
  }

  Future<void> _addBookmark() async {
    final player = _player;
    if (player == null) return;
    final ms = player.state.position.inMilliseconds;
    if (ms < 1000) {
      _showPlayerMessage('Play the video for a moment before bookmarking.');
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final key = 'vortex_bookmarks_${_currentAsset.id}';
    final values = (prefs.getStringList(key) ?? [])
        .map((value) => int.tryParse(value))
        .whereType<int>()
        .toSet();
    if (!values.any((value) => (value - ms).abs() < 2500)) values.add(ms);
    final sorted = values.toList()..sort();
    await prefs.setStringList(key, sorted.map((value) => value.toString()).toList());
    if (mounted) setState(() => _bookmarks = sorted);
    _showPlayerMessage('Bookmark saved at ${_formatClock(Duration(milliseconds: ms))}.');
  }

  Future<void> _openBookmarks() async {
    if (_bookmarks.isEmpty) {
      _showPlayerMessage('No bookmarks saved for this video yet.');
      return;
    }
    _cancelControlsTimer();
    final selected = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: _surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8))),
            const SizedBox(height: 16),
            const Align(alignment: Alignment.centerLeft, child: Text('BOOKMARKS', style: TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5))),
            const SizedBox(height: 8),
            ..._bookmarks.reversed.map((ms) => ListTile(
              dense: true,
              leading: const Icon(Icons.bookmark_rounded, color: _primary),
              title: Text(_formatClock(Duration(milliseconds: ms)), style: const TextStyle(color: _white, fontWeight: FontWeight.w800)),
              subtitle: const Text('Tap to jump to this point', style: TextStyle(color: _muted, fontSize: 11)),
              trailing: IconButton(
                tooltip: 'Delete bookmark',
                icon: const Icon(Icons.delete_outline_rounded, color: Color(0xFFFF7180)),
                onPressed: () async {
                  final updated = List<int>.from(_bookmarks)..remove(ms);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setStringList('vortex_bookmarks_${_currentAsset.id}', updated.map((v) => v.toString()).toList());
                  if (mounted) setState(() => _bookmarks = updated);
                  if (sheetContext.mounted) Navigator.pop(sheetContext);
                  if (mounted) _openBookmarks();
                },
              ),
              onTap: () => Navigator.pop(sheetContext, ms),
            )),
          ]),
        ),
      ),
    );
    if (!mounted) return;
    if (selected != null && _player != null) {
      await _player!.seek(Duration(milliseconds: selected));
      await _savePlaybackProgress();
      if (mounted) setState(() => _controlsVisible = true);
      _scheduleControlsHide();
    } else {
      _scheduleControlsHide();
    }
  }

  Future<void> _chooseSleepTimer() async {
    _cancelControlsTimer();
    final selected = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: _surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8))),
            const SizedBox(height: 16),
            const Align(alignment: Alignment.centerLeft, child: Text('SLEEP TIMER', style: TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5))),
            const SizedBox(height: 8),
            ...[0, 15, 30, 45, 60, 90].map((minutes) => ListTile(
              dense: true,
              leading: Icon(minutes == 0 ? Icons.timer_off_rounded : Icons.bedtime_rounded, color: _primary),
              title: Text(minutes == 0 ? 'Turn off timer' : '$minutes minutes', style: const TextStyle(color: _white)),
              trailing: _sleepTimerMinutes == minutes ? const Icon(Icons.check_circle_rounded, color: _primary) : null,
              onTap: () => Navigator.pop(sheetContext, minutes),
            )),
          ]),
        ),
      ),
    );
    if (!mounted) return;
    if (selected == null) { _scheduleControlsHide(); return; }
    _sleepTimer?.cancel();
    if (selected == 0) {
      _sleepTimerEndsAt = null;
      if (mounted) setState(() => _sleepTimerMinutes = null);
      _showPlayerMessage('Sleep timer turned off.');
    } else {
      _sleepTimerEndsAt = DateTime.now().add(Duration(minutes: selected));
      if (mounted) setState(() => _sleepTimerMinutes = selected);
      _sleepTimer = Timer.periodic(const Duration(seconds: 1), (timer) async {
        final remaining = _sleepTimerEndsAt?.difference(DateTime.now()) ?? Duration.zero;
        if (remaining <= Duration.zero) {
          timer.cancel();
          _sleepTimerEndsAt = null;
          await _player?.pause();
          await _savePlaybackProgress();
          if (!mounted) return;
          setState(() { _sleepTimerMinutes = null; _controlsVisible = true; });
          _cancelControlsTimer();
          _showPlayerMessage('Sleep timer paused playback.');
        } else if (mounted) {
          setState(() {});
        }
      });
      _showPlayerMessage('Playback will pause in $selected minutes.');
    }
    _scheduleControlsHide();
  }

  Future<void> _showPlayingQueue() async {
    if (widget.playlist.isEmpty) return;
    _cancelControlsTimer();
    final index = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: _surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .62,
          child: Column(children: [
            const SizedBox(height: 12),
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8))),
            const Padding(padding: EdgeInsets.fromLTRB(18, 16, 18, 10), child: Align(alignment: Alignment.centerLeft, child: Text('PLAYING QUEUE', style: TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5)))),
            Expanded(child: ListView.builder(
              itemCount: widget.playlist.length,
              itemBuilder: (context, i) {
                final asset = widget.playlist[i];
                return ListTile(
                  selected: i == _currentIndex,
                  leading: ClipRRect(borderRadius: BorderRadius.circular(8), child: SizedBox(width: 62, height: 42, child: AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover))),
                  title: Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: i == _currentIndex ? _primary : _white, fontSize: 12, fontWeight: FontWeight.w700)),
                  subtitle: Text(_formatDuration(asset.duration), style: const TextStyle(color: _muted, fontSize: 11)),
                  trailing: i == _currentIndex ? const Icon(Icons.equalizer_rounded, color: _primary) : null,
                  onTap: () => Navigator.pop(sheetContext, i),
                );
              },
            )),
          ]),
        ),
      ),
    );
    if (!mounted) return;
    if (index != null && index != _currentIndex) await _playQueueIndex(index);
    _scheduleControlsHide();
  }

  Future<void> _playQueueIndex(int index, {bool askResume = true}) async {
    if (index < 0 || index >= widget.playlist.length || _isSwitchingVideo) return;
    _isSwitchingVideo = true;
    try {
      await _savePlaybackProgress();
      final asset = widget.playlist[index];
      final prefs = await SharedPreferences.getInstance();
      final savedMs = prefs.getInt('vortex_resume_${asset.id}') ?? 0;
      final durationMs = asset.duration * 1000;
      final hasProgress = savedMs > 3000 && (durationMs <= 0 || savedMs < durationMs - 3000);
      var startMs = askResume || hasProgress ? (hasProgress ? savedMs : 0) : 0;
      if (askResume && hasProgress) {
        final choice = await _showResumePrompt(context, savedMs);
        if (choice == null || !mounted) return;
        startMs = choice;
      }
      if (!mounted) return;
      setState(() {
        _currentIndex = index;
        _currentAsset = asset;
        _initialPositionMs = startMs;
        _favorite = widget.isFavorite(asset.id);
        _controlsVisible = true;
      });
      await _initialiseVideo();
    } finally {
      _isSwitchingVideo = false;
    }
  }

  void _showPlayerMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)));
  }

  Future<void> _loadPlayerSettings() async {
    if (_settingsLoaded) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      _speed = (prefs.getDouble('vortex_playback_speed') ?? 1.0).clamp(0.5, 4.0).toDouble();
      _subtitleScale = (prefs.getDouble('vortex_subtitle_scale') ?? 1.25).clamp(0.6, 2.5).toDouble();
      _subtitlePosition = (prefs.getDouble('vortex_subtitle_position') ?? 95.0).clamp(0.0, 100.0).toDouble();
      _subtitleMoveMode = prefs.getBool('vortex_subtitle_drag_enabled') ?? true;
      _seekIntervalSeconds = (prefs.getInt('vortex_swipe_seek_seconds') ?? 5).clamp(5, 60).toInt();
      _repeatMode = (prefs.getInt('vortex_repeat_mode') ?? 0).clamp(0, 2).toInt();
      _userSelectedFit = prefs.containsKey('vortex_fit_mode');
      _fitMode = (prefs.getInt('vortex_fit_mode') ?? 0).clamp(0, 2).toInt();
      final savedBoost = prefs.getDouble('vortex_volume_boost') ?? 1.0;
      if (savedBoost > 1.0) {
        _volume = savedBoost.clamp(1.0, 2.0).toDouble();
        _volumeBeforeMute = 1.0;
        _volumeInitialised = true;
      }
    } catch (_) {}
    _settingsLoaded = true;
  }

  Future<void> _handleVideoCompleted(Player completedPlayer) async {
    if (_isSwitchingVideo || !mounted || !identical(_player, completedPlayer)) return;
    if (_repeatMode == 1) {
      await completedPlayer.seek(Duration.zero);
      await completedPlayer.play();
      _completionHandled = false;
      return;
    }
    final completedIndex = _currentIndex;
    final nextIndex = completedIndex + 1;
    if (nextIndex < widget.playlist.length) {
      // Advance exactly one entry in the current folder/queue after each completion.
      await _playQueueIndex(nextIndex, askResume: false);
    } else if (_repeatMode == 2 && widget.playlist.isNotEmpty) {
      await _playQueueIndex(0, askResume: false);
    } else {
      await _savePlaybackProgress();
      await _abandonAudioFocus();
      if (mounted) setState(() => _controlsVisible = true);
    }
  }

  Future<void> _cycleRepeatMode() async {
    final next = (_repeatMode + 1) % 3;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('vortex_repeat_mode', next);
    if (mounted) setState(() => _repeatMode = next);
    _showPlayerMessage(['Repeat off', 'Repeat one', 'Repeat all'][next]);
  }

  Future<void> _toggleRotation() async {
    _forceLandscape = !_forceLandscape;
    await SystemChrome.setPreferredOrientations(_forceLandscape
        ? const [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]
        : const [DeviceOrientation.portraitUp]);
    if (mounted) setState(() {});
  }

  Future<void> _loadExternalSubtitle(Player player) async {
    try {
      final path = await _fileChannel.invokeMethod<String>('pickSubtitleFile');
      if (path == null || path.isEmpty || !mounted) return;
      final title = path.split('/').last;
      await player.setSubtitleTrack(SubtitleTrack.uri(Uri.file(path).toString(), title: title));
      _showPlayerMessage('Subtitle loaded: $title');
    } on PlatformException catch (e) {
      _showPlayerMessage('Could not load subtitle: ${e.message ?? e.code}');
    } catch (e) {
      _showPlayerMessage('Could not load subtitle: $e');
    }
  }

  Future<void> _readSystemBrightness() async {
    try {
      final value = await _brightnessChannel.invokeMethod<double>('getSystemBrightness');
      if (mounted && value != null) {
        setState(() => _brightness = value.clamp(0.05, 1.0).toDouble());
      }
    } catch (_) {
      // Brightness gestures remain unavailable if the native channel is unavailable.
    }
  }

  Future<void> _applyScreenBrightness(double value) async {
    try {
      await _brightnessChannel.invokeMethod<void>('setBrightness', {'value': value});
    } catch (_) {
      // Keep video playback working even if a device rejects brightness changes.
    }
  }

  Future<void> _resetScreenBrightness() async {
    try {
      await _brightnessChannel.invokeMethod<void>('resetBrightness');
    } catch (_) {}
  }

  void _showGestureMessage(String message) {
    _gestureHudTimer?.cancel();
    _sideGestureTimer?.cancel();
    if (mounted) {
      setState(() {
        _showGestureHud = true;
        _showSideGestureHud = false;
        _gestureHudText = message;
      });
    }
    _gestureHudTimer = Timer(const Duration(milliseconds: 1100), () {
      if (mounted && _gestureKind == null && !_temporarySpeedActive) {
        setState(() => _showGestureHud = false);
      }
    });
  }

  void _cancelControlsTimer() {
    _controlsTimer?.cancel();
    _controlsTimer = null;
  }

  void _scheduleControlsHide() {
    _cancelControlsTimer();
    final player = _player;
    if (!mounted || !_controlsVisible || player == null || !player.state.playing || _dragPosition != null || _gestureKind != null || _temporarySpeedActive) {
      return;
    }
    _controlsTimer = Timer(const Duration(seconds: 3), () {
      if (!mounted) return;
      final current = _player;
      if (current != null && current.state.playing && _dragPosition == null) {
        setState(() => _controlsVisible = false);
      }
    });
  }

  void _toggleControls() {
    if (!_controlsVisible) {
      setState(() => _controlsVisible = true);
      _scheduleControlsHide();
    } else if (_player?.state.playing == true) {
      _cancelControlsTimer();
      setState(() => _controlsVisible = false);
    } else {
      _cancelControlsTimer();
      setState(() => _controlsVisible = true);
    }
  }

  Future<void> _initialiseVideo() async {
    _cancelControlsTimer();
    _bookmarks = [];
    unawaited(_loadBookmarks());
    _progressSaveTimer?.cancel();
    await _loadPlayerSettings();
    final previous = _player;
    _player = null;
    _videoController = null;
    await _playingSubscription?.cancel();
    await _errorSubscription?.cancel();
    await _completedSubscription?.cancel();
    if (previous != null) {
      await previous.dispose();
    }
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
      _controlsVisible = true;
    });

    Player? pendingPlayer;
    try {
      final file = await _currentAsset.file;
      if (file == null) throw Exception('Video file unavailable');

      // media_kit uses bundled libmpv/FFmpeg decoders rather than relying only
      // on Android's built-in codecs, allowing formats such as E-AC-3 (EAC3).
      final player = Player();
      pendingPlayer = player;
      final videoController = VideoController(player);
      _player = player;
      _videoController = videoController;

      _completionHandled = false;
      if (!_volumeInitialised) {
        try {
          _volume = (await _systemVolumeChannel.invokeMethod<double>('getSystemVolume') ?? 1.0).clamp(0.0, 1.0).toDouble();
        } catch (_) { _volume = 1.0; }
        _volumeBeforeMute = _volume;
        _volumeInitialised = true;
      }
      _isMuted = _volume <= 0.001;
      if (player.platform is NativePlayer) {
        final nativePlayer = player.platform as NativePlayer;
        try {
          await nativePlayer.setProperty('volume-max', '200');
        } catch (_) {
          // Playback remains available even if this mpv build cannot raise its volume ceiling.
        }
      }
      await player.setVolume(_volume > 1.0 ? _volume * 100.0 : 100.0);
      await player.setRate(_speed);

      _playingSubscription = player.stream.playing.listen((playing) {
        if (!mounted) return;
        if (playing) {
          _scheduleControlsHide();
        } else {
          _cancelControlsTimer();
          if (!_controlsVisible) setState(() => _controlsVisible = true);
        }
      });
      _errorSubscription = player.stream.error.listen((message) {
        if (!mounted || message.trim().isEmpty) return;
        setState(() {
          _error = 'આ વિડિયો ચલાવવામાં સમસ્યા આવી: $message';
          _loading = false;
        });
      });
      _completedSubscription = player.stream.completed.listen((completed) {
        if (completed && mounted && identical(_player, player) && !_completionHandled) {
          _completionHandled = true;
          unawaited(_handleVideoCompleted(player));
        }
      });

      await player.open(Media(file.path), play: false);
      // Wait for the media duration to become available before seeking. Seeking
      // immediately after open can be ignored by some demuxers on slower phones.
      var mediaDuration = player.state.duration;
      if (mediaDuration <= Duration.zero) {
        try {
          mediaDuration = await player.stream.duration
              .firstWhere((value) => value > Duration.zero)
              .timeout(const Duration(seconds: 6));
        } catch (_) {
          mediaDuration = player.state.duration;
        }
      }
      final prefs = await SharedPreferences.getInstance();
      final requestedMs = _initialPositionMs < 0 ? 0 : _initialPositionMs;
      final nearlyFinished = mediaDuration > Duration.zero &&
          Duration(milliseconds: requestedMs) >= mediaDuration - const Duration(seconds: 3);
      final boundedMs = mediaDuration > Duration.zero
          ? requestedMs.clamp(0, (mediaDuration - const Duration(seconds: 2)).inMilliseconds.clamp(0, 1 << 62)).toInt()
          : requestedMs;
      final startMs = nearlyFinished ? 0 : boundedMs;
      if (startMs > 1500) {
        final targetPosition = Duration(milliseconds: startMs);
        await player.seek(targetPosition);
        await Future.delayed(const Duration(milliseconds: 350));
        if ((player.state.position - targetPosition).inMilliseconds.abs() > 2500) {
          await player.seek(targetPosition);
          await Future.delayed(const Duration(milliseconds: 250));
        }
      }
      await prefs.setInt('vortex_resume_${_currentAsset.id}', startMs);
      await prefs.setString('vortex_last_asset_id', _currentAsset.id);
      await prefs.setString('vortex_last_asset_title', _currentAsset.title ?? 'Last played video');
      await prefs.setInt('vortex_last_position_ms', startMs);
      _initialPositionMs = startMs;
      await _requestAudioFocus();
      await player.play();
      if (!mounted) {
        await player.dispose();
        return;
      }
      setState(() => _loading = false);
      _progressSaveTimer = Timer.periodic(const Duration(seconds: 2), (_) {
        unawaited(_savePlaybackProgress());
      });
      _scheduleControlsHide();
    } catch (e) {
      await _playingSubscription?.cancel();
      await _errorSubscription?.cancel();
      await _completedSubscription?.cancel();
      if (pendingPlayer != null) {
        await pendingPlayer.dispose();
      }
      if (mounted) {
        setState(() {
          _player = null;
          _videoController = null;
          _loading = false;
          _error = 'આ વિડિયો ખોલી શકાયો નથી. ફાઇલ અથવા video format તપાસો. ($e)';
        });
      }
    }
  }

  Future<void> _requestAudioFocus() async {
    try { await _audioFocusChannel.invokeMethod<bool>('request'); } catch (_) {}
  }

  Future<void> _abandonAudioFocus() async {
    try { await _audioFocusChannel.invokeMethod<void>('abandon'); } catch (_) {}
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      final player = _player;
      if (player?.state.playing == true) unawaited(player!.pause());
      unawaited(_savePlaybackProgress());
      unawaited(_abandonAudioFocus());
    }
  }

  Future<void> _savePlaybackProgress() async {
    final player = _player;
    if (player == null) return;
    final assetId = _currentAsset.id;
    final assetTitle = _currentAsset.title ?? 'Last played video';
    final position = player.state.position;
    final duration = player.state.duration;
    final completed = duration > Duration.zero &&
        position >= duration - const Duration(seconds: 3);
    final safeMs = completed ? 0 : position.inMilliseconds.clamp(0, 1 << 62).toInt();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('vortex_resume_$assetId', safeMs);
      await prefs.setString('vortex_last_asset_id', assetId);
      await prefs.setString('vortex_last_asset_title', assetTitle);
      await prefs.setInt('vortex_last_position_ms', safeMs);
      final recent = prefs.getStringList('vortex_recent_asset_ids') ?? <String>[];
      recent.remove(assetId);
      recent.insert(0, assetId);
      await prefs.setStringList('vortex_recent_asset_ids', recent.take(20).toList());
    } catch (_) {
      // Resume data is best-effort; playback must continue even if storage fails.
    }
  }

  Future<void> _setVolume(double value) async {
    final player = _player;
    if (player == null) return;
    final requested = value.clamp(0.0, 2.0).toDouble();
    var actual = requested;
    try {
      final systemTarget = requested.clamp(0.0, 1.0).toDouble();
      final systemActual = await _systemVolumeChannel.invokeMethod<double>(
        'setSystemVolume', {'value': systemTarget},
      );
      if (requested <= 1.0 && systemActual != null) actual = systemActual.clamp(0.0, 1.0).toDouble();
    } catch (_) {
      // If the OEM blocks system volume control, keep the player-side fallback.
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      if (actual > 1.0) {
        await prefs.setDouble('vortex_volume_boost', actual);
      } else {
        await prefs.remove('vortex_volume_boost');
      }
    } catch (_) {}
    if (mounted) {
      setState(() {
        _volume = actual;
        _isMuted = actual <= 0.001;
        if (actual > 0.001) _volumeBeforeMute = actual;
      });
    }
    await player.setVolume(actual > 1.0 ? actual * 100.0 : 100.0);
    _scheduleControlsHide();
  }

  Future<void> _toggleMute() async {
    if (_isMuted) {
      await _setVolume(_volumeBeforeMute.clamp(0.05, 1.0).toDouble());
    } else {
      _volumeBeforeMute = _volume.clamp(0.05, 1.0).toDouble();
      await _setVolume(0.0);
    }
    _scheduleControlsHide();
  }

  Future<void> _togglePlay() async {
    final player = _player;
    if (player == null) return;
    if (player.state.playing) {
      await player.pause();
      await _savePlaybackProgress();
      await _abandonAudioFocus();
      _cancelControlsTimer();
      if (mounted) setState(() => _controlsVisible = true);
    } else {
      if (player.state.completed ||
          (player.state.duration > Duration.zero && player.state.position >= player.state.duration)) {
        await player.seek(Duration.zero);
      }
      await _requestAudioFocus();
      await player.play();
      if (mounted) {
        setState(() => _controlsVisible = true);
        _scheduleControlsHide();
      }
    }
  }

  Future<void> _playAdjacent(int delta) async {
    if (widget.playlist.isEmpty) return;
    final next = (_currentIndex + delta).clamp(0, widget.playlist.length - 1).toInt();
    if (next == _currentIndex) return;
    await _playQueueIndex(next);
  }

  Future<void> _cycleFitMode() async {
    final next = (_fitMode + 1) % 3;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('vortex_fit_mode', next);
    _userSelectedFit = true;
    if (mounted) setState(() => _fitMode = next);
    _showGestureMessage(['FIT: CONTAIN', 'FIT: FILL', 'FIT: 16:9'][next]);
  }

  void _toggleLock() {
    setState(() {
      _locked = !_locked;
      if (_locked) _controlsVisible = false;
      else _controlsVisible = true;
    });
    if (_locked) _cancelControlsTimer(); else _scheduleControlsHide();
  }

  Future<void> _skipBy(int seconds) async {
    final player = _player;
    if (player == null) return;
    final target = player.state.position + Duration(seconds: seconds);
    final max = player.state.duration;
    final clamped = target < Duration.zero ? Duration.zero : (target > max ? max : target);
    await player.seek(clamped);
    await _savePlaybackProgress();
    _scheduleControlsHide();
  }

  Future<void> _changeSpeed(double value) async {
    final player = _player;
    if (player == null) return;
    await player.setRate(value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('vortex_playback_speed', value);
    if (mounted) setState(() => _speed = value);
    _scheduleControlsHide();
  }

  void _onVideoVerticalDragStart(DragStartDetails details, double videoHeight) {
    final player = _player;
    final subtitleActive = player != null && player.state.track.subtitle.id != 'no';
    final screenWidth = MediaQuery.of(context).size.width;
    // Subtitle movement owns the center 64% of the screen at every vertical position.
    // Left/right edge swipes remain reserved for brightness and volume.
    final overSubtitleZone = details.localPosition.dx > screenWidth * 0.18 && details.localPosition.dx < screenWidth * 0.82;
    if (_subtitleMoveMode && subtitleActive && overSubtitleZone) {
      _gestureKind = 'subtitle_position';
      _gestureStartY = details.localPosition.dy;
      _subtitleDragStartValue = _subtitlePosition;
      _gestureHudTimer?.cancel();
      _cancelControlsTimer();
      setState(() {
        _controlsVisible = false;
        _showGestureHud = true;
        _showSideGestureHud = false;
        _gestureHudText = 'SUBTITLE  ${_subtitlePosition.round()}%';
      });
      return;
    }
    _gestureKind = details.localPosition.dx < screenWidth / 2 ? 'brightness' : 'volume';
    _sideGestureKind = _gestureKind;
    _gestureStartY = details.localPosition.dy;
    _gestureStartValue = _gestureKind == 'brightness' ? _brightness : _volume;
    _gestureHudTimer?.cancel();
    _sideGestureTimer?.cancel();
    _cancelControlsTimer();
    setState(() {
      _controlsVisible = false;
      _showGestureHud = false;
      _showSideGestureHud = true;
      _gestureHudText = _gestureKind == 'brightness'
          ? '☀  Brightness ${(_brightness * 100).round()}%'
          : '🔊  Volume ${(_volume * 100).round()}%';
    });
    unawaited(HapticFeedback.selectionClick());
  }

  void _onVideoVerticalDragUpdate(DragUpdateDetails details, double videoHeight) {
    if (_gestureKind == null) return;
    final delta = (_gestureStartY - details.localPosition.dy) / (videoHeight * 0.72).clamp(140.0, 520.0);
    if (_gestureKind == 'subtitle_position') {
      final next = (_subtitleDragStartValue - delta * 85.0).clamp(0.0, 100.0).toDouble();
      if ((next - _subtitlePosition).abs() >= 0.7) {
        setState(() {
          _subtitlePosition = next;
          _gestureHudText = 'SUBTITLE  ${next.round()}%';
          _showGestureHud = true;
        });
        unawaited(_setSubtitlePosition(next, persist: false));
      }
    } else if (_gestureKind == 'brightness') {
      final next = (_gestureStartValue + delta).clamp(0.05, 1.0).toDouble();
      if ((next - _brightness).abs() >= 0.012) {
        setState(() {
          _brightness = next;
          _gestureHudText = '☀  Brightness ${(next * 100).round()}%';
        });
        unawaited(_applyScreenBrightness(next));
      }
    } else {
      final next = (_gestureStartValue + delta * 2.0).clamp(0.0, 2.0).toDouble();
      if ((next - _volume).abs() >= 0.012) {
        _gestureHudText = next > 1.0
            ? '🔊  Volume Boost ${(next * 100).round()}%'
            : '🔊  System Volume ${(next * 100).round()}%';
        unawaited(_setVolume(next));
      }
    }
  }

  void _onVideoVerticalDragEnd(DragEndDetails details) {
    final endedKind = _gestureKind;
    _gestureKind = null;
    if (endedKind == 'subtitle_position') {
      unawaited(_setSubtitlePosition(_subtitlePosition));
      _showGestureMessage('Subtitle position ${_subtitlePosition.round()}%');
      return;
    }
    _sideGestureKind = endedKind;
    _sideGestureTimer?.cancel();
    _sideGestureTimer = Timer(const Duration(milliseconds: 950), () {
      if (mounted) setState(() => _showSideGestureHud = false);
    });
    _scheduleControlsHide();
  }

  void _onVideoHorizontalDragStart(DragStartDetails details) {
    _horizontalDragDx = 0;
    _horizontalStartPosition = _player?.state.position ?? Duration.zero;
    _cancelControlsTimer();
    _sideGestureTimer?.cancel();
    if (mounted) setState(() { _controlsVisible = false; _showGestureHud = false; _showSideGestureHud = false; });
  }

  int _horizontalSeekSeconds() {
    if (_horizontalDragDx.abs() < 35) return 0;
    final intervals = (_horizontalDragDx.abs() / 110).round().clamp(1, 20).toInt();
    return _horizontalDragDx.isNegative ? -intervals * _seekIntervalSeconds : intervals * _seekIntervalSeconds;
  }

  void _onVideoHorizontalDragUpdate(DragUpdateDetails details) {
    _horizontalDragDx += details.delta.dx;
    final seconds = _horizontalSeekSeconds();
    if (seconds == 0) return;
    if (mounted) {
      setState(() {
        _showGestureHud = true;
        _gestureHudText = seconds > 0 ? '⏩  +${seconds}s' : '⏪  ${seconds}s';
      });
    }
  }

  Future<void> _onVideoHorizontalDragEnd(DragEndDetails details) async {
    final seconds = _horizontalSeekSeconds();
    _horizontalDragDx = 0;
    final player = _player;
    if (player != null && seconds != 0) {
      final target = _horizontalStartPosition + Duration(seconds: seconds);
      final duration = player.state.duration;
      final clamped = target < Duration.zero
          ? Duration.zero
          : (duration > Duration.zero && target > duration ? duration : target);
      await player.seek(clamped);
      await _savePlaybackProgress();
      _showGestureMessage(seconds > 0 ? '⏩  +${seconds}s' : '⏪  ${seconds}s');
    } else {
      if (mounted) setState(() => _showGestureHud = false);
    }
    _scheduleControlsHide();
  }

  void _flashTopSpeedHud(String label) {
    _speedHudTimer?.cancel();
    if (!mounted) return;
    setState(() {
      _showTopSpeedHud = true;
      _topSpeedHudText = label;
    });
    _speedHudTimer = Timer(const Duration(milliseconds: 950), () {
      if (mounted) setState(() => _showTopSpeedHud = false);
    });
  }

  Future<void> _startTemporary2x(LongPressStartDetails details) async {
    final player = _player;
    if (player == null || _locked || _isSwitchingVideo) return;
    _temporarySpeedActive = true;
    _temporarySpeedValue = 2.0;
    _gestureHudTimer?.cancel();
    _sideGestureTimer?.cancel();
    _speedHudTimer?.cancel();
    await player.setRate(_temporarySpeedValue);
    if (!mounted) return;
    setState(() {
      _showGestureHud = false;
      _showSideGestureHud = false;
      _controlsVisible = false;
    });
    _flashTopSpeedHud('2×');
    _cancelControlsTimer();
    unawaited(HapticFeedback.heavyImpact());
  }

  void _updateTemporarySpeed(LongPressMoveUpdateDetails details) {
    if (!_temporarySpeedActive) return;
    final vertical = details.localOffsetFromOrigin.dy;
    final steps = (-vertical / 55.0).round();
    final next = (2.0 + steps * 0.5).clamp(1.0, 4.0).toDouble();
    if ((next - _temporarySpeedValue).abs() < 0.01) return;
    _temporarySpeedValue = next;
    final player = _player;
    if (player != null) unawaited(player.setRate(next));
    _flashTopSpeedHud('${next.toStringAsFixed(next == next.roundToDouble() ? 0 : 1)}×');
    unawaited(HapticFeedback.selectionClick());
  }

  Future<void> _endTemporary2x() async {
    if (!_temporarySpeedActive) return;
    _temporarySpeedActive = false;
    final player = _player;
    if (player != null) await player.setRate(1.0);
    _speed = 1.0;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('vortex_playback_speed', 1.0);
    } catch (_) {}
    if (!mounted) return;
    setState(() => _showGestureHud = false);
    _flashTopSpeedHud('1×');
    unawaited(HapticFeedback.selectionClick());
    _scheduleControlsHide();
  }

  String _audioTrackName(AudioTrack track) {
    if (track.id == 'no') return 'Off';
    final language = track.language?.trim();
    final title = track.title?.trim();
    final details = [if (language != null && language.isNotEmpty) language, if (title != null && title.isNotEmpty) title];
    return details.isEmpty ? 'Audio track ${track.id}' : details.join(' • ');
  }

  String _subtitleTrackName(SubtitleTrack track) {
    if (track.id == 'no') return 'Off';
    final language = track.language?.trim();
    final title = track.title?.trim();
    final details = [if (language != null && language.isNotEmpty) language, if (title != null && title.isNotEmpty) title];
    return details.isEmpty ? 'Subtitle ${track.id}' : details.join(' • ');
  }

  Future<void> _openAudioTrackSettings(Player player) async {
    _cancelControlsTimer();
    final audioTracks = player.state.tracks.audio;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 26),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 18),
            const Text('AUDIO SETTINGS', style: TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
            const SizedBox(height: 10),
            StatefulBuilder(builder: (context, setSheetState) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  const Expanded(child: Text('Volume / Audio boost', style: TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w700))),
                  Text('${(_volume * 100).round()}%', style: const TextStyle(color: _primary, fontSize: 12, fontWeight: FontWeight.w900)),
                ]),
                Slider(
                  value: _volume.clamp(0.0, 2.0).toDouble(), min: 0, max: 2, divisions: 20,
                  activeColor: _primary, inactiveColor: Colors.white24,
                  onChanged: (value) { setSheetState(() {}); unawaited(_setVolume(value)); },
                ),
                const SizedBox(height: 5),
                const Text('AUDIO TRACK', style: TextStyle(color: _primary, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              ],
            )),
            const SizedBox(height: 10),
            if (audioTracks.where((track) => track.id != 'auto' && track.id != 'no').isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('This video has only one audio track.', style: TextStyle(color: _muted, fontSize: 12)))
            else
              ...audioTracks.where((track) => track.id != 'auto').map((track) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.audiotrack_rounded, color: _primary),
                title: Text(_audioTrackName(track), style: const TextStyle(color: _white, fontSize: 13)),
                trailing: player.state.track.audio.id == track.id ? const Icon(Icons.check_circle_rounded, color: _primary) : null,
                onTap: () async {
                  await player.setAudioTrack(track);
                  if (mounted) setState(() {});
                  if (sheetContext.mounted) Navigator.pop(sheetContext);
                },
              )),
          ]),
        ),
      ),
    );
    _scheduleControlsHide();
  }

  Future<void> _openSubtitleTrackSettings(Player player) async {
    _cancelControlsTimer();
    final subtitleTracks = player.state.tracks.subtitle;
    var subtitlesEnabled = player.state.track.subtitle.id != 'no';
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: StatefulBuilder(builder: (context, setSheetState) => SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 26),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 18),
            Row(children: [
              const Icon(Icons.subtitles_rounded, color: _primary, size: 24),
              const SizedBox(width: 9),
              const Expanded(child: Text('SUBTITLE SETTINGS', style: TextStyle(color: _primary, fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1.3))),
              TextButton(onPressed: () => Navigator.pop(sheetContext), child: const Text('DONE')),
            ]),
            const SizedBox(height: 5),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              activeColor: _primary,
              title: const Text('Subtitles ON / OFF', style: TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w800)),
              subtitle: const Text('Show or hide the selected subtitle track', style: TextStyle(color: _muted, fontSize: 11)),
              value: subtitlesEnabled,
              onChanged: (enabled) async {
                setSheetState(() => subtitlesEnabled = enabled);
                try {
                  await player.setSubtitleTrack(enabled ? SubtitleTrack.auto() : SubtitleTrack.no());
                  if (mounted) setState(() {});
                } catch (e) {
                  setSheetState(() => subtitlesEnabled = !enabled);
                  _showPlayerMessage('Could not change subtitle visibility: $e');
                }
              },
            ),
            const Divider(color: Colors.white12),
            Row(children: [
              const Expanded(child: Text('Subtitle size', style: TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w800))),
              Text('${(_subtitleScale * 100).round()}%', style: const TextStyle(color: _primary, fontSize: 13, fontWeight: FontWeight.w900)),
            ]),
            Slider(
              value: _subtitleScale.clamp(0.6, 2.5).toDouble(), min: 0.6, max: 2.5, divisions: 19,
              activeColor: _primary, inactiveColor: Colors.white24,
              onChanged: (value) {
                setSheetState(() => _subtitleScale = value);
                unawaited(_setSubtitleScale(value, persist: false));
              },
              onChangeEnd: (value) => unawaited(_setSubtitleScale(value)),
            ),
            const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Small', style: TextStyle(color: _muted, fontSize: 11)),
              Text('Large', style: TextStyle(color: _muted, fontSize: 11)),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              const Expanded(child: Text('Subtitle vertical position', style: TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w800))),
              Text('${_subtitlePosition.round()}%', style: const TextStyle(color: _primary, fontSize: 13, fontWeight: FontWeight.w900)),
            ]),
            Slider(
              value: _subtitlePosition.clamp(0.0, 100.0).toDouble(), min: 0, max: 100, divisions: 20,
              activeColor: _primary, inactiveColor: Colors.white24,
              onChanged: (value) {
                setSheetState(() => _subtitlePosition = value);
                unawaited(_setSubtitlePosition(value, persist: false));
              },
              onChangeEnd: (value) => unawaited(_setSubtitlePosition(value)),
            ),
            const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Move higher', style: TextStyle(color: _muted, fontSize: 11)),
              Text('Near bottom', style: TextStyle(color: _muted, fontSize: 11)),
            ]),
            const SizedBox(height: 6),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              activeColor: _primary,
              title: const Text('Drag to move subtitles', style: TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w800)),
              subtitle: const Text('Swipe up or down in the middle of the video. Left/right edges stay for brightness and volume.', style: TextStyle(color: _muted, fontSize: 11)),
              value: _subtitleMoveMode,
              onChanged: (value) {
                setSheetState(() => _subtitleMoveMode = value);
                unawaited(_setSubtitleMoveMode(value));
              },
            ),
            const Divider(color: Colors.white12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.folder_open_rounded, color: _primary),
              title: const Text('Load external subtitle (.srt / .vtt)', style: TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w700)),
              onTap: () async {
                Navigator.pop(sheetContext);
                await _loadExternalSubtitle(player);
              },
            ),
            const SizedBox(height: 4),
            if (subtitleTracks.where((track) => track.id != 'auto' && track.id != 'no').isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('No embedded subtitles found. Load an external .srt or .vtt file.', style: TextStyle(color: _muted, fontSize: 12)))
            else ...[
              const Padding(padding: EdgeInsets.only(top: 4, bottom: 4), child: Text('AVAILABLE SUBTITLE TRACKS', style: TextStyle(color: _primary, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.2))),
              ...subtitleTracks.where((track) => track.id != 'auto' && track.id != 'no').map((track) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.subtitles_rounded, color: _primary),
                title: Text(_subtitleTrackName(track), style: const TextStyle(color: _white, fontSize: 13)),
                trailing: player.state.track.subtitle.id == track.id ? const Icon(Icons.check_circle_rounded, color: _primary) : null,
                onTap: () async {
                  await player.setSubtitleTrack(track);
                  setSheetState(() => subtitlesEnabled = true);
                  if (mounted) setState(() {});
                },
              )),
            ],
          ]),
        )),
      ),
    );
    _scheduleControlsHide();
  }


  Future<void> _setSubtitleScale(double value, {bool persist = true}) async {
    final next = value.clamp(0.6, 2.5).toDouble();
    if (mounted) setState(() => _subtitleScale = next);
    if (persist) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('vortex_subtitle_scale', next);
    }
  }

  Future<void> _setSubtitlePosition(double value, {bool persist = true}) async {
    final next = value.clamp(0.0, 100.0).toDouble();
    if (mounted && (_subtitlePosition - next).abs() > 0.001) setState(() => _subtitlePosition = next);
    if (persist) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('vortex_subtitle_position', next);
    }
  }

  Future<void> _setSubtitleMoveMode(bool enabled) async {
    if (mounted) setState(() => _subtitleMoveMode = enabled);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('vortex_subtitle_drag_enabled', enabled);
  }

  Future<void> _shareVideo() async {
    await widget.onShare([_currentAsset]);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cancelControlsTimer();
    _progressSaveTimer?.cancel();
    _sleepTimer?.cancel();
    _sleepTimerEndsAt = null;
    unawaited(_savePlaybackProgress());
    unawaited(_abandonAudioFocus());
    _audioFocusChannel.setMethodCallHandler(null);
    _gestureHudTimer?.cancel();
    _sideGestureTimer?.cancel();
    _speedHudTimer?.cancel();
    unawaited(_brightnessChannel.invokeMethod<void>('resetBrightness').catchError((_) {}));
    final player = _player;
    if (player != null) {
      unawaited(_playingSubscription?.cancel());
      unawaited(_errorSubscription?.cancel());
      unawaited(_completedSubscription?.cancel());
      unawaited(player.dispose());
    }
    SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Widget _compactControlButton({
    required IconData icon,
    required VoidCallback? onPressed,
    String? tooltip,
    Color color = Colors.white,
    double iconSize = 25,
    double width = 38,
    double height = 48,
  }) {
    return SizedBox(
      width: width,
      height: height,
      child: IconButton(
        tooltip: tooltip,
        onPressed: onPressed,
        padding: EdgeInsets.zero,
        constraints: BoxConstraints.tightFor(width: width, height: height),
        visualDensity: VisualDensity.standard,
        style: IconButton.styleFrom(
          backgroundColor: width > 44 ? _primary.withValues(alpha: .25) : const Color(0xB51B0710),
          shape: const CircleBorder(),
        ),
        icon: Icon(icon, color: onPressed == null ? Colors.white24 : color, size: iconSize),
      ),
    );
  }

  Widget _buildControls(Player player, Duration position, Duration duration, bool playing) {
    final shownPosition = _dragPosition ?? position;
    final totalMs = duration.inMilliseconds > 0 ? duration.inMilliseconds.toDouble() : 1.0;
    final progress = shownPosition.inMilliseconds.clamp(0, duration.inMilliseconds).toDouble();
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 2),
      child: SafeArea(
        top: false,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            Text(_formatClock(shownPosition), style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w800)),
            Expanded(child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                trackHeight: 4.6,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 9),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 17),
              ),
              child: Slider(
                value: progress.clamp(0.0, totalMs).toDouble(), min: 0, max: totalMs,
                activeColor: _primary, inactiveColor: Colors.white30,
                onChanged: (value) { _cancelControlsTimer(); setState(() => _dragPosition = Duration(milliseconds: value.round())); },
                onChangeEnd: (value) async {
                  await player.seek(Duration(milliseconds: value.round()));
                  await _savePlaybackProgress();
                  if (mounted) { setState(() => _dragPosition = null); _scheduleControlsHide(); }
                },
              ),
            )),
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => setState(() => _showRemainingTime = !_showRemainingTime),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                child: Text(
                  _showRemainingTime
                      ? '-${_formatClock(duration - shownPosition)}'
                      : _formatClock(duration),
                  style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ]),
          const SizedBox(height: 2),
          LayoutBuilder(builder: (context, constraints) {
            final scale = (constraints.maxWidth / 500).clamp(.70, 1.18).toDouble();
            final buttonWidth = 38 * scale;
            final buttonHeight = 50 * scale;
            final iconSize = 26 * scale;
            return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              _compactControlButton(icon: _locked ? Icons.lock_rounded : Icons.lock_open_rounded, tooltip: 'Lock controls', onPressed: _toggleLock, color: _primary, width: buttonWidth, height: buttonHeight, iconSize: iconSize),
              _compactControlButton(icon: _isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded, tooltip: _isMuted ? 'Unmute' : 'Mute', onPressed: _toggleMute, color: _primary, width: buttonWidth, height: buttonHeight, iconSize: iconSize),
              _compactControlButton(icon: Icons.skip_previous_rounded, tooltip: 'Previous video', onPressed: _currentIndex > 0 && !_isSwitchingVideo ? () => _playAdjacent(-1) : null, width: buttonWidth, height: buttonHeight, iconSize: iconSize),
              _compactControlButton(icon: playing ? Icons.pause_rounded : Icons.play_arrow_rounded, tooltip: playing ? 'Pause' : 'Play', onPressed: _togglePlay, color: _primary, iconSize: 49 * scale, width: 56 * scale, height: 56 * scale),
              _compactControlButton(icon: Icons.skip_next_rounded, tooltip: 'Next video', onPressed: _currentIndex < widget.playlist.length - 1 && !_isSwitchingVideo ? () => _playAdjacent(1) : null, width: buttonWidth, height: buttonHeight, iconSize: iconSize),
              SizedBox(
                width: 46 * scale,
                height: buttonHeight,
                child: PopupMenuButton<double>(
                  tooltip: 'Playback speed', initialValue: _speed, color: _surface2,
                  padding: EdgeInsets.zero, constraints: BoxConstraints.tightFor(width: 46 * scale, height: buttonHeight),
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: .5, child: Text('0.5×')),
                    PopupMenuItem(value: .75, child: Text('0.75×')),
                    PopupMenuItem(value: 1.0, child: Text('1.0× Normal')),
                    PopupMenuItem(value: 1.25, child: Text('1.25×')),
                    PopupMenuItem(value: 1.5, child: Text('1.5×')),
                    PopupMenuItem(value: 2.0, child: Text('2.0×')),
                    PopupMenuItem(value: 2.5, child: Text('2.5×')),
                    PopupMenuItem(value: 3.0, child: Text('3.0×')),
                    PopupMenuItem(value: 3.5, child: Text('3.5×')),
                    PopupMenuItem(value: 4.0, child: Text('4.0×')),
                  ],
                  child: Center(child: Text('${_speed.toStringAsFixed(1)}×', style: TextStyle(color: _white, fontSize: 12 * scale, fontWeight: FontWeight.w900))),
                ),
              ),
              _compactControlButton(icon: _forceLandscape ? Icons.stay_current_portrait_rounded : Icons.screen_rotation_rounded, tooltip: 'Rotate screen', onPressed: _toggleRotation, color: _primary, width: buttonWidth, height: buttonHeight, iconSize: iconSize),
              _compactControlButton(icon: Icons.fit_screen_rounded, tooltip: 'Change fit mode', onPressed: _cycleFitMode, color: _primary, width: buttonWidth, height: buttonHeight, iconSize: iconSize),
            ]);
          }),
          if (_sleepTimerEndsAt != null)
            Padding(padding: const EdgeInsets.only(top: 3), child: Text('SLEEP • ${_formatClock(_sleepTimerEndsAt!.difference(DateTime.now()))}', style: const TextStyle(color: _softAccent, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.1))),
        ]),
      ),
    );
  }

  Widget _buildVerticalSideRail({required bool volume, required bool active}) {
    final rawValue = volume ? (_volume / 2).clamp(0.0, 1.0).toDouble() : _brightness.clamp(0.0, 1.0).toDouble();
    final percent = volume ? (_volume * 100).round() : (_brightness * 100).round();
    final accent = volume ? const Color(0xFFFF6B83) : const Color(0xFFFFC078);
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 130),
      opacity: active ? .96 : .04,
      child: Container(
        width: 58,
        height: 196,
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0x661A0710),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: accent.withValues(alpha: active ? .42 : .08), width: active ? 1.1 : .6),
          boxShadow: [BoxShadow(color: accent.withValues(alpha: active ? .08 : .01), blurRadius: 14)],
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Icon(volume ? Icons.volume_up_rounded : Icons.brightness_6_rounded, color: accent.withValues(alpha: .92), size: 22),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Center(
                child: Container(
                  width: 8,
                  decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(12)),
                  clipBehavior: Clip.antiAlias,
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: FractionallySizedBox(
                      heightFactor: rawValue,
                      widthFactor: 1,
                      child: DecoratedBox(decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(12))),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Text('$percent%', style: TextStyle(color: _white.withValues(alpha: .94), fontSize: 11, fontWeight: FontWeight.w900)),
        ]),
      ),
    );
  }

  Widget _buildTopSpeedHud() {
    return IgnorePointer(
      child: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: Padding(
            padding: const EdgeInsets.only(top: 12),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 220),
              switchInCurve: Curves.easeOutBack,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: (child, animation) => FadeTransition(
                opacity: animation,
                child: ScaleTransition(scale: Tween<double>(begin: .78, end: 1).animate(animation), child: SlideTransition(
                  position: Tween<Offset>(begin: const Offset(0, -.16), end: Offset.zero).animate(animation), child: child,
                )),
              ),
              child: _showTopSpeedHud
                  ? Container(
                      key: ValueKey<String>(_topSpeedHudText),
                      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 13),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: .24),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: Colors.white.withValues(alpha: .22)),
                        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .12), blurRadius: 20, spreadRadius: 2)],
                      ),
                      child: Text(_topSpeedHudText, style: const TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.w900, letterSpacing: .5)),
                    )
                  : const SizedBox.shrink(key: ValueKey<String>('speed-hidden')),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGestureHud() {
    final isForward = _gestureHudText.contains('⏩');
    final isBackward = _gestureHudText.contains('⏪');
    return IgnorePointer(
      child: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: Padding(
            padding: const EdgeInsets.only(top: 76),
            child: AnimatedOpacity(
              opacity: _showGestureHud ? 1 : 0,
              duration: const Duration(milliseconds: 160),
              child: AnimatedScale(
                scale: _showGestureHud ? 1 : .82,
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeOutBack,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0x5C3B0A1B), Color(0x4A10050B)],
                    ),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: const Color(0xFFFF7894).withValues(alpha: .30)),
                    boxShadow: [
                      BoxShadow(color: const Color(0xFFFF315F).withValues(alpha: .12), blurRadius: 24, spreadRadius: 1),
                      BoxShadow(color: Colors.black.withValues(alpha: .10), blurRadius: 18),
                    ],
                  ),
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 190),
                    switchInCurve: Curves.easeOutBack,
                    switchOutCurve: Curves.easeIn,
                    transitionBuilder: (child, animation) => FadeTransition(
                      opacity: animation,
                      child: ScaleTransition(
                        scale: Tween<double>(begin: .82, end: 1).animate(animation),
                        child: SlideTransition(
                          position: Tween<Offset>(begin: const Offset(0, .10), end: Offset.zero).animate(animation),
                          child: child,
                        ),
                      ),
                    ),
                    child: Row(key: ValueKey<String>(_gestureHudText), mainAxisSize: MainAxisSize.min, children: [
                      if (isBackward) const Icon(Icons.fast_rewind_rounded, color: Colors.white, size: 30),
                      if (isForward) const Icon(Icons.fast_forward_rounded, color: Colors.white, size: 30),
                      if (isForward || isBackward) const SizedBox(width: 10),
                      Text(_gestureHudText, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: .2)),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPlayer(Player player, VideoController videoController) {
    return StreamBuilder<bool>(
      stream: player.stream.playing,
      initialData: player.state.playing,
      builder: (context, playingSnapshot) {
        final playing = playingSnapshot.data ?? player.state.playing;
        return StreamBuilder<Duration>(
          stream: player.stream.duration,
          initialData: player.state.duration,
          builder: (context, durationSnapshot) {
            final duration = durationSnapshot.data ?? player.state.duration;
            return StreamBuilder<Duration>(
              stream: player.stream.position,
              initialData: player.state.position,
              builder: (context, positionSnapshot) {
                final position = positionSnapshot.data ?? player.state.position;
                return Stack(fit: StackFit.expand, children: [
                  Positioned.fill(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: _locked ? null : _toggleControls,
                      onDoubleTapDown: _locked ? null : (details) => _doubleTapPosition = details.localPosition,
                      onDoubleTap: _locked ? null : () {
                        final point = _doubleTapPosition;
                        if (point == null) return;
                        final width = MediaQuery.of(context).size.width;
                        unawaited(_skipBy(point.dx < width / 2 ? -10 : 10));
                      },
                      onLongPressStart: _locked ? null : _startTemporary2x,
                      onLongPressMoveUpdate: _locked ? null : _updateTemporarySpeed,
                      onLongPressEnd: _locked ? null : (_) => _endTemporary2x(),
                      onVerticalDragStart: _locked ? null : (details) => _onVideoVerticalDragStart(details, MediaQuery.of(context).size.height),
                      onVerticalDragUpdate: _locked ? null : (details) => _onVideoVerticalDragUpdate(details, MediaQuery.of(context).size.height),
                      onVerticalDragEnd: _locked ? null : _onVideoVerticalDragEnd,
                      onHorizontalDragStart: _locked ? null : _onVideoHorizontalDragStart,
                      onHorizontalDragUpdate: _locked ? null : _onVideoHorizontalDragUpdate,
                      onHorizontalDragEnd: _locked ? null : _onVideoHorizontalDragEnd,
                      child: _fitMode == 2
                          ? Center(child: AspectRatio(
                              aspectRatio: 16 / 9,
                              child: Video(
                                controller: videoController, controls: NoVideoControls, fit: BoxFit.contain,
                                subtitleViewConfiguration: _vortexSubtitleViewConfiguration(context, scale: _subtitleScale, position: _subtitlePosition),
                              ),
                            ))
                          : Video(
                              controller: videoController,
                              controls: NoVideoControls,
                              fit: _fitMode == 1 ? BoxFit.cover : BoxFit.contain,
                              subtitleViewConfiguration: _vortexSubtitleViewConfiguration(context, scale: _subtitleScale, position: _subtitlePosition),
                            ),
                    ),
                  ),
                  if (player.state.buffering)
                    const IgnorePointer(child: Center(child: CircularProgressIndicator(color: _primary))),
                  if (_showGestureHud && (_gestureKind == null || _gestureKind == 'subtitle_position') && !_temporarySpeedActive)
                    Positioned.fill(child: _buildGestureHud()),
                  if (_showSideGestureHud)
                    Positioned.fill(
                      child: IgnorePointer(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                            if (_sideGestureKind == 'brightness') _buildVerticalSideRail(volume: false, active: true) else const SizedBox.shrink(),
                            if (_sideGestureKind == 'volume') _buildVerticalSideRail(volume: true, active: true) else const SizedBox.shrink(),
                          ]),
                        ),
                      ),
                    ),
                  if (_showTopSpeedHud)
                    Positioned.fill(child: _buildTopSpeedHud()),
                  if (_controlsVisible && !_locked)
                    Positioned(left: 0, right: 0, top: 0, child: SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        child: Row(children: [
                          IconButton(
                            tooltip: 'Back to library',
                            onPressed: () => Navigator.of(context).maybePop(),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints.tightFor(width: 44, height: 48),
                            icon: const Icon(Icons.arrow_back_rounded, color: _white, size: 28),
                          ),
                          const SizedBox(width: 3),
                          Expanded(child: Text(_currentAsset.title ?? 'Video', maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: _white, fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: .1))),
                          IconButton(tooltip: 'Audio track', onPressed: () => _openAudioTrackSettings(player),
                            style: IconButton.styleFrom(backgroundColor: const Color(0xB51B0710), shape: const CircleBorder(), minimumSize: const Size(48, 48)),
                            icon: const Icon(Icons.audiotrack_rounded, color: _primary, size: 29)),
                          TextButton.icon(
                            onPressed: () => _openSubtitleTrackSettings(player),
                            style: TextButton.styleFrom(
                              backgroundColor: const Color(0xB51B0710),
                              foregroundColor: _primary,
                              minimumSize: const Size(68, 46),
                              padding: const EdgeInsets.symmetric(horizontal: 8),
                              shape: const StadiumBorder(),
                            ),
                            icon: const Icon(Icons.subtitles_rounded, size: 22),
                            label: const Text('SUB', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .6)),
                          ),
                          const SizedBox(width: 2),
                          IconButton(
                            tooltip: 'Subtitle size & position settings',
                            onPressed: () => _openSubtitleTrackSettings(player),
                            style: IconButton.styleFrom(
                              backgroundColor: const Color(0xB51B0710),
                              foregroundColor: _primary,
                              minimumSize: const Size(44, 46),
                              shape: const CircleBorder(),
                            ),
                            icon: const Icon(Icons.tune_rounded, color: _primary, size: 23),
                          ),
                          IconButton(tooltip: _favorite ? 'Remove from favorites' : 'Add to favorites', onPressed: () {
                            widget.onFavorite(_currentAsset.id);
                            setState(() => _favorite = !_favorite);
                          }, style: IconButton.styleFrom(backgroundColor: const Color(0x9E1B0710), shape: const CircleBorder()),
                            icon: Icon(_favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                            color: _favorite ? _primary : Colors.white)),
                          PopupMenuButton<String>(
                            tooltip: 'More player tools',
                            color: _surface2,
                            icon: const Icon(Icons.more_vert_rounded, color: Colors.white),
                            onSelected: (choice) {
                              switch (choice) {
                                case 'bookmark': _addBookmark(); break;
                                case 'bookmarks': _openBookmarks(); break;
                                case 'queue': _showPlayingQueue(); break;
                                case 'sleep': _chooseSleepTimer(); break;
                                case 'repeat': _cycleRepeatMode(); break;
                                case 'audio_settings': _openAudioTrackSettings(player); break;
                                case 'subtitle_settings': _openSubtitleTrackSettings(player); break;
                                case 'share': _shareVideo(); break;
                                case 'info': _showAssetInfo(context, _currentAsset); break;
                              }
                            },
                            itemBuilder: (_) => [
                              const PopupMenuItem(value: 'bookmark', child: ListTile(dense: true, leading: Icon(Icons.bookmark_add_outlined), title: Text('Save bookmark'))),
                              PopupMenuItem(value: 'bookmarks', child: ListTile(dense: true, leading: const Icon(Icons.bookmarks_outlined), title: Text('Bookmarks (${_bookmarks.length})'))),
                              const PopupMenuItem(value: 'queue', child: ListTile(dense: true, leading: Icon(Icons.queue_music_rounded), title: Text('Playing queue'))),
                              PopupMenuItem(value: 'repeat', child: ListTile(dense: true, leading: const Icon(Icons.repeat_rounded), title: Text('Repeat • ${['Off', 'One', 'All'][_repeatMode]}'))),
                              PopupMenuItem(value: 'sleep', child: ListTile(dense: true, leading: const Icon(Icons.bedtime_outlined), title: Text(_sleepTimerMinutes == null ? 'Sleep timer' : 'Sleep timer • $_sleepTimerMinutes min'))),
                              const PopupMenuDivider(),
                              const PopupMenuItem(value: 'audio_settings', child: ListTile(dense: true, leading: Icon(Icons.audiotrack_rounded), title: Text('Audio settings'))),
                              const PopupMenuItem(value: 'subtitle_settings', child: ListTile(dense: true, leading: Icon(Icons.subtitles_rounded), title: Text('Subtitle settings • size & position'))),
                              const PopupMenuDivider(),
                              const PopupMenuItem(value: 'share', child: ListTile(dense: true, leading: Icon(Icons.share_outlined), title: Text('Share video'))),
                              const PopupMenuItem(value: 'info', child: ListTile(dense: true, leading: Icon(Icons.info_outline_rounded), title: Text('Video information'))),
                            ],
                          ),
                        ]),
                      ),
                    )),
                  if (_locked)
                    Positioned(top: 12, right: 14, child: SafeArea(child: IconButton.filledTonal(
                      tooltip: 'Unlock player controls', onPressed: _toggleLock,
                      icon: const Icon(Icons.lock_rounded),
                    ))),
                  if (_controlsVisible && !_locked)
                    Positioned(left: 0, right: 0, bottom: 0,
                      child: Listener(
                        behavior: HitTestBehavior.translucent,
                        onPointerDown: (_) => _cancelControlsTimer(),
                        onPointerUp: (_) => _scheduleControlsHide(),
                        onPointerCancel: (_) => _scheduleControlsHide(),
                        child: _buildControls(player, position, duration, playing),
                      ),
                    ),
                ]);
              },
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final player = _player;
    final videoController = _videoController;
    return PopScope<Object?>(
      canPop: true,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) unawaited(_savePlaybackProgress());
      },
      child: Scaffold(
      backgroundColor: Colors.black,
      appBar: null,
      body: SafeArea(
        top: false,
        bottom: false,
        left: false,
        right: false,
        child: _error != null
            ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.video_file_outlined, color: _muted, size: 48),
                const SizedBox(height: 12),
                Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                const SizedBox(height: 16),
                FilledButton.icon(onPressed: _initialiseVideo, icon: const Icon(Icons.refresh_rounded), label: const Text('Try again')),
              ])))
            : _loading || player == null || videoController == null
                ? const Center(child: CircularProgressIndicator(color: _primary))
                : _buildPlayer(player, videoController),
      ),
      ),
    );
  }
}

