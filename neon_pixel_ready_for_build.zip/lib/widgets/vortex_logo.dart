import 'dart:math' as math;
import 'package:flutter/material.dart';

class VortexLogoMark extends StatelessWidget {
  final double size;
  final double progress;
  const VortexLogoMark({required this.size, this.progress = 1});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: size,
    height: size,
    child: CustomPaint(painter: VortexLogoPainter(progress.clamp(0.0, 1.0).toDouble())),
  );
}

class VortexLogoPainter extends CustomPainter {
  final double progress;
  const VortexLogoPainter(this.progress);

  double _ease(double value) => Curves.easeOutCubic.transform(value.clamp(0.0, 1.0));

  @override
  void paint(Canvas canvas, Size size) {
    final u = size.shortestSide;
    final c = Offset(size.width / 2, size.height / 2);
    final p = progress.clamp(0.0, 1.0);

    // Two coloured energy streams fly in from opposite sides and converge.
    final merge = _ease(p / .56);
    final leftStart = Offset(-u * .30, c.dy - u * .13);
    final rightStart = Offset(size.width + u * .30, c.dy + u * .13);
    final leftNow = Offset.lerp(leftStart, Offset(c.dx - u * .12, c.dy), merge)!;
    final rightNow = Offset.lerp(rightStart, Offset(c.dx + u * .12, c.dy), merge)!;
    final beamFade = (1.0 - _ease((p - .36) / .36)).clamp(0.0, 1.0);
    if (beamFade > 0) {
      final leftPath = Path()..moveTo(leftStart.dx, leftStart.dy)..quadraticBezierTo(c.dx - u * .18, c.dy - u * .25, leftNow.dx, leftNow.dy);
      final rightPath = Path()..moveTo(rightStart.dx, rightStart.dy)..quadraticBezierTo(c.dx + u * .18, c.dy + u * .25, rightNow.dx, rightNow.dy);
      final leftPaint = Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = u * .035
        ..shader = const LinearGradient(colors: [Color(0x007B0E2C), Color(0xFFE13C59)]).createShader(Rect.fromLTWH(-u*.35, c.dy-u*.25, u*.85, u*.5))
        ..color = Colors.white.withValues(alpha: beamFade);
      final rightPaint = Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = u * .035
        ..shader = const LinearGradient(colors: [Color(0xFFFF9868), Color(0x00FF9868)]).createShader(Rect.fromLTWH(c.dx, c.dy-u*.25, u*.85, u*.5))
        ..color = Colors.white.withValues(alpha: beamFade);
      canvas.drawPath(leftPath, leftPaint);
      canvas.drawPath(rightPath, rightPaint);
      canvas.drawCircle(leftNow, u * (.025 + .02 * (1-merge)), Paint()..color = const Color(0xFFFF5B70).withValues(alpha: beamFade));
      canvas.drawCircle(rightNow, u * (.025 + .02 * (1-merge)), Paint()..color = const Color(0xFFFFA06D).withValues(alpha: beamFade));
    }

    final assemble = _ease((p - .30) / .70);
    final emblemScale = .22 + .78 * assemble;
    final reveal = _ease((p - .48) / .52);
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.scale(emblemScale);
    canvas.rotate((1 - assemble) * -.20);
    canvas.translate(-c.dx, -c.dy);

    final card = Rect.fromCenter(center: c, width: u * .72, height: u * .72);
    final cardRRect = RRect.fromRectAndRadius(card, Radius.circular(u * .24));
    final glow = Paint()..color = const Color(0xFFC51F45).withValues(alpha: .36 * reveal)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, u * .16);
    canvas.drawRRect(cardRRect, glow);
    final cardPaint = Paint()..shader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF7C102E), Color(0xFFC51F45), Color(0xFFE45A58)],
    ).createShader(card)..color = Colors.white.withValues(alpha: reveal);
    canvas.drawRRect(cardRRect, cardPaint);

    final orbitRect = Rect.fromCircle(center: c, radius: u * .465);
    final orbitPaint = Paint()..style = PaintingStyle.stroke..strokeWidth = u * .032
      ..strokeCap = StrokeCap.round
      ..shader = const SweepGradient(colors: [Color(0x00FFFFFF), Color(0xFFE13B59), Color(0xFFFFA06D), Color(0x00FFFFFF)]).createShader(orbitRect);
    canvas.drawArc(orbitRect, -math.pi / 2, math.pi * 2 * reveal, false, orbitPaint);
    final orbAngle = -math.pi / 2 + math.pi * 2 * reveal;
    final orb = Offset(c.dx + math.cos(orbAngle) * u * .465, c.dy + math.sin(orbAngle) * u * .465);
    canvas.drawCircle(orb, u * .040, Paint()..color = const Color(0xFFFFE5D9).withValues(alpha: reveal));

    final inner = Paint()..color = const Color(0xFF17070F).withValues(alpha: reveal);
    canvas.drawCircle(c, u * .225, inner);
    final play = Path()
      ..moveTo(c.dx - u * .055, c.dy - u * .115)
      ..quadraticBezierTo(c.dx - u * .075, c.dy - u * .13, c.dx - u * .075, c.dy - u * .095)
      ..lineTo(c.dx + u * .125, c.dy - u * .005)
      ..quadraticBezierTo(c.dx + u * .16, c.dy + u * .012, c.dx + u * .12, c.dy + u * .04)
      ..lineTo(c.dx - u * .06, c.dy + u * .14)
      ..quadraticBezierTo(c.dx - u * .09, c.dy + u * .15, c.dx - u * .075, c.dy + u * .10)
      ..close();
    canvas.drawPath(play, Paint()..color = const Color(0xFFFFF4F0).withValues(alpha: reveal));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant VortexLogoPainter oldDelegate) => oldDelegate.progress != progress;
}
