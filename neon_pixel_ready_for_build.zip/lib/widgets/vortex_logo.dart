import 'dart:math' as math;
import 'package:flutter/material.dart';

/// VORTEX PLAYER's refreshed electric V mark with a play core and orbit stroke.
/// It is drawn as vector artwork, so it stays crisp at launcher, header and splash sizes.
class VortexLogoMark extends StatelessWidget {
  final double size;
  final double progress;
  const VortexLogoMark({super.key, required this.size, this.progress = 1});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: size,
    height: size,
    child: CustomPaint(painter: VortexLogoPainter(progress.clamp(0.0, 1.0).toDouble())),
  );
}

class VortexLogoPainter extends CustomPainter {
  final double progress;
  const VortexLogoPainter(this.progress);

  double _ease(double x) => Curves.easeOutCubic.transform(x.clamp(0.0, 1.0).toDouble());

  @override
  void paint(Canvas canvas, Size size) {
    final u = size.shortestSide;
    final center = Offset(size.width / 2, size.height / 2);
    final p = progress.clamp(0.0, 1.0).toDouble();
    final tile = Rect.fromCenter(center: center, width: u * .94, height: u * .94);
    final round = RRect.fromRectAndRadius(tile, Radius.circular(u * .27));

    canvas.drawRRect(round, Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF242044), Color(0xFF111322), Color(0xFF101A2B)],
      ).createShader(tile));
    canvas.drawRRect(round, Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = u * .012
      ..color = const Color(0xFF9B83FF).withValues(alpha: .25));

    // Soft neon bloom behind the emblem.
    final glow = Paint()
      ..color = const Color(0xFF8057F5).withValues(alpha: .19 * p)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, u * .12);
    canvas.drawCircle(Offset(center.dx, center.dy + u * .02), u * .30, glow);

    // Two continuous ribbons form a distinctive V. The open top leaves visual space for the orbit.
    final left = Path()
      ..moveTo(center.dx - u * .28, center.dy - u * .23)
      ..cubicTo(center.dx - u * .23, center.dy - u * .02, center.dx - u * .10, center.dy + u * .20, center.dx, center.dy + u * .30);
    final right = Path()
      ..moveTo(center.dx + u * .28, center.dy - u * .23)
      ..cubicTo(center.dx + u * .23, center.dy - u * .02, center.dx + u * .10, center.dy + u * .20, center.dx, center.dy + u * .30);

    final ribbonGlow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = u * .14
      ..color = const Color(0xFF8A6BFF).withValues(alpha: .40 * p)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, u * .075);
    for (final path in [left, right]) {
      for (final metric in path.computeMetrics()) {
        canvas.drawPath(metric.extractPath(0, metric.length * _ease(p)), ribbonGlow);
      }
    }

    final leftPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = u * .095
      ..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomRight,
        colors: [Color(0xFFDB7BFF), Color(0xFF8155FF), Color(0xFF5735D7)]).createShader(tile);
    final rightPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = u * .095
      ..shader = const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft,
        colors: [Color(0xFF65E4FF), Color(0xFF6B86FF), Color(0xFF8057F5)]).createShader(tile);
    for (final entry in [(left, leftPaint), (right, rightPaint)]) {
      for (final metric in entry.$1.computeMetrics()) {
        canvas.drawPath(metric.extractPath(0, metric.length * _ease(p)), entry.$2);
      }
    }

    // Orbit sweeps around the V to give the mark a motion identity.
    final orbit = Path()
      ..moveTo(center.dx - u * .34, center.dy - u * .07)
      ..cubicTo(center.dx - u * .14, center.dy - u * .43, center.dx + u * .25, center.dy - u * .38, center.dx + u * .36, center.dy - u * .09);
    canvas.drawPath(orbit, Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = u * .025
      ..shader = const LinearGradient(colors: [Color(0x00C28CFF), Color(0xFFC38BFF), Color(0xFF58DDFF)]).createShader(tile)
      ..color = Colors.white.withValues(alpha: _ease((p - .18) / .45)));

    // Play symbol at the center-right of the V.
    final reveal = _ease((p - .45) / .35);
    final play = Path()
      ..moveTo(center.dx - u * .045, center.dy - u * .105)
      ..quadraticBezierTo(center.dx - u * .055, center.dy - u * .13, center.dx - u * .02, center.dy - u * .11)
      ..lineTo(center.dx + u * .14, center.dy - u * .012)
      ..quadraticBezierTo(center.dx + u * .185, center.dy + u * .015, center.dx + u * .14, center.dy + u * .04)
      ..lineTo(center.dx - u * .02, center.dy + u * .13)
      ..quadraticBezierTo(center.dx - u * .055, center.dy + u * .15, center.dx - u * .055, center.dy + u * .105)
      ..close();
    canvas.drawPath(play, Paint()..color = Colors.white.withValues(alpha: reveal));

    final spark = Offset(center.dx + math.cos(-.45) * u * .39, center.dy + math.sin(-.45) * u * .39);
    canvas.drawCircle(spark, u * .022, Paint()..color = const Color(0xFF8AE8FF).withValues(alpha: p));
  }

  @override
  bool shouldRepaint(covariant VortexLogoPainter oldDelegate) => oldDelegate.progress != progress;
}
