import 'dart:math' as math;
import 'package:flutter/material.dart';

class VortexLogoMark extends StatelessWidget {
  final double size;
  final double progress;
  const VortexLogoMark({required this.size, this.progress = 1});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: size,
    height: size,
    child: CustomPaint(painter: VortexLogoPainter(progress.clamp(0.0, 1.0).toDouble())),
  );
}

class VortexLogoPainter extends CustomPainter {
  final double progress;
  const VortexLogoPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final unit = size.shortestSide;
    final card = Rect.fromCenter(center: c, width: unit * .68, height: unit * .68);
    final rr = RRect.fromRectAndRadius(card, Radius.circular(unit * .22));
    final shadow = Paint()
      ..color = const Color(0xFFFF5C70).withValues(alpha: .24 * progress)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, unit * .12);
    canvas.drawRRect(rr, shadow);
    final cardPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [const Color(0xFFFF5C70), const Color(0xFFFF9A68), Color(0xFFFFB16E)],
      ).createShader(card);
    cardPaint.color = Colors.white.withValues(alpha: progress);
    canvas.drawRRect(rr, cardPaint);

    final inner = Paint()..color = const Color(0xFF18111B).withValues(alpha: progress);
    canvas.drawCircle(c, unit * .215, inner);

    final orbitRect = Rect.fromCircle(center: c, radius: unit * .465);
    final orbitPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = unit * .028
      ..strokeCap = StrokeCap.round
      ..shader = const SweepGradient(colors: [
        Color(0x00FFFFFF), Color(0xFFFFD8C5), Color(0xFFFF5C70), Color(0x00FFFFFF),
      ]).createShader(orbitRect);
    canvas.drawArc(orbitRect, -math.pi / 2, math.pi * 1.82 * progress, false, orbitPaint);

    final angle = -math.pi / 2 + math.pi * 1.82 * progress;
    final dot = Offset(c.dx + math.cos(angle) * unit * .465, c.dy + math.sin(angle) * unit * .465);
    canvas.drawCircle(dot, unit * .038, Paint()..color = const Color(0xFFFFE8DA).withValues(alpha: progress));

    final play = Path()
      ..moveTo(c.dx - unit * .055, c.dy - unit * .105)
      ..quadraticBezierTo(c.dx - unit * .065, c.dy - unit * .12, c.dx - unit * .04, c.dy - unit * .105)
      ..lineTo(c.dx + unit * .105, c.dy)
      ..quadraticBezierTo(c.dx + unit * .125, c.dy + unit * .012, c.dx + unit * .105, c.dy + unit * .025)
      ..lineTo(c.dx - unit * .04, c.dy + unit * .11)
      ..quadraticBezierTo(c.dx - unit * .065, c.dy + unit * .12, c.dx - unit * .055, c.dy + unit * .095)
      ..close();
    canvas.drawPath(play, Paint()..color = const Color(0xFFFFF7F2).withValues(alpha: progress));
  }

  @override
  bool shouldRepaint(covariant VortexLogoPainter oldDelegate) => oldDelegate.progress != progress;
}

