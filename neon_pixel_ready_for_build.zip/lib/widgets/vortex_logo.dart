import 'dart:math' as math;
import 'package:flutter/material.dart';

/// VORTEX PLAYER's new Ion-Core emblem. Drawn as crisp vector artwork and
/// revealed in stages by the launch animation.
class VortexLogoMark extends StatelessWidget {
  final double size;
  final double progress;
  const VortexLogoMark({super.key, required this.size, this.progress = 1});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: size, height: size,
    child: CustomPaint(painter: VortexLogoPainter(progress.clamp(0.0, 1.0).toDouble())),
  );
}

class VortexLogoPainter extends CustomPainter {
  final double progress;
  const VortexLogoPainter(this.progress);

  double _reveal(double v) => Curves.easeOutCubic.transform(v.clamp(0.0, 1.0).toDouble());

  @override
  void paint(Canvas canvas, Size size) {
    final u = size.shortestSide;
    final c = Offset(size.width / 2, size.height / 2);
    final p = progress.clamp(0.0, 1.0).toDouble();
    final tile = Rect.fromCenter(center: c, width: u * .94, height: u * .94);
    final rr = RRect.fromRectAndRadius(tile, Radius.circular(u * .28));
    canvas.drawRRect(rr, Paint()..shader = const LinearGradient(
      begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [Color(0xFF183B4B), Color(0xFF07131F), Color(0xFF0B1724)],
    ).createShader(tile));
    canvas.drawRRect(rr, Paint()..style = PaintingStyle.stroke..strokeWidth = u * .012..color = const Color(0xFF7AF7FF).withValues(alpha: .32));

    final glow = Paint()..color = const Color(0xFF00D7E8).withValues(alpha: .25 * p)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, u * .13);
    canvas.drawCircle(Offset(c.dx, c.dy + u * .02), u * .30, glow);

    // Twin angular ribbons create a sharp, forward-moving V.
    final left = Path()..moveTo(c.dx - u*.29, c.dy - u*.27)
      ..cubicTo(c.dx - u*.24, c.dy - u*.02, c.dx - u*.10, c.dy + u*.23, c.dx, c.dy + u*.31);
    final right = Path()..moveTo(c.dx + u*.29, c.dy - u*.27)
      ..cubicTo(c.dx + u*.24, c.dy - u*.02, c.dx + u*.10, c.dy + u*.23, c.dx, c.dy + u*.31);
    final leftPaint = Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round
      ..strokeWidth = u*.085..shader = const LinearGradient(begin: Alignment.topCenter,end: Alignment.bottomRight,colors:[Color(0xFFFFC56A),Color(0xFF00E5F0),Color(0xFF008EA5)]).createShader(tile);
    final rightPaint = Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round
      ..strokeWidth = u*.085..shader = const LinearGradient(begin: Alignment.topCenter,end: Alignment.bottomLeft,colors:[Color(0xFFB7FCFF),Color(0xFF00D7E8),Color(0xFF087F91)]).createShader(tile);
    for (final entry in [(left,leftPaint),(right,rightPaint)]) {
      for (final metric in entry.$1.computeMetrics()) {
        canvas.drawPath(metric.extractPath(0, metric.length * _reveal(p)), entry.$2);
      }
    }

    // Fast orbital ring with a bright moving node.
    final orbit = Path()..addOval(Rect.fromCenter(center: c, width: u*.70, height: u*.34));
    canvas.save();
    canvas.translate(c.dx,c.dy);
    canvas.rotate(-.34 + p * .20);
    canvas.translate(-c.dx,-c.dy);
    canvas.drawPath(orbit, Paint()..style=PaintingStyle.stroke..strokeWidth=u*.025
      ..color=const Color(0xFFFFC56A).withValues(alpha:.82 * _reveal((p-.25)/.5)));
    final a = -math.pi*.18 + p*math.pi*1.7;
    final node = Offset(c.dx + math.cos(a)*u*.35, c.dy + math.sin(a)*u*.17);
    canvas.drawCircle(node,u*.035,Paint()..color=const Color(0xFFFFD18A).withValues(alpha:p)
      ..maskFilter=MaskFilter.blur(BlurStyle.normal,u*.035));
    canvas.drawCircle(node,u*.014,Paint()..color=Colors.white.withValues(alpha:p));
    canvas.restore();

    // Compact play core.
    final core = Path()..moveTo(c.dx-u*.055,c.dy-u*.105)..quadraticBezierTo(c.dx-u*.075,c.dy-u*.14,c.dx-u*.025,c.dy-u*.11)
      ..lineTo(c.dx+u*.13,c.dy-u*.012)..quadraticBezierTo(c.dx+u*.18,c.dy+u*.02,c.dx+u*.13,c.dy+u*.05)
      ..lineTo(c.dx-u*.025,c.dy+u*.14)..quadraticBezierTo(c.dx-u*.075,c.dy+u*.16,c.dx-u*.055,c.dy+u*.105)..close();
    canvas.drawPath(core,Paint()..color=Colors.white.withValues(alpha:_reveal((p-.55)/.35)));
  }

  @override
  bool shouldRepaint(covariant VortexLogoPainter oldDelegate) => oldDelegate.progress != progress;
}
