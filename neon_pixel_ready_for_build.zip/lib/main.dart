import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:cross_file/cross_file.dart';
import 'package:flutter/services.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Bundled libmpv/FFmpeg engine for broad codec support, including E-AC-3.
  MediaKit.ensureInitialized();
  runApp(const VortexPlayerApp());
}

const _bg = Color(0xFF070B16);
const _surface = Color(0xFF111827);
const _surface2 = Color(0xFF1B2638);
const _purple = Color(0xFF8B5CF6);
const _cyan = Color(0xFF35D7F2);
const _muted = Color(0xFF9AA9BC);
const _white = Color(0xFFF3F7FC);
const _mint = Color(0xFF56E0C2);

class VortexPlayerApp extends StatelessWidget {
  const VortexPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VORTEX PLAYER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bg,
        colorScheme: ColorScheme.fromSeed(seedColor: _cyan, brightness: Brightness.dark, surface: _surface),
        fontFamily: 'Roboto',
      ),
      home: const VortexLaunchScreen(),
    );
  }
}

class VortexLaunchScreen extends StatefulWidget {
  const VortexLaunchScreen({super.key});

  @override
  State<VortexLaunchScreen> createState() => _VortexLaunchScreenState();
}

class _VortexLaunchScreenState extends State<VortexLaunchScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;
  late final Animation<double> _fade;
  late final Animation<double> _rotation;
  late final Animation<double> _pulse;
  bool _showHome = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1700));
    _scale = Tween<double>(begin: .72, end: 1).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutBack));
    _fade = CurvedAnimation(parent: _controller, curve: const Interval(0, .72, curve: Curves.easeIn));
    _rotation = Tween<double>(begin: -.35, end: math.pi * 1.65).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOutCubic));
    _pulse = Tween<double>(begin: .94, end: 1.04).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    _controller.forward();
    Timer(const Duration(milliseconds: 2050), () {
      if (mounted) setState(() => _showHome = true);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 520),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeInCubic,
      child: _showHome ? const VortexHome() : Scaffold(
        key: const ValueKey('vortex-launch'),
        backgroundColor: _bg,
        body: Container(
          decoration: const BoxDecoration(
            gradient: RadialGradient(center: Alignment.center, radius: 1.0,
              colors: [Color(0xFF1A2450), _bg]),
          ),
          child: Center(child: FadeTransition(
            opacity: _fade,
            child: ScaleTransition(scale: _scale, child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) => Transform.scale(
                    scale: _pulse.value,
                    child: SizedBox(
                      width: 112, height: 112,
                      child: Stack(alignment: Alignment.center, children: [
                        Transform.rotate(
                          angle: _rotation.value,
                          child: Container(
                            width: 108, height: 108,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: _cyan.withOpacity(.65), width: 1.5),
                              boxShadow: [BoxShadow(color: _cyan.withOpacity(.16), blurRadius: 28, spreadRadius: 3)],
                            ),
                            child: Align(
                              alignment: Alignment.topCenter,
                              child: Container(width: 9, height: 9, decoration: const BoxDecoration(shape: BoxShape.circle, color: _mint)),
                            ),
                          ),
                        ),
                        Container(
                          width: 76, height: 76,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),
                            gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [_cyan, _purple]),
                            boxShadow: [BoxShadow(color: _purple.withOpacity(.32), blurRadius: 28, spreadRadius: 1)],
                          ),
                          child: const Icon(Icons.play_arrow_rounded, color: Color(0xFF07111D), size: 54),
                        ),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                const Text('VORTEX PLAYER', style: TextStyle(
                  color: _white, fontSize: 16, fontWeight: FontWeight.w900,
                  letterSpacing: 3.2,
                )),
                const SizedBox(height: 8),
                Text('PLAY WITHOUT LIMITS', style: TextStyle(
                  color: _cyan.withOpacity(.92), fontSize: 9,
                  fontWeight: FontWeight.w800, letterSpacing: 2.8,
                )),
                const SizedBox(height: 20),
                SizedBox(width: 82, child: AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) => ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(value: _controller.value, minHeight: 2, backgroundColor: Colors.white12,
                      valueColor: const AlwaysStoppedAnimation<Color>(_cyan)),
                  ),
                )),
              ],
            )),
          )),
        ),
      ),
    );
  }
}

class VortexHome extends StatefulWidget {
  const VortexHome({super.key});

  @override
  State<VortexHome> createState() => _VortexHomeState();
}

class _VortexHomeState extends State<VortexHome> {
  List<AssetEntity> _videos = [];
  List<AssetPathEntity> _folders = [];
  AssetPathEntity? _selectedFolder;
  final Set<String> _favorites = {};
  final TextEditingController _searchController = TextEditingController();
  bool _loading = true;
  bool _searchOpen = false;
  bool _favoritesOnly = false;
  bool _grid = true;
  bool _newestFirst = true;
  String? _error;
  String _query = '';
  String? _lastWatchedAssetId;
  String _lastWatchedTitle = '';
  int _lastWatchedPositionMs = 0;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _loadVideos();
    _loadLastWatched();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadLastWatched() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    final lastId = prefs.getString('vortex_last_asset_id');
    final position = lastId == null
        ? (prefs.getInt('vortex_last_position_ms') ?? 0)
        : (prefs.getInt('vortex_resume_$lastId') ??
            prefs.getInt('vortex_last_position_ms') ?? 0);
    setState(() {
      _lastWatchedAssetId = lastId;
      _lastWatchedTitle = prefs.getString('vortex_last_asset_title') ?? 'Last played video';
      _lastWatchedPositionMs = position;
    });
  }

  Future<void> _resumeLastWatched() async {
    final id = _lastWatchedAssetId;
    if (id == null || id.isEmpty) return;
    final asset = await AssetEntity.fromId(id);
    if (!mounted) return;
    if (asset == null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('vortex_last_asset_id');
      await prefs.remove('vortex_last_asset_title');
      await prefs.remove('vortex_last_position_ms');
      setState(() {
        _lastWatchedAssetId = null;
        _lastWatchedTitle = '';
        _lastWatchedPositionMs = 0;
      });
      _showMessage('Last played video is no longer available.');
      return;
    }
    await _openVideo(asset, resumeDirectly: true);
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _favorites.addAll(prefs.getStringList('vortex_player_favorites') ?? []));
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('vortex_player_favorites', _favorites.toList());
  }

  Future<void> _loadVideos() async {
    if (mounted) setState(() { _loading = true; _error = null; });
    try {
      final permission = await PhotoManager.requestPermissionExtend();
      if (!permission.isAuth && !permission.hasAccess) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = 'Allow video access so VORTEX can build your local video library.';
        });
        return;
      }
      final paths = await PhotoManager.getAssetPathList(
        type: RequestType.video,
        hasAll: false,
      );
      final selected = _selectedFolder;
      final clips = <AssetEntity>[];
      if (selected != null) {
        clips.addAll(await selected.getAssetListRange(start: 0, end: 5000));
      }
      clips.sort((a, b) => b.createDateTime.compareTo(a.createDateTime));
      if (!mounted) return;
      setState(() {
        _folders = paths;
        _videos = clips;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Could not load video folders. Please try again.\n$e'; });
    }
  }

  Future<void> _openFolder(AssetPathEntity folder) async {
    setState(() { _selectedFolder = folder; _favoritesOnly = false; _query = ''; _searchController.clear(); });
    await _loadVideos();
  }

  Future<void> _leaveFolder() async {
    setState(() { _selectedFolder = null; _favoritesOnly = false; _query = ''; _searchController.clear(); });
    await _loadVideos();
  }

  List<AssetEntity> get _visibleVideos {
    var items = List<AssetEntity>.from(_videos);
    if (_favoritesOnly) items = items.where((v) => _favorites.contains(v.id)).toList();
    final q = _query.trim().toLowerCase();
    if (q.isNotEmpty) items = items.where((v) => (v.title ?? '').toLowerCase().contains(q)).toList();
    items.sort((a, b) => _newestFirst
        ? b.createDateTime.compareTo(a.createDateTime)
        : a.createDateTime.compareTo(b.createDateTime));
    return items;
  }

  void _toggleFavorite(String id) {
    setState(() {
      if (!_favorites.add(id)) _favorites.remove(id);
    });
    _saveFavorites();
  }

  Future<void> _shareVideo(AssetEntity asset) async {
    final file = await asset.file;
    if (file == null) return;
    await Share.shareXFiles([XFile(file.path)], text: 'Shared with VORTEX PLAYER');
  }

  Future<int?> _chooseStartPosition(AssetEntity asset) async {
    final prefs = await SharedPreferences.getInstance();
    final savedMs = prefs.getInt('vortex_resume_${asset.id}') ?? 0;
    final durationMs = asset.duration * 1000;
    final isIncomplete = savedMs > 3000 && (durationMs <= 0 || savedMs < durationMs - 3000);
    if (!isIncomplete) return 0;
    if (!mounted) return null;
    return showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: _surface2,
        title: const Text('Continue watching?', style: TextStyle(color: _white, fontWeight: FontWeight.w800)),
        content: Text(
          'You watched until ${_formatClock(Duration(milliseconds: savedMs))}.',
          style: const TextStyle(color: _muted, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, 0),
            child: const Text('START FROM BEGINNING', style: TextStyle(color: _muted, fontSize: 11)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: _cyan, foregroundColor: Colors.black),
            onPressed: () => Navigator.pop(dialogContext, savedMs),
            child: const Text('CONTINUE', style: TextStyle(fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }

  Future<void> _openVideo(AssetEntity asset, {bool resumeDirectly = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final savedForAsset = prefs.getInt('vortex_resume_${asset.id}') ?? 0;
    final startPositionMs = resumeDirectly
        ? (savedForAsset > 0 ? savedForAsset : _lastWatchedPositionMs)
        : await _chooseStartPosition(asset);
    if (!mounted || startPositionMs == null) return;
    final visible = _visibleVideos;
    final playlist = visible.any((item) => item.id == asset.id) ? visible : <AssetEntity>[asset];
    final index = playlist.indexWhere((item) => item.id == asset.id);
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => VideoPlayerPage(
        asset: asset,
        playlist: playlist,
        initialIndex: index < 0 ? 0 : index,
        initialPositionMs: startPositionMs,
        isFavorite: (id) => _favorites.contains(id),
        initiallyFavorite: _favorites.contains(asset.id),
        onFavorite: _toggleFavorite,
        onShare: (items) async {
          if (items.isNotEmpty) await _shareVideo(items.first);
        },
      ),
    ));
    await _loadLastWatched();
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    final items = _visibleVideos;
    return PopScope<Object?>(
      canPop: _selectedFolder == null && !_searchOpen,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (_searchOpen) {
          setState(() {
            _searchOpen = false;
            _query = '';
            _searchController.clear();
          });
        } else if (_selectedFolder != null) {
          _leaveFolder();
        }
      },
      child: Scaffold(
      backgroundColor: _bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF11172A), _bg, Color(0xFF0C1D2B)], stops: [0, .42, 1]),
        ),
        child: SafeArea(
          child: Column(children: [
            _buildHeader(),
            if (_searchOpen) _buildSearch(),
            const SizedBox(height: 8),
            _buildLibraryToolbar(),
            Expanded(child: _buildVideoLibrary(items)),
          ]),
        ),
      ),
      floatingActionButton: _lastWatchedAssetId != null && _lastWatchedPositionMs > 1500
          ? SizedBox(
              width: 58,
              height: 58,
              child: Material(
                color: Colors.transparent,
                shape: const CircleBorder(),
                elevation: 8,
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: _resumeLastWatched,
                  child: Ink(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [_cyan, _purple]),
                    ),
                    child: const Icon(Icons.play_arrow_rounded, color: Colors.black, size: 34),
                  ),
                ),
              ),
            )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 16, 8),
      child: Row(children: [
        if (_selectedFolder != null)
          IconButton(
            tooltip: 'Back to folders',
            onPressed: _leaveFolder,
            icon: const Icon(Icons.arrow_back_rounded, color: _cyan),
          ),
        Container(
          width: 46, height: 46,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            gradient: const LinearGradient(colors: [_cyan, _purple]),
            boxShadow: [BoxShadow(color: _cyan.withOpacity(.22), blurRadius: 20, spreadRadius: 1)],
          ),
          child: const Icon(Icons.play_arrow_rounded, color: Colors.black, size: 32),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('VORTEX', style: TextStyle(color: _white, fontSize: 22, height: 1, fontWeight: FontWeight.w900, letterSpacing: 2.1)),
          const SizedBox(height: 4),
          Text('PREMIUM VIDEO PLAYER', style: TextStyle(color: _cyan.withOpacity(.9), fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 2.0)),
        ])),
        IconButton(
          tooltip: _searchOpen ? 'Close search' : 'Search videos',
          onPressed: () => setState(() {
            _searchOpen = !_searchOpen;
            if (!_searchOpen) { _query = ''; _searchController.clear(); }
          }),
          style: IconButton.styleFrom(backgroundColor: Colors.white.withOpacity(.07)),
          icon: Icon(_searchOpen ? Icons.close_rounded : Icons.search_rounded, color: _white),
        ),
        const SizedBox(width: 6),
        PopupMenuButton<String>(
          color: _surface2,
          icon: const Icon(Icons.more_vert_rounded, color: _white),
          onSelected: (v) {
            if (v == 'refresh') _loadVideos();
            if (v == 'newest') setState(() => _newestFirst = true);
            if (v == 'oldest') setState(() => _newestFirst = false);
            if (v == 'grid') setState(() => _grid = true);
            if (v == 'list') setState(() => _grid = false);
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'newest', child: Text('Newest first')),
            PopupMenuItem(value: 'oldest', child: Text('Oldest first')),
            PopupMenuDivider(),
            PopupMenuItem(value: 'grid', child: Text('Grid view')),
            PopupMenuItem(value: 'list', child: Text('List view')),
            PopupMenuDivider(),
            PopupMenuItem(value: 'refresh', child: Text('Refresh library')),
          ],
        ),
      ]),
    );
  }

  Widget _buildSearch() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
      child: TextField(
        controller: _searchController,
        onChanged: (v) => setState(() => _query = v),
        style: const TextStyle(color: _white, fontSize: 13),
        decoration: InputDecoration(
          hintText: 'Search video names…',
          hintStyle: const TextStyle(color: _muted, fontSize: 12),
          prefixIcon: const Icon(Icons.search_rounded, color: _cyan),
          filled: true, fillColor: _surface,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withOpacity(.05))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withOpacity(.06))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: _cyan, width: 1)),
        ),
      ),
    );
  }

  Widget _buildLibraryToolbar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 2, 18, 12),
      child: Row(children: [
        Expanded(child: Text(
          _selectedFolder == null ? 'VIDEO FOLDERS' : 'VIDEOS',
          style: const TextStyle(color: _white, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.4),
        )),
        if (_selectedFolder != null) ...[
          _FilterChip(label: 'ALL', active: !_favoritesOnly, onTap: () => setState(() => _favoritesOnly = false)),
          const SizedBox(width: 7),
          _FilterChip(label: '♥', active: _favoritesOnly, onTap: () => setState(() => _favoritesOnly = true)),
          const SizedBox(width: 8),
        ],
        IconButton(
          tooltip: _grid ? 'List view' : 'Grid view',
          onPressed: () => setState(() => _grid = !_grid),
          style: IconButton.styleFrom(backgroundColor: Colors.white.withOpacity(.06), minimumSize: const Size(38, 38)),
          icon: Icon(_grid ? Icons.view_list_rounded : Icons.grid_view_rounded, color: _cyan, size: 20),
        ),
      ]),
    );
  }

  Widget _buildVideoLibrary(List<AssetEntity> items) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _cyan));
    if (_error != null) {
      return _VideoEmptyState(
        icon: Icons.video_library_rounded,
        title: 'VIDEO ACCESS REQUIRED',
        message: _error!,
        action: 'OPEN SETTINGS',
        onTap: () async { await PhotoManager.openSetting(); await _loadVideos(); },
      );
    }
    if (_selectedFolder == null) {
      if (_folders.isEmpty) {
        return _VideoEmptyState(
          icon: Icons.folder_off_rounded,
          title: 'NO VIDEO FOLDERS',
          message: 'Create or copy video folders on your phone, then refresh the library.',
          action: 'REFRESH LIBRARY',
          onTap: _loadVideos,
        );
      }
      return RefreshIndicator(
        color: _cyan,
        backgroundColor: _surface,
        onRefresh: _loadVideos,
        child: _grid
            ? GridView.builder(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12,
                  childAspectRatio: 1.18,
                ),
                itemCount: _folders.length,
                itemBuilder: (context, index) => _FolderCard(
                  folder: _folders[index],
                  grid: true,
                  onTap: () => _openFolder(_folders[index]),
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                itemCount: _folders.length,
                itemBuilder: (context, index) => _FolderCard(
                  folder: _folders[index],
                  onTap: () => _openFolder(_folders[index]),
                ),
              ),
      );
    }
    if (items.isEmpty) {
      return _VideoEmptyState(
        icon: _favoritesOnly ? Icons.favorite_border_rounded : Icons.movie_creation_outlined,
        title: _favoritesOnly ? 'NO FAVOURITES YET' : 'NO VIDEOS FOUND',
        message: _favoritesOnly ? 'Tap the heart on any video to add it to your favourites.' : 'Videos saved on your phone will appear here automatically.',
        action: 'REFRESH LIBRARY',
        onTap: _loadVideos,
      );
    }
    return RefreshIndicator(
      color: _cyan, backgroundColor: _surface, onRefresh: _loadVideos,
      child: _grid
          ? GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 13, childAspectRatio: 1.06),
              itemCount: items.length,
              itemBuilder: (context, index) => _VideoCard(
                asset: items[index], favorite: _favorites.contains(items[index].id),
                onTap: () => _openVideo(items[index]), onFavorite: () => _toggleFavorite(items[index].id),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) => _VideoListTile(
                asset: items[index], favorite: _favorites.contains(items[index].id),
                onTap: () => _openVideo(items[index]), onFavorite: () => _toggleFavorite(items[index].id),
              ),
            ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(30), onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: active ? const LinearGradient(colors: [_cyan, _purple]) : null,
        color: active ? null : Colors.white.withOpacity(.055),
        border: Border.all(color: active ? Colors.transparent : Colors.white.withOpacity(.08)),
        boxShadow: active ? [BoxShadow(color: _cyan.withOpacity(.20), blurRadius: 12)] : const [],
      ),
      child: Text(label, style: TextStyle(color: active ? Colors.black : _muted, fontSize: 10, fontWeight: FontWeight.w900)),
    ),
  );
}

class _FolderCard extends StatelessWidget {
  final AssetPathEntity folder;
  final VoidCallback onTap;
  final bool grid;
  const _FolderCard({required this.folder, required this.onTap, this.grid = false});

  @override
  Widget build(BuildContext context) {
    final icon = Container(
      width: grid ? 54 : 48,
      height: grid ? 54 : 48,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(colors: [_cyan, _purple]),
      ),
      child: Icon(grid ? Icons.video_library_rounded : Icons.folder_rounded,
          color: Colors.black, size: grid ? 30 : 27),
    );
    if (!grid) {
      return Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: _surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _cyan.withOpacity(.16)),
        ),
        child: ListTile(
          onTap: onTap,
          leading: icon,
          title: Text(folder.name, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _white, fontWeight: FontWeight.w800, fontSize: 13)),
          subtitle: FutureBuilder<int>(
            future: folder.assetCountAsync,
            builder: (context, snapshot) => Text('${snapshot.data ?? 0} videos',
              style: const TextStyle(color: _muted, fontSize: 10)),
          ),
          trailing: const Icon(Icons.chevron_right_rounded, color: _cyan),
        ),
      );
    }
    return Material(
      color: _surface,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _cyan.withOpacity(.18)),
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [_surface2.withOpacity(.92), _surface]),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [icon, const Spacer(), const Icon(Icons.arrow_outward_rounded, color: _muted, size: 18)]),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(folder.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                FutureBuilder<int>(
                  future: folder.assetCountAsync,
                  builder: (context, snapshot) => Text('${snapshot.data ?? 0} VIDEOS',
                    style: const TextStyle(color: _cyan, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.0)),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}

Future<int> _savedVideoPositionMs(String assetId) async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getInt('vortex_resume_$assetId') ?? 0;
}

class _VideoCard extends StatelessWidget {
  final AssetEntity asset;
  final bool favorite;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  const _VideoCard({required this.asset, required this.favorite, required this.onTap, required this.onFavorite});

  @override
  Widget build(BuildContext context) => Material(
    color: _surface,
    borderRadius: BorderRadius.circular(18),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Stack(fit: StackFit.expand, children: [
          AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover),
          const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0x99000000)]))),
          Center(child: Container(width: 43, height: 43, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black.withOpacity(.50), border: Border.all(color: _cyan.withOpacity(.8), width: 1.2), boxShadow: [BoxShadow(color: _cyan.withOpacity(.25), blurRadius: 16)]), child: const Icon(Icons.play_arrow_rounded, color: _white, size: 28))),
          Positioned(left: 9, bottom: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4), decoration: BoxDecoration(color: Colors.black.withOpacity(.70), borderRadius: BorderRadius.circular(7)), child: Text(_formatDuration(asset.duration), style: const TextStyle(color: _white, fontSize: 9, fontWeight: FontWeight.w800)))),
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: FutureBuilder<int>(
              future: _savedVideoPositionMs(asset.id),
              builder: (context, snapshot) {
                final saved = snapshot.data ?? 0;
                final totalMs = asset.duration * 1000;
                if (saved <= 1500 || totalMs <= 0) return const SizedBox(height: 3);
                final ratio = (saved / totalMs).clamp(0.0, 1.0).toDouble();
                return LinearProgressIndicator(value: ratio, minHeight: 3, backgroundColor: Colors.white24, valueColor: const AlwaysStoppedAnimation<Color>(_cyan));
              },
            ),
          ),
          Positioned(right: 5, top: 5, child: IconButton(onPressed: onFavorite, visualDensity: VisualDensity.compact, style: IconButton.styleFrom(backgroundColor: Colors.black.withOpacity(.48)), icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: favorite ? const Color(0xFFFF6F9D) : _white, size: 17))),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 10, fontWeight: FontWeight.w700)),
          FutureBuilder<int>(
            future: _savedVideoPositionMs(asset.id),
            builder: (context, snapshot) {
              final saved = snapshot.data ?? 0;
              final totalMs = asset.duration * 1000;
              if (saved <= 1500 || totalMs <= 0 || saved >= totalMs - 3000) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text('Watched until ${_formatClock(Duration(milliseconds: saved))}', style: const TextStyle(color: _cyan, fontSize: 8, fontWeight: FontWeight.w700)),
              );
            },
          ),
        ])),
      ]),
    ),
  );
}

class _VideoListTile extends StatelessWidget {
  final AssetEntity asset;
  final bool favorite;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  const _VideoListTile({required this.asset, required this.favorite, required this.onTap, required this.onFavorite});
  @override
  Widget build(BuildContext context) => Material(
    color: _surface, borderRadius: BorderRadius.circular(16), clipBehavior: Clip.antiAlias,
    child: ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.all(7),
      leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: SizedBox(width: 82, height: 58, child: Stack(fit: StackFit.expand, children: [AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover), const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 27))]))),
      title: Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w800)),
      subtitle: FutureBuilder<int>(
        future: _savedVideoPositionMs(asset.id),
        builder: (context, snapshot) {
          final saved = snapshot.data ?? 0;
          final totalMs = asset.duration * 1000;
          final watched = saved > 1500 && totalMs > 0 && saved < totalMs - 3000;
          return Text(
            watched
                ? '${_formatDuration(asset.duration)}  •  Watched until ${_formatClock(Duration(milliseconds: saved))}'
                : '${_formatDuration(asset.duration)}  •  ${_formatDate(asset.createDateTime)}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: watched ? _cyan : _muted, fontSize: 9),
          );
        },
      ),
      trailing: IconButton(onPressed: onFavorite, icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: favorite ? const Color(0xFFFF6F9D) : _muted, size: 19)),
    ),
  );
}

class _VideoEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String action;
  final VoidCallback onTap;
  const _VideoEmptyState({required this.icon, required this.title, required this.message, required this.action, required this.onTap});
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(30),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 86, height: 86, decoration: BoxDecoration(shape: BoxShape.circle, color: _surface2, border: Border.all(color: _cyan.withOpacity(.24)), boxShadow: [BoxShadow(color: _purple.withOpacity(.13), blurRadius: 24)]), child: Icon(icon, color: _cyan, size: 39)),
      const SizedBox(height: 18),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
      const SizedBox(height: 9),
      Text(message, textAlign: TextAlign.center, style: const TextStyle(color: _muted, height: 1.5, fontSize: 11)),
      const SizedBox(height: 18),
      FilledButton(onPressed: onTap, style: FilledButton.styleFrom(backgroundColor: _cyan, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)), child: Text(action, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1))),
    ]),
  ));
}

class VideoPlayerPage extends StatefulWidget {
  final AssetEntity asset;
  final List<AssetEntity> playlist;
  final int initialIndex;
  final int initialPositionMs;
  final bool Function(String) isFavorite;
  final bool initiallyFavorite;
  final void Function(String) onFavorite;
  final Future<void> Function(List<AssetEntity>) onShare;

  const VideoPlayerPage({
    super.key,
    required this.asset,
    required this.playlist,
    required this.initialIndex,
    required this.initialPositionMs,
    required this.isFavorite,
    required this.initiallyFavorite,
    required this.onFavorite,
    required this.onShare,
  });

  @override
  State<VideoPlayerPage> createState() => _VideoPlayerPageState();
}

class _VideoPlayerPageState extends State<VideoPlayerPage> with WidgetsBindingObserver {
  late AssetEntity _currentAsset;
  late int _currentIndex;
  bool _locked = false;
  int _fitMode = 0; // 0 contain, 1 cover, 2 16:9 frame.
  Player? _player;
  VideoController? _videoController;
  StreamSubscription<bool>? _playingSubscription;
  StreamSubscription<String>? _errorSubscription;
  Timer? _progressSaveTimer;
  String? _error;
  bool _loading = true;
  bool _isMuted = false;
  int _initialPositionMs = 0;
  bool _favorite = false;
  double _volume = 1.0; // 0.0 to 2.0 (0% to 200%).
  double _speed = 1.0;
  Duration? _dragPosition;
  bool _controlsVisible = true;
  Timer? _controlsTimer;

  // Gesture controls: left-side vertical drag = brightness, right-side = volume.
  static const MethodChannel _brightnessChannel = MethodChannel('vortex_player/brightness');
  double _brightness = 0.5;
  double _gestureStartValue = 0.5;
  double _gestureStartY = 0.0;
  String? _gestureKind;
  bool _temporarySpeedActive = false;
  bool _showGestureHud = false;
  String _gestureHudText = '';
  Timer? _gestureHudTimer;
  double _horizontalDragDx = 0.0;
  Duration _horizontalStartPosition = Duration.zero;
  List<int> _bookmarks = [];
  Timer? _sleepTimer;
  int? _sleepTimerMinutes;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _currentAsset = widget.asset;
    _currentIndex = widget.playlist.isEmpty ? 0 : widget.initialIndex.clamp(0, widget.playlist.length - 1).toInt();
    _favorite = widget.initiallyFavorite;
    _initialPositionMs = widget.initialPositionMs;
    unawaited(_loadBookmarks());
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _readSystemBrightness();
    _initialiseVideo();
  }

  Future<void> _loadBookmarks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final values = (prefs.getStringList('vortex_bookmarks_${_currentAsset.id}') ?? [])
          .map((value) => int.tryParse(value))
          .whereType<int>()
          .toSet()
          .toList()
        ..sort();
      if (mounted) setState(() => _bookmarks = values);
    } catch (_) {}
  }

  Future<void> _addBookmark() async {
    final player = _player;
    if (player == null) return;
    final ms = player.state.position.inMilliseconds;
    if (ms < 1000) {
      _showPlayerMessage('Play the video for a moment before bookmarking.');
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final key = 'vortex_bookmarks_${_currentAsset.id}';
    final values = (prefs.getStringList(key) ?? [])
        .map((value) => int.tryParse(value))
        .whereType<int>()
        .toSet();
    if (!values.any((value) => (value - ms).abs() < 2500)) values.add(ms);
    final sorted = values.toList()..sort();
    await prefs.setStringList(key, sorted.map((value) => value.toString()).toList());
    if (mounted) setState(() => _bookmarks = sorted);
    _showPlayerMessage('Bookmark saved at ${_formatClock(Duration(milliseconds: ms))}.');
  }

  Future<void> _openBookmarks() async {
    if (_bookmarks.isEmpty) {
      _showPlayerMessage('No bookmarks saved for this video yet.');
      return;
    }
    _cancelControlsTimer();
    final selected = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: _surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8))),
            const SizedBox(height: 16),
            const Align(alignment: Alignment.centerLeft, child: Text('BOOKMARKS', style: TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5))),
            const SizedBox(height: 8),
            ..._bookmarks.reversed.map((ms) => ListTile(
              dense: true,
              leading: const Icon(Icons.bookmark_rounded, color: _cyan),
              title: Text(_formatClock(Duration(milliseconds: ms)), style: const TextStyle(color: _white, fontWeight: FontWeight.w800)),
              subtitle: const Text('Tap to jump to this point', style: TextStyle(color: _muted, fontSize: 10)),
              onTap: () => Navigator.pop(sheetContext, ms),
            )),
          ]),
        ),
      ),
    );
    if (!mounted) return;
    if (selected != null && _player != null) {
      await _player!.seek(Duration(milliseconds: selected));
      await _savePlaybackProgress();
      if (mounted) setState(() => _controlsVisible = true);
      _scheduleControlsHide();
    } else {
      _scheduleControlsHide();
    }
  }

  Future<void> _chooseSleepTimer() async {
    _cancelControlsTimer();
    final selected = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: _surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8))),
            const SizedBox(height: 16),
            const Align(alignment: Alignment.centerLeft, child: Text('SLEEP TIMER', style: TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5))),
            const SizedBox(height: 8),
            ...[0, 15, 30, 45, 60, 90].map((minutes) => ListTile(
              dense: true,
              leading: Icon(minutes == 0 ? Icons.timer_off_rounded : Icons.bedtime_rounded, color: _cyan),
              title: Text(minutes == 0 ? 'Turn off timer' : '$minutes minutes', style: const TextStyle(color: _white)),
              trailing: _sleepTimerMinutes == minutes ? const Icon(Icons.check_circle_rounded, color: _cyan) : null,
              onTap: () => Navigator.pop(sheetContext, minutes),
            )),
          ]),
        ),
      ),
    );
    if (!mounted) return;
    if (selected == null) { _scheduleControlsHide(); return; }
    _sleepTimer?.cancel();
    if (selected == 0) {
      if (mounted) setState(() => _sleepTimerMinutes = null);
      _showPlayerMessage('Sleep timer turned off.');
    } else {
      if (mounted) setState(() => _sleepTimerMinutes = selected);
      _sleepTimer = Timer(Duration(minutes: selected), () async {
        await _player?.pause();
        await _savePlaybackProgress();
        if (!mounted) return;
        setState(() { _sleepTimerMinutes = null; _controlsVisible = true; });
        _cancelControlsTimer();
        _showPlayerMessage('Sleep timer paused playback.');
      });
      _showPlayerMessage('Playback will pause in $selected minutes.');
    }
    _scheduleControlsHide();
  }

  Future<void> _showPlayingQueue() async {
    if (widget.playlist.isEmpty) return;
    _cancelControlsTimer();
    final index = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: _surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .62,
          child: Column(children: [
            const SizedBox(height: 12),
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8))),
            const Padding(padding: EdgeInsets.fromLTRB(18, 16, 18, 10), child: Align(alignment: Alignment.centerLeft, child: Text('PLAYING QUEUE', style: TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.5)))),
            Expanded(child: ListView.builder(
              itemCount: widget.playlist.length,
              itemBuilder: (context, i) {
                final asset = widget.playlist[i];
                return ListTile(
                  selected: i == _currentIndex,
                  leading: ClipRRect(borderRadius: BorderRadius.circular(8), child: SizedBox(width: 62, height: 42, child: AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover))),
                  title: Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: i == _currentIndex ? _cyan : _white, fontSize: 12, fontWeight: FontWeight.w700)),
                  subtitle: Text(_formatDuration(asset.duration), style: const TextStyle(color: _muted, fontSize: 10)),
                  trailing: i == _currentIndex ? const Icon(Icons.equalizer_rounded, color: _cyan) : null,
                  onTap: () => Navigator.pop(sheetContext, i),
                );
              },
            )),
          ]),
        ),
      ),
    );
    if (!mounted) return;
    if (index != null && index != _currentIndex) await _playQueueIndex(index);
    _scheduleControlsHide();
  }

  Future<void> _playQueueIndex(int index) async {
    if (index < 0 || index >= widget.playlist.length) return;
    await _savePlaybackProgress();
    final asset = widget.playlist[index];
    final prefs = await SharedPreferences.getInstance();
    final savedMs = prefs.getInt('vortex_resume_${asset.id}') ?? 0;
    final durationMs = asset.duration * 1000;
    final hasProgress = savedMs > 3000 && (durationMs <= 0 || savedMs < durationMs - 3000);
    var startMs = 0;
    if (hasProgress) {
      final choice = await showDialog<int>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          backgroundColor: _surface2,
          title: const Text('Continue watching?', style: TextStyle(color: _white, fontWeight: FontWeight.w800)),
          content: Text('You watched until ${_formatClock(Duration(milliseconds: savedMs))}.', style: const TextStyle(color: _muted, fontSize: 13)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, 0), child: const Text('START FROM BEGINNING')),
            FilledButton(style: FilledButton.styleFrom(backgroundColor: _cyan, foregroundColor: Colors.black), onPressed: () => Navigator.pop(dialogContext, savedMs), child: const Text('CONTINUE')),
          ],
        ),
      );
      if (choice == null || !mounted) return;
      startMs = choice;
    }
    if (!mounted) return;
    setState(() {
      _currentIndex = index;
      _currentAsset = asset;
      _initialPositionMs = startMs;
      _favorite = widget.isFavorite(asset.id);
      _controlsVisible = true;
    });
    await _initialiseVideo();
  }

  void _showPlayerMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)));
  }

  Future<void> _readSystemBrightness() async {
    try {
      final value = await _brightnessChannel.invokeMethod<double>('getSystemBrightness');
      if (mounted && value != null) {
        setState(() => _brightness = value.clamp(0.05, 1.0).toDouble());
      }
    } catch (_) {
      // Brightness gestures remain unavailable if the native channel is unavailable.
    }
  }

  Future<void> _applyScreenBrightness(double value) async {
    try {
      await _brightnessChannel.invokeMethod<void>('setBrightness', {'value': value});
    } catch (_) {
      // Keep video playback working even if a device rejects brightness changes.
    }
  }

  Future<void> _resetScreenBrightness() async {
    try {
      await _brightnessChannel.invokeMethod<void>('resetBrightness');
    } catch (_) {}
  }

  void _showGestureMessage(String message) {
    _gestureHudTimer?.cancel();
    if (mounted) {
      setState(() {
        _showGestureHud = true;
        _gestureHudText = message;
      });
    }
    _gestureHudTimer = Timer(const Duration(milliseconds: 1100), () {
      if (mounted && _gestureKind == null && !_temporarySpeedActive) {
        setState(() => _showGestureHud = false);
      }
    });
  }

  void _cancelControlsTimer() {
    _controlsTimer?.cancel();
    _controlsTimer = null;
  }

  void _scheduleControlsHide() {
    _cancelControlsTimer();
    final player = _player;
    if (!mounted || !_controlsVisible || player == null || !player.state.playing || _dragPosition != null || _gestureKind != null || _temporarySpeedActive) {
      return;
    }
    _controlsTimer = Timer(const Duration(seconds: 3), () {
      if (!mounted) return;
      final current = _player;
      if (current != null && current.state.playing && _dragPosition == null) {
        setState(() => _controlsVisible = false);
      }
    });
  }

  void _toggleControls() {
    if (!_controlsVisible) {
      setState(() => _controlsVisible = true);
      _scheduleControlsHide();
    } else if (_player?.state.playing == true) {
      _cancelControlsTimer();
      setState(() => _controlsVisible = false);
    } else {
      _cancelControlsTimer();
      setState(() => _controlsVisible = true);
    }
  }

  Future<void> _initialiseVideo() async {
    _cancelControlsTimer();
    _bookmarks = [];
    unawaited(_loadBookmarks());
    _progressSaveTimer?.cancel();
    await _readSystemBrightness();
    final previous = _player;
    _player = null;
    _videoController = null;
    await _playingSubscription?.cancel();
    await _errorSubscription?.cancel();
    if (previous != null) {
      await previous.dispose();
    }
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
      _controlsVisible = true;
    });

    Player? pendingPlayer;
    try {
      final file = await _currentAsset.file;
      if (file == null) throw Exception('Video file unavailable');

      // media_kit uses bundled libmpv/FFmpeg decoders rather than relying only
      // on Android's built-in codecs, allowing formats such as E-AC-3 (EAC3).
      final player = Player();
      pendingPlayer = player;
      final videoController = VideoController(player);
      _player = player;
      _videoController = videoController;

      _volume = 1.0;
      _isMuted = false;
      _speed = 1.0;
      if (player.platform is NativePlayer) {
        try {
          await (player.platform as NativePlayer).setProperty('volume-max', '200');
        } catch (_) {
          // Playback remains available even if this mpv build cannot raise its volume ceiling.
        }
      }
      await player.setVolume(_volume * 100.0);
      await player.setRate(1.0);

      _playingSubscription = player.stream.playing.listen((playing) {
        if (!mounted) return;
        if (playing) {
          _scheduleControlsHide();
        } else {
          _cancelControlsTimer();
          if (!_controlsVisible) setState(() => _controlsVisible = true);
        }
      });
      _errorSubscription = player.stream.error.listen((message) {
        if (!mounted || message.trim().isEmpty) return;
        setState(() {
          _error = 'આ વિડિયો ચલાવવામાં સમસ્યા આવી: $message';
          _loading = false;
        });
      });

      await player.open(Media(file.path), play: false);
      // Wait for the media duration to become available before seeking. Seeking
      // immediately after open can be ignored by some demuxers on slower phones.
      var mediaDuration = player.state.duration;
      if (mediaDuration <= Duration.zero) {
        try {
          mediaDuration = await player.stream.duration
              .firstWhere((value) => value > Duration.zero)
              .timeout(const Duration(seconds: 6));
        } catch (_) {
          mediaDuration = player.state.duration;
        }
      }
      final prefs = await SharedPreferences.getInstance();
      final requestedMs = _initialPositionMs < 0 ? 0 : _initialPositionMs;
      final nearlyFinished = mediaDuration > Duration.zero &&
          Duration(milliseconds: requestedMs) >= mediaDuration - const Duration(seconds: 3);
      final boundedMs = mediaDuration > Duration.zero
          ? requestedMs.clamp(0, (mediaDuration - const Duration(seconds: 2)).inMilliseconds.clamp(0, 1 << 62)).toInt()
          : requestedMs;
      final startMs = nearlyFinished ? 0 : boundedMs;
      if (startMs > 1500) {
        final targetPosition = Duration(milliseconds: startMs);
        await player.seek(targetPosition);
        await Future.delayed(const Duration(milliseconds: 350));
        if ((player.state.position - targetPosition).inMilliseconds.abs() > 2500) {
          await player.seek(targetPosition);
          await Future.delayed(const Duration(milliseconds: 250));
        }
      }
      await prefs.setInt('vortex_resume_${_currentAsset.id}', startMs);
      await prefs.setString('vortex_last_asset_id', _currentAsset.id);
      await prefs.setString('vortex_last_asset_title', _currentAsset.title ?? 'Last played video');
      await prefs.setInt('vortex_last_position_ms', startMs);
      _initialPositionMs = startMs;
      await player.play();
      if (!mounted) {
        await player.dispose();
        return;
      }
      setState(() => _loading = false);
      _progressSaveTimer = Timer.periodic(const Duration(seconds: 2), (_) {
        unawaited(_savePlaybackProgress());
      });
      _scheduleControlsHide();
    } catch (e) {
      await _playingSubscription?.cancel();
      await _errorSubscription?.cancel();
      if (pendingPlayer != null) {
        await pendingPlayer.dispose();
      }
      if (mounted) {
        setState(() {
          _player = null;
          _videoController = null;
          _loading = false;
          _error = 'આ વિડિયો ખોલી શકાયો નથી. ફાઇલ અથવા video format તપાસો. ($e)';
        });
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      unawaited(_savePlaybackProgress());
    }
  }

  Future<void> _savePlaybackProgress() async {
    final player = _player;
    if (player == null) return;
    final assetId = _currentAsset.id;
    final assetTitle = _currentAsset.title ?? 'Last played video';
    final position = player.state.position;
    final duration = player.state.duration;
    final completed = duration > Duration.zero &&
        position >= duration - const Duration(seconds: 3);
    final safeMs = completed ? 0 : position.inMilliseconds.clamp(0, 1 << 62).toInt();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('vortex_resume_$assetId', safeMs);
      await prefs.setString('vortex_last_asset_id', assetId);
      await prefs.setString('vortex_last_asset_title', assetTitle);
      await prefs.setInt('vortex_last_position_ms', safeMs);
    } catch (_) {
      // Resume data is best-effort; playback must continue even if storage fails.
    }
  }

  Future<void> _setVolume(double value) async {
    final player = _player;
    if (player == null) return;
    setState(() {
      _volume = value.clamp(0.0, 2.0).toDouble();
      _isMuted = _volume <= 0.001;
    });
    await player.setVolume(_volume * 100.0);
    _scheduleControlsHide();
  }

  Future<void> _toggleMute() async {
    final player = _player;
    if (player == null) return;
    if (_isMuted) {
      await _setVolume(_volume <= 0.001 ? 1.0 : _volume);
    } else {
      setState(() => _isMuted = true);
      await player.setVolume(0.0);
    }
    _scheduleControlsHide();
  }

  Future<void> _togglePlay() async {
    final player = _player;
    if (player == null) return;
    if (player.state.playing) {
      await player.pause();
      await _savePlaybackProgress();
      _cancelControlsTimer();
      if (mounted) setState(() => _controlsVisible = true);
    } else {
      if (player.state.completed ||
          (player.state.duration > Duration.zero && player.state.position >= player.state.duration)) {
        await player.seek(Duration.zero);
      }
      await player.play();
      if (mounted) {
        setState(() => _controlsVisible = true);
        _scheduleControlsHide();
      }
    }
  }

  Future<void> _playAdjacent(int delta) async {
    if (widget.playlist.isEmpty) return;
    final next = (_currentIndex + delta).clamp(0, widget.playlist.length - 1).toInt();
    if (next == _currentIndex) return;
    await _playQueueIndex(next);
  }

  void _cycleFitMode() {
    setState(() => _fitMode = (_fitMode + 1) % 3);
    _showGestureMessage(['FIT: CONTAIN', 'FIT: FILL', 'FIT: 16:9'][_fitMode]);
  }

  void _toggleLock() {
    setState(() {
      _locked = !_locked;
      if (_locked) _controlsVisible = false;
      else _controlsVisible = true;
    });
    if (_locked) _cancelControlsTimer(); else _scheduleControlsHide();
  }

  Future<void> _skipBy(int seconds) async {
    final player = _player;
    if (player == null) return;
    final target = player.state.position + Duration(seconds: seconds);
    final max = player.state.duration;
    final clamped = target < Duration.zero ? Duration.zero : (target > max ? max : target);
    await player.seek(clamped);
    await _savePlaybackProgress();
    _scheduleControlsHide();
  }

  Future<void> _changeSpeed(double value) async {
    final player = _player;
    if (player == null) return;
    await player.setRate(value);
    if (mounted) setState(() => _speed = value);
    _scheduleControlsHide();
  }

  void _onVideoVerticalDragStart(DragStartDetails details, double videoHeight) {
    final screenWidth = MediaQuery.of(context).size.width;
    _gestureKind = details.localPosition.dx < screenWidth / 2 ? 'brightness' : 'volume';
    _gestureStartY = details.localPosition.dy;
    _gestureStartValue = _gestureKind == 'brightness' ? _brightness : _volume;
    _gestureHudTimer?.cancel();
    _cancelControlsTimer();
    setState(() {
      _controlsVisible = false;
      _showGestureHud = true;
      _gestureHudText = _gestureKind == 'brightness'
          ? '☀  Brightness ${( _brightness * 100).round()}%'
          : '🔊  Volume ${(_volume * 100).round()}%';
    });
  }

  void _onVideoVerticalDragUpdate(DragUpdateDetails details, double videoHeight) {
    if (_gestureKind == null) return;
    final delta = (_gestureStartY - details.localPosition.dy) / (videoHeight * 0.72).clamp(140.0, 520.0);
    if (_gestureKind == 'brightness') {
      final next = (_gestureStartValue + delta).clamp(0.05, 1.0).toDouble();
      if ((next - _brightness).abs() >= 0.012) {
        setState(() {
          _brightness = next;
          _gestureHudText = '☀  Brightness ${(next * 100).round()}%';
        });
        unawaited(_applyScreenBrightness(next));
      }
    } else {
      final next = (_gestureStartValue + delta * 2.0).clamp(0.0, 2.0).toDouble();
      if ((next - _volume).abs() >= 0.012) {
        setState(() {
          _volume = next;
          _isMuted = next <= 0.001;
          _gestureHudText = next > 1.0
              ? '🔊  Volume Boost ${(next * 100).round()}%'
              : '🔊  Volume ${(next * 100).round()}%';
        });
        unawaited(_player?.setVolume(next * 100.0) ?? Future<void>.value());
      }
    }
  }

  void _onVideoVerticalDragEnd(DragEndDetails details) {
    _gestureKind = null;
    _showGestureMessage(_gestureHudText);
    _scheduleControlsHide();
  }

  void _onVideoHorizontalDragStart(DragStartDetails details) {
    _horizontalDragDx = 0;
    _horizontalStartPosition = _player?.state.position ?? Duration.zero;
    _cancelControlsTimer();
    if (mounted) setState(() { _controlsVisible = false; _showGestureHud = false; });
  }

  void _onVideoHorizontalDragUpdate(DragUpdateDetails details) {
    _horizontalDragDx += details.delta.dx;
    final seconds = (_horizontalDragDx / 70).round() * 5;
    if (seconds == 0) return;
    if (mounted) {
      setState(() {
        _showGestureHud = true;
        _gestureHudText = seconds > 0 ? '⏩ +${seconds}s' : '⏪ ${seconds}s';
      });
    }
  }

  Future<void> _onVideoHorizontalDragEnd(DragEndDetails details) async {
    final seconds = (_horizontalDragDx / 70).round() * 5;
    _horizontalDragDx = 0;
    final player = _player;
    if (player != null && seconds != 0) {
      final target = _horizontalStartPosition + Duration(seconds: seconds);
      final duration = player.state.duration;
      final clamped = target < Duration.zero
          ? Duration.zero
          : (duration > Duration.zero && target > duration ? duration : target);
      await player.seek(clamped);
      await _savePlaybackProgress();
      _showGestureMessage(seconds > 0 ? '⏩ +${seconds}s' : '⏪ ${seconds}s');
    } else {
      if (mounted) setState(() => _showGestureHud = false);
    }
    _scheduleControlsHide();
  }

  Future<void> _startTemporary2x(LongPressStartDetails details) async {
    final width = MediaQuery.of(context).size.width;
    if (details.localPosition.dx < width * 0.52) return;
    final player = _player;
    if (player == null) return;
    _temporarySpeedActive = true;
    _gestureHudTimer?.cancel();
    await player.setRate(2.0);
    if (!mounted) return;
    setState(() {
      _speed = 2.0;
      _showGestureHud = true;
      _gestureHudText = '2.0×  SPEED';
      _controlsVisible = false;
    });
    _cancelControlsTimer();
  }

  Future<void> _endTemporary2x() async {
    if (!_temporarySpeedActive) return;
    _temporarySpeedActive = false;
    final player = _player;
    if (player != null) await player.setRate(1.0);
    if (!mounted) return;
    setState(() {
      _speed = 1.0;
      _gestureHudText = '1.0×  NORMAL';
    });
    _showGestureMessage(_gestureHudText);
    _scheduleControlsHide();
  }

  String _audioTrackName(AudioTrack track) {
    if (track.id == 'no') return 'Off';
    final language = track.language?.trim();
    final title = track.title?.trim();
    final details = [if (language != null && language.isNotEmpty) language, if (title != null && title.isNotEmpty) title];
    return details.isEmpty ? 'Audio track ${track.id}' : details.join(' • ');
  }

  String _subtitleTrackName(SubtitleTrack track) {
    if (track.id == 'no') return 'Off';
    final language = track.language?.trim();
    final title = track.title?.trim();
    final details = [if (language != null && language.isNotEmpty) language, if (title != null && title.isNotEmpty) title];
    return details.isEmpty ? 'Subtitle ${track.id}' : details.join(' • ');
  }

  Future<void> _openAudioTrackSettings(Player player) async {
    _cancelControlsTimer();
    final audioTracks = player.state.tracks.audio;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 26),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 18),
            const Text('AUDIO TRACK', style: TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
            const SizedBox(height: 12),
            if (audioTracks.where((track) => track.id != 'auto' && track.id != 'no').isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('This video has only one audio track.', style: TextStyle(color: _muted, fontSize: 12)))
            else
              ...audioTracks.where((track) => track.id != 'auto').map((track) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.audiotrack_rounded, color: _cyan),
                title: Text(_audioTrackName(track), style: const TextStyle(color: _white, fontSize: 13)),
                trailing: player.state.track.audio.id == track.id ? const Icon(Icons.check_circle_rounded, color: _cyan) : null,
                onTap: () async {
                  await player.setAudioTrack(track);
                  if (mounted) setState(() {});
                  if (sheetContext.mounted) Navigator.pop(sheetContext);
                },
              )),
          ]),
        ),
      ),
    );
    _scheduleControlsHide();
  }

  Future<void> _openSubtitleTrackSettings(Player player) async {
    _cancelControlsTimer();
    final subtitleTracks = player.state.tracks.subtitle;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 26),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 18),
            const Text('SUBTITLES', style: TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
            const SizedBox(height: 12),
            if (subtitleTracks.where((track) => track.id != 'auto' && track.id != 'no').isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('No embedded subtitles found in this video.', style: TextStyle(color: _muted, fontSize: 12)))
            else
              ...subtitleTracks.where((track) => track.id != 'auto').map((track) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.subtitles_rounded, color: _cyan),
                title: Text(_subtitleTrackName(track), style: const TextStyle(color: _white, fontSize: 13)),
                trailing: player.state.track.subtitle.id == track.id ? const Icon(Icons.check_circle_rounded, color: _cyan) : null,
                onTap: () async {
                  await player.setSubtitleTrack(track);
                  if (mounted) setState(() {});
                  if (sheetContext.mounted) Navigator.pop(sheetContext);
                },
              )),
          ]),
        ),
      ),
    );
    _scheduleControlsHide();
  }

  Future<void> _shareVideo() async {
    await widget.onShare([_currentAsset]);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cancelControlsTimer();
    _progressSaveTimer?.cancel();
    _sleepTimer?.cancel();
    unawaited(_savePlaybackProgress());
    _gestureHudTimer?.cancel();
    unawaited(_brightnessChannel.invokeMethod<void>('resetBrightness').catchError((_) {}));
    final player = _player;
    if (player != null) {
      unawaited(_playingSubscription?.cancel());
      unawaited(_errorSubscription?.cancel());
      unawaited(player.dispose());
    }
    SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Widget _compactControlButton({
    required IconData icon,
    required VoidCallback? onPressed,
    String? tooltip,
    Color color = Colors.white,
    double iconSize = 21,
    double width = 34,
  }) {
    return SizedBox(
      width: width,
      height: 42,
      child: IconButton(
        tooltip: tooltip,
        onPressed: onPressed,
        padding: EdgeInsets.zero,
        constraints: BoxConstraints.tightFor(width: width, height: 42),
        visualDensity: VisualDensity.compact,
        style: IconButton.styleFrom(
          backgroundColor: width > 40 ? _cyan.withOpacity(.16) : Colors.black.withOpacity(.30),
          shape: const CircleBorder(),
        ),
        icon: Icon(icon, color: onPressed == null ? Colors.white24 : color, size: iconSize),
      ),
    );
  }

  Widget _buildControls(Player player, Duration position, Duration duration, bool playing) {
    final shownPosition = _dragPosition ?? position;
    final totalMs = duration.inMilliseconds > 0 ? duration.inMilliseconds.toDouble() : 1.0;
    final progress = shownPosition.inMilliseconds.clamp(0, duration.inMilliseconds).toDouble();
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 2),
      child: SafeArea(
        top: false,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            Text(_formatClock(shownPosition), style: const TextStyle(color: _white, fontSize: 10, fontWeight: FontWeight.w700)),
            Expanded(child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                trackHeight: 2.5,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 13),
              ),
              child: Slider(
                value: progress.clamp(0.0, totalMs).toDouble(), min: 0, max: totalMs,
                activeColor: _cyan, inactiveColor: Colors.white30,
                onChanged: (value) { _cancelControlsTimer(); setState(() => _dragPosition = Duration(milliseconds: value.round())); },
                onChangeEnd: (value) async {
                  await player.seek(Duration(milliseconds: value.round()));
                  await _savePlaybackProgress();
                  if (mounted) { setState(() => _dragPosition = null); _scheduleControlsHide(); }
                },
              ),
            )),
            Text(_formatClock(duration), style: const TextStyle(color: _white, fontSize: 10, fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 2),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            _compactControlButton(icon: _locked ? Icons.lock_rounded : Icons.lock_open_rounded, tooltip: 'Lock controls', onPressed: _toggleLock, color: _cyan),
            _compactControlButton(icon: _isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded, tooltip: _isMuted ? 'Unmute' : 'Mute', onPressed: _toggleMute, color: _cyan),
            _compactControlButton(icon: Icons.skip_previous_rounded, tooltip: 'Previous video', onPressed: _currentIndex > 0 ? () => _playAdjacent(-1) : null),
            _compactControlButton(icon: Icons.replay_10_rounded, tooltip: '10 seconds back', onPressed: () => _skipBy(-10)),
            _compactControlButton(icon: playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded, tooltip: playing ? 'Pause' : 'Play', onPressed: _togglePlay, color: _cyan, iconSize: 43, width: 48),
            _compactControlButton(icon: Icons.forward_10_rounded, tooltip: '10 seconds forward', onPressed: () => _skipBy(10)),
            _compactControlButton(icon: Icons.skip_next_rounded, tooltip: 'Next video', onPressed: _currentIndex < widget.playlist.length - 1 ? () => _playAdjacent(1) : null),
            SizedBox(
              width: 42,
              child: PopupMenuButton<double>(
                tooltip: 'Playback speed', initialValue: _speed, color: _surface2, onSelected: _changeSpeed,
                padding: EdgeInsets.zero,
                itemBuilder: (_) => const [
                  PopupMenuItem(value: .5, child: Text('0.5×')),
                  PopupMenuItem(value: .75, child: Text('0.75×')),
                  PopupMenuItem(value: 1.0, child: Text('1.0× Normal')),
                  PopupMenuItem(value: 1.25, child: Text('1.25×')),
                  PopupMenuItem(value: 1.5, child: Text('1.5×')),
                  PopupMenuItem(value: 2.0, child: Text('2.0×')),
                ],
                child: Center(child: Text('${_speed.toStringAsFixed(1)}×', style: const TextStyle(color: _white, fontSize: 10, fontWeight: FontWeight.w900))),
              ),
            ),
            _compactControlButton(icon: Icons.fit_screen_rounded, tooltip: 'Change fit mode', onPressed: _cycleFitMode, color: _cyan),
          ]),
          if (_sleepTimerMinutes != null)
            Padding(padding: const EdgeInsets.only(top: 3), child: Text('SLEEP TIMER • $_sleepTimerMinutes MIN', style: const TextStyle(color: _mint, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1.1))),
        ]),
      ),
    );
  }

  Widget _buildGestureHud() {
    final isVolume = _gestureKind == 'volume';
    final value = isVolume ? (_volume / 2).clamp(0.0, 1.0).toDouble() : _brightness.clamp(0.0, 1.0).toDouble();
    final percent = isVolume ? (_volume * 100).round() : (_brightness * 100).round();
    return Container(
      width: 210,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xE8171A22),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _cyan.withOpacity(.65)),
        boxShadow: [BoxShadow(color: _cyan.withOpacity(.12), blurRadius: 24)],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          Icon(isVolume ? Icons.volume_up_rounded : Icons.brightness_6_rounded, color: _cyan, size: 22),
          const SizedBox(width: 10),
          Expanded(child: Text(isVolume ? (percent > 100 ? 'VOLUME BOOST' : 'VOLUME') : 'BRIGHTNESS', style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.1))),
          Text('$percent%', style: const TextStyle(color: _cyan, fontSize: 15, fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: LinearProgressIndicator(value: value, minHeight: 6, backgroundColor: Colors.white12, valueColor: const AlwaysStoppedAnimation<Color>(_cyan)),
        ),
      ]),
    );
  }

  Widget _buildPlayer(Player player, VideoController videoController) {
    return StreamBuilder<bool>(
      stream: player.stream.playing,
      initialData: player.state.playing,
      builder: (context, playingSnapshot) {
        final playing = playingSnapshot.data ?? player.state.playing;
        return StreamBuilder<Duration>(
          stream: player.stream.duration,
          initialData: player.state.duration,
          builder: (context, durationSnapshot) {
            final duration = durationSnapshot.data ?? player.state.duration;
            return StreamBuilder<Duration>(
              stream: player.stream.position,
              initialData: player.state.position,
              builder: (context, positionSnapshot) {
                final position = positionSnapshot.data ?? player.state.position;
                return Stack(fit: StackFit.expand, children: [
                  Positioned.fill(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: _locked ? null : _toggleControls,
                      onLongPressStart: _locked ? null : _startTemporary2x,
                      onLongPressEnd: _locked ? null : (_) => _endTemporary2x(),
                      onVerticalDragStart: _locked ? null : (details) => _onVideoVerticalDragStart(details, MediaQuery.of(context).size.height),
                      onVerticalDragUpdate: _locked ? null : (details) => _onVideoVerticalDragUpdate(details, MediaQuery.of(context).size.height),
                      onVerticalDragEnd: _locked ? null : _onVideoVerticalDragEnd,
                      onHorizontalDragStart: _locked ? null : _onVideoHorizontalDragStart,
                      onHorizontalDragUpdate: _locked ? null : _onVideoHorizontalDragUpdate,
                      onHorizontalDragEnd: _locked ? null : _onVideoHorizontalDragEnd,
                      child: _fitMode == 2
                          ? Center(child: AspectRatio(
                              aspectRatio: 16 / 9,
                              child: Video(controller: videoController, controls: NoVideoControls, fit: BoxFit.contain),
                            ))
                          : Video(
                              controller: videoController,
                              controls: NoVideoControls,
                              fit: _fitMode == 1 ? BoxFit.cover : BoxFit.contain,
                            ),
                    ),
                  ),
                  if (player.state.buffering)
                    const IgnorePointer(child: Center(child: CircularProgressIndicator(color: _cyan))),
                  if (_showGestureHud)
                    IgnorePointer(child: Center(child: _gestureKind == null
                        ? Container(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
                            decoration: BoxDecoration(color: const Color(0xDD151922), borderRadius: BorderRadius.circular(18), border: Border.all(color: _cyan.withOpacity(.55))),
                            child: Text(_gestureHudText, style: const TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w800)),
                          )
                        : _buildGestureHud())),
                  if (_controlsVisible && !_locked)
                    Positioned(left: 0, right: 0, top: 0, child: SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        child: Row(children: [
                          Expanded(child: Text(_currentAsset.title ?? 'Video', maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w700))),
                          IconButton(tooltip: 'Audio track', onPressed: () => _openAudioTrackSettings(player),
                            style: IconButton.styleFrom(backgroundColor: Colors.black.withOpacity(.28), shape: const CircleBorder()),
                            icon: const Icon(Icons.audiotrack_rounded, color: _cyan)),
                          IconButton(tooltip: 'Subtitles', onPressed: () => _openSubtitleTrackSettings(player),
                            style: IconButton.styleFrom(backgroundColor: Colors.black.withOpacity(.28), shape: const CircleBorder()),
                            icon: const Icon(Icons.subtitles_rounded, color: _cyan)),
                          IconButton(tooltip: _favorite ? 'Remove from favorites' : 'Add to favorites', onPressed: () {
                            widget.onFavorite(_currentAsset.id);
                            setState(() => _favorite = !_favorite);
                          }, style: IconButton.styleFrom(backgroundColor: Colors.black.withOpacity(.28), shape: const CircleBorder()),
                            icon: Icon(_favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                            color: _favorite ? const Color(0xFFFF6F9D) : Colors.white)),
                          PopupMenuButton<String>(
                            tooltip: 'More player tools',
                            color: _surface2,
                            icon: const Icon(Icons.more_vert_rounded, color: Colors.white),
                            onSelected: (choice) {
                              switch (choice) {
                                case 'bookmark': _addBookmark(); break;
                                case 'bookmarks': _openBookmarks(); break;
                                case 'queue': _showPlayingQueue(); break;
                                case 'sleep': _chooseSleepTimer(); break;
                                case 'share': _shareVideo(); break;
                                case 'info': _showAssetInfo(context, _currentAsset); break;
                              }
                            },
                            itemBuilder: (_) => [
                              const PopupMenuItem(value: 'bookmark', child: ListTile(dense: true, leading: Icon(Icons.bookmark_add_outlined), title: Text('Save bookmark'))),
                              PopupMenuItem(value: 'bookmarks', child: ListTile(dense: true, leading: const Icon(Icons.bookmarks_outlined), title: Text('Bookmarks (${_bookmarks.length})'))),
                              const PopupMenuItem(value: 'queue', child: ListTile(dense: true, leading: Icon(Icons.queue_music_rounded), title: Text('Playing queue'))),
                              PopupMenuItem(value: 'sleep', child: ListTile(dense: true, leading: const Icon(Icons.bedtime_outlined), title: Text(_sleepTimerMinutes == null ? 'Sleep timer' : 'Sleep timer • $_sleepTimerMinutes min'))),
                              const PopupMenuDivider(),
                              const PopupMenuItem(value: 'share', child: ListTile(dense: true, leading: Icon(Icons.share_outlined), title: Text('Share video'))),
                              const PopupMenuItem(value: 'info', child: ListTile(dense: true, leading: Icon(Icons.info_outline_rounded), title: Text('Video information'))),
                            ],
                          ),
                        ]),
                      ),
                    )),
                  if (_locked)
                    Positioned(top: 12, right: 14, child: SafeArea(child: IconButton.filledTonal(
                      tooltip: 'Unlock player controls', onPressed: _toggleLock,
                      icon: const Icon(Icons.lock_rounded),
                    ))),
                  if (_controlsVisible && !_locked)
                    Positioned(left: 0, right: 0, bottom: 0,
                      child: Listener(
                        behavior: HitTestBehavior.translucent,
                        onPointerDown: (_) => _cancelControlsTimer(),
                        onPointerUp: (_) => _scheduleControlsHide(),
                        onPointerCancel: (_) => _scheduleControlsHide(),
                        child: _buildControls(player, position, duration, playing),
                      ),
                    ),
                ]);
              },
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final player = _player;
    final videoController = _videoController;
    return PopScope<Object?>(
      canPop: true,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) unawaited(_savePlaybackProgress());
      },
      child: Scaffold(
      backgroundColor: Colors.black,
      appBar: null,
      body: SafeArea(
        top: false,
        bottom: false,
        child: _error != null
            ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.video_file_outlined, color: _muted, size: 48),
                const SizedBox(height: 12),
                Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                const SizedBox(height: 16),
                FilledButton.icon(onPressed: _initialiseVideo, icon: const Icon(Icons.refresh_rounded), label: const Text('Try again')),
              ])))
            : _loading || player == null || videoController == null
                ? const Center(child: CircularProgressIndicator(color: _cyan))
                : _buildPlayer(player, videoController),
      ),
      ),
    );
  }
}

Future<void> _showAssetInfo(BuildContext context, AssetEntity asset) async {
  final file = await asset.file;
  String fileSize = 'Unavailable';
  if (file != null) {
    try {
      final bytes = await file.length();
      fileSize = bytes > 1024 * 1024 ? '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB' : '${(bytes / 1024).toStringAsFixed(0)} KB';
    } catch (_) {}
  }
  if (!context.mounted) return;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: _surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
    builder: (context) => Padding(
      padding: const EdgeInsets.fromLTRB(22, 14, 22, 30),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
        const SizedBox(height: 20),
        const Text('VIDEO DETAILS', style: TextStyle(color: _cyan, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Text(asset.title ?? 'Untitled video', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 16, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        _InfoRow(label: 'Created', value: _formatDate(asset.createDateTime)),
        _InfoRow(label: 'Resolution', value: '${asset.width} × ${asset.height}'),
        _InfoRow(label: 'Duration', value: _formatDuration(asset.duration)),
        _InfoRow(label: 'File size', value: fileSize),
      ]),
    ),
  );
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(children: [Text(label, style: const TextStyle(color: _muted, fontSize: 12)), const Spacer(), Flexible(child: Text(value, textAlign: TextAlign.right, style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w600)))],),
  );
}

String _formatDate(DateTime date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final local = date.toLocal();
  return '${local.day} ${months[local.month - 1]} ${local.year}';
}

String _formatClock(Duration duration) {
  final totalSeconds = duration.inSeconds < 0 ? 0 : duration.inSeconds;
  final hours = totalSeconds ~/ 3600;
  final minutes = (totalSeconds % 3600) ~/ 60;
  final seconds = totalSeconds % 60;
  final mm = minutes.toString().padLeft(2, '0');
  final ss = seconds.toString().padLeft(2, '0');
  return hours > 0 ? '${hours.toString()}:$mm:$ss' : '$mm:$ss';
}

String _formatDuration(int seconds) {
  final hours = seconds ~/ 3600;
  final minutes = (seconds % 3600) ~/ 60;
  final remaining = seconds % 60;
  if (hours > 0) return '$hours:${minutes.toString().padLeft(2, '0')}:${remaining.toString().padLeft(2, '0')}';
  return '$minutes:${remaining.toString().padLeft(2, '0')}';
}
