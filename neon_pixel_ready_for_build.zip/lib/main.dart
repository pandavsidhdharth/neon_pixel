import 'dart:ui';

import 'package:cross_file/cross_file.dart';
import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NeonPixelApp());
}

const _bg = Color(0xFF080B14);
const _surface = Color(0xFF121827);
const _surface2 = Color(0xFF1A2234);
const _purple = Color(0xFF9B7BFF);
const _cyan = Color(0xFF53E5E8);
const _muted = Color(0xFF929AAF);
const _white = Color(0xFFF4F5FA);

class NeonPixelApp extends StatelessWidget {
  const NeonPixelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NEON PIXEL',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: _purple,
          brightness: Brightness.dark,
          surface: _surface,
        ),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: _bg,
          foregroundColor: _white,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const GalleryHome(),
    );
  }
}

class GalleryHome extends StatefulWidget {
  const GalleryHome({super.key});

  @override
  State<GalleryHome> createState() => _GalleryHomeState();
}

class _GalleryHomeState extends State<GalleryHome> {
  List<AssetEntity> _images = [];
  List<AssetEntity> _videos = [];
  List<AssetEntity> _albumItems = [];
  List<AssetPathEntity> _albums = [];
  final Set<String> _favorites = {};
  final Set<String> _selected = {};
  final TextEditingController _searchController = TextEditingController();

  bool _loading = true;
  bool _gridMode = true;
  bool _newestFirst = true;
  bool _selectionMode = false;
  String? _error;
  String _query = '';
  int _tab = 0; // 0 Photos, 1 Albums, 2 Favorites, 3 Videos.
  AssetPathEntity? _activeAlbum;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _loadGallery();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _favorites.addAll(prefs.getStringList('neon_pixel_favorites') ?? []));
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('neon_pixel_favorites', _favorites.toList());
  }

  Future<void> _loadGallery() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final permission = await PhotoManager.requestPermissionExtend();
      if (!permission.isAuth && !permission.hasAccess) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = 'NEON PIXEL needs permission to read the photos and videos on this phone.';
        });
        return;
      }

      final allPaths = await PhotoManager.getAssetPathList(
        type: RequestType.common,
        hasAll: true,
        onlyAll: true,
      );
      final allMedia = <AssetEntity>[];
      if (allPaths.isNotEmpty) {
        allMedia.addAll(await allPaths.first.getAssetListRange(start: 0, end: 2000));
      }

      final albumPaths = await PhotoManager.getAssetPathList(
        type: RequestType.image,
        hasAll: false,
        onlyAll: false,
      );

      if (!mounted) return;
      setState(() {
        _images = allMedia.where((asset) => asset.type == AssetType.image).toList();
        _videos = allMedia.where((asset) => asset.type == AssetType.video).toList();
        _albums = albumPaths;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Could not load the gallery. Please try again.\n$e';
      });
    }
  }

  void _changeTab(int index) {
    setState(() {
      _tab = index;
      _activeAlbum = null;
      _albumItems = [];
      _selectionMode = false;
      _selected.clear();
      _query = '';
      _searchController.clear();
    });
  }

  Future<void> _openAlbum(AssetPathEntity album) async {
    setState(() {
      _loading = true;
      _activeAlbum = album;
      _tab = 0;
    });
    try {
      final items = await album.getAssetListRange(start: 0, end: 1000);
      if (!mounted) return;
      setState(() {
        _albumItems = items.where((asset) => asset.type == AssetType.image).toList();
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  List<AssetEntity> get _currentItems {
    List<AssetEntity> source;
    if (_activeAlbum != null) {
      source = List<AssetEntity>.from(_albumItems);
    } else if (_tab == 2) {
      source = [..._images, ..._videos].where((item) => _favorites.contains(item.id)).toList();
    } else if (_tab == 3) {
      source = List<AssetEntity>.from(_videos);
    } else {
      source = List<AssetEntity>.from(_images);
    }

    if (_query.trim().isNotEmpty) {
      final q = _query.trim().toLowerCase();
      source = source.where((item) => (item.title ?? '').toLowerCase().contains(q)).toList();
    }
    source.sort((a, b) => _newestFirst
        ? b.createDateTime.compareTo(a.createDateTime)
        : a.createDateTime.compareTo(b.createDateTime));
    return source;
  }

  void _toggleFavorite(String id) {
    setState(() {
      if (!_favorites.add(id)) _favorites.remove(id);
    });
    _saveFavorites();
  }

  void _toggleSelected(String id) {
    setState(() {
      if (!_selected.add(id)) _selected.remove(id);
      _selectionMode = _selected.isNotEmpty;
    });
  }

  Future<void> _shareAssets(List<AssetEntity> assets) async {
    final files = <XFile>[];
    for (final asset in assets) {
      final file = await asset.file;
      if (file != null) files.add(XFile(file.path));
    }
    if (files.isEmpty) {
      _message('Could not prepare these files for sharing.');
      return;
    }
    await Share.shareXFiles(files, text: 'Shared with NEON PIXEL');
  }

  Future<void> _favoriteSelected() async {
    setState(() {
      for (final id in _selected) {
        if (!_favorites.add(id)) _favorites.remove(id);
      }
      _selected.clear();
      _selectionMode = false;
    });
    await _saveFavorites();
    _message('Selected favorites updated.');
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));
  }

  Future<void> _shareSelected() async {
    final items = _currentItems.where((asset) => _selected.contains(asset.id)).toList();
    await _shareAssets(items);
    if (!mounted) return;
    setState(() {
      _selected.clear();
      _selectionMode = false;
    });
  }

  void _openAsset(List<AssetEntity> items, int index) {
    final asset = items[index];
    if (_selectionMode) {
      _toggleSelected(asset.id);
      return;
    }
    if (asset.type == AssetType.video) {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => VideoPlayerPage(asset: asset)));
      return;
    }
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => PhotoViewerPage(
        assets: items,
        initialIndex: index,
        isFavorite: (id) => _favorites.contains(id),
        onFavorite: _toggleFavorite,
        onShare: _shareAssets,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final items = _currentItems;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _buildTopBar(),
            if (_selectionMode) _buildSelectionBar() else _buildIntro(),
            _buildSearchBar(),
            _buildSectionHeader(items.length),
            Expanded(child: _buildContent(items)),
            _buildBottomNavigation(),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 16, 8),
      child: Row(
        children: [
          Container(
            height: 42,
            width: 42,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: const LinearGradient(colors: [_purple, _cyan], begin: Alignment.topLeft, end: Alignment.bottomRight),
              boxShadow: [BoxShadow(color: _purple.withOpacity(.22), blurRadius: 18, offset: const Offset(0, 5))],
            ),
            child: const Icon(Icons.bubble_chart_rounded, size: 25, color: _bg),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('NEON PIXEL', style: TextStyle(color: _white, fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: 1.8)),
              SizedBox(height: 2),
              Text('YOUR PERSONAL GALLERY', style: TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.4, fontWeight: FontWeight.w600)),
            ]),
          ),
          IconButton(
            tooltip: 'Refresh gallery',
            onPressed: _loadGallery,
            icon: const Icon(Icons.sync_rounded, color: _cyan),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.tune_rounded, color: _white),
            color: _surface2,
            onSelected: (value) {
              if (value == 'grid') setState(() => _gridMode = true);
              if (value == 'list') setState(() => _gridMode = false);
              if (value == 'newest') setState(() => _newestFirst = true);
              if (value == 'oldest') setState(() => _newestFirst = false);
              if (value == 'refresh') _loadGallery();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'grid', child: Text('Grid layout')),
              PopupMenuItem(value: 'list', child: Text('List layout')),
              PopupMenuDivider(),
              PopupMenuItem(value: 'newest', child: Text('Newest first')),
              PopupMenuItem(value: 'oldest', child: Text('Oldest first')),
              PopupMenuDivider(),
              PopupMenuItem(value: 'refresh', child: Text('Refresh gallery')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildIntro() {
    final photoCount = _images.length;
    final videoCount = _videos.length;
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 14),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(19, 18, 18, 17),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
            colors: [Color(0xFF292044), Color(0xFF172A3C), Color(0xFF102D34)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: Colors.white.withOpacity(.08)),
          boxShadow: [BoxShadow(color: _purple.withOpacity(.08), blurRadius: 24, offset: const Offset(0, 10))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Expanded(child: Text('EVERY MOMENT,\nIN ONE PLACE.', style: TextStyle(color: _white, fontSize: 22, height: 1.13, fontWeight: FontWeight.w900, letterSpacing: .4))),
            Container(
              height: 66,
              width: 66,
              decoration: BoxDecoration(color: Colors.white.withOpacity(.07), borderRadius: BorderRadius.circular(20)),
              child: const Icon(Icons.auto_awesome_rounded, color: _cyan, size: 34),
            ),
          ]),
          const SizedBox(height: 15),
          Row(children: [
            _StatPill(icon: Icons.photo_outlined, number: '$photoCount', label: 'PHOTOS'),
            const SizedBox(width: 8),
            _StatPill(icon: Icons.videocam_outlined, number: '$videoCount', label: 'VIDEOS'),
            const SizedBox(width: 8),
            _StatPill(icon: Icons.favorite_border_rounded, number: '${_favorites.length}', label: 'SAVED'),
          ]),
        ]),
      ),
    );
  }

  Widget _buildSelectionBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(color: _surface2, borderRadius: BorderRadius.circular(18), border: Border.all(color: _purple.withOpacity(.35))),
        child: Row(children: [
          Text('${_selected.length} selected', style: const TextStyle(color: _white, fontWeight: FontWeight.w700)),
          const Spacer(),
          IconButton(tooltip: 'Toggle favorites', onPressed: _favoriteSelected, icon: const Icon(Icons.favorite_border_rounded, color: _purple)),
          IconButton(tooltip: 'Share selected', onPressed: _shareSelected, icon: const Icon(Icons.share_rounded, color: _cyan)),
          IconButton(tooltip: 'Clear selection', onPressed: () => setState(() { _selected.clear(); _selectionMode = false; }), icon: const Icon(Icons.close_rounded, color: _white)),
        ]),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
      child: Container(
        decoration: BoxDecoration(color: _surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(.06))),
        child: TextField(
          controller: _searchController,
          onChanged: (value) => setState(() => _query = value),
          style: const TextStyle(color: _white, fontSize: 13),
          decoration: InputDecoration(
            hintText: _activeAlbum != null ? 'Search in ${_activeAlbum!.name}...' : 'Search photos and videos...',
            hintStyle: const TextStyle(color: _muted, fontSize: 12),
            prefixIcon: const Icon(Icons.search_rounded, color: _cyan, size: 21),
            suffixIcon: _query.isEmpty ? null : IconButton(
              onPressed: () { _searchController.clear(); setState(() => _query = ''); },
              icon: const Icon(Icons.close_rounded, color: _muted, size: 18),
            ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 15),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(int count) {
    String title;
    String subtitle;
    if (_activeAlbum != null) {
      title = _activeAlbum!.name;
      subtitle = '$count ITEMS IN THIS ALBUM';
    } else if (_tab == 1) {
      title = 'Your albums';
      subtitle = '${_albums.length} ALBUMS ON DEVICE';
    } else if (_tab == 2) {
      title = 'Your favorites';
      subtitle = '${_favorites.length} SAVED MOMENTS';
    } else if (_tab == 3) {
      title = 'Your videos';
      subtitle = '$count VIDEOS FOUND';
    } else {
      title = 'Recent photos';
      subtitle = '$count PHOTOS ON DEVICE';
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 2, 18, 10),
      child: Row(children: [
        if (_activeAlbum != null)
          IconButton(
            visualDensity: VisualDensity.compact,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            onPressed: () => setState(() { _activeAlbum = null; _albumItems = []; _tab = 1; _query = ''; _searchController.clear(); }),
            icon: const Icon(Icons.arrow_back_rounded, color: _cyan),
          ),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(color: _muted, fontSize: 9, letterSpacing: 1.2, fontWeight: FontWeight.w600)),
        ])),
        if (_tab != 1 && _activeAlbum == null)
          Icon(_gridMode ? Icons.grid_view_rounded : Icons.view_agenda_rounded, color: _muted, size: 18),
      ]),
    );
  }

  Widget _buildContent(List<AssetEntity> items) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _cyan));
    if (_error != null) {
      return _EmptyPanel(
        icon: Icons.photo_library_outlined,
        title: 'LET YOUR GALLERY IN',
        message: _error!,
        action: 'GRANT ACCESS',
        onTap: () async { await PhotoManager.openSetting(); await _loadGallery(); },
      );
    }
    if (_tab == 1 && _activeAlbum == null) return _buildAlbumGrid();
    if (items.isEmpty) {
      return _EmptyPanel(
        icon: _tab == 2 ? Icons.favorite_border_rounded : Icons.photo_outlined,
        title: _tab == 2 ? 'NOTHING SAVED YET' : 'NO MEDIA FOUND',
        message: _tab == 2 ? 'Tap the heart on a photo to keep it close. Your favorites stay saved on this phone.' : 'Your photos and videos will appear here when they are available on your phone.',
        action: 'REFRESH',
        onTap: _loadGallery,
      );
    }
    return RefreshIndicator(
      color: _purple,
      backgroundColor: _surface,
      onRefresh: _loadGallery,
      child: _gridMode ? _buildAssetGrid(items) : _buildAssetList(items),
    );
  }

  Widget _buildAssetGrid(List<AssetEntity> items) {
    return GridView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(14, 2, 14, 16),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 7,
        mainAxisSpacing: 7,
        childAspectRatio: .82,
      ),
      itemBuilder: (context, index) => _AssetTile(
        asset: items[index],
        selected: _selected.contains(items[index].id),
        favorite: _favorites.contains(items[index].id),
        onTap: () => _openAsset(items, index),
        onLongPress: () => _toggleSelected(items[index].id),
      ),
    );
  }

  Widget _buildAssetList(List<AssetEntity> items) {
    return ListView.separated(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 2, 16, 18),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 9),
      itemBuilder: (context, index) {
        final asset = items[index];
        return InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _openAsset(items, index),
          onLongPress: () => _toggleSelected(asset.id),
          child: Container(
            height: 78,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: _surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(.05))),
            child: Row(children: [
              ClipRRect(borderRadius: BorderRadius.circular(11), child: SizedBox(width: 62, height: 62, child: AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover))),
              const SizedBox(width: 12),
              Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(asset.title ?? 'Untitled media', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w700)),
                const SizedBox(height: 5),
                Text(_formatDate(asset.createDateTime), style: const TextStyle(color: _muted, fontSize: 10)),
              ])),
              if (asset.type == AssetType.video) const Icon(Icons.play_circle_outline_rounded, color: _cyan),
              if (_favorites.contains(asset.id)) const Icon(Icons.favorite_rounded, color: _purple, size: 17),
              if (_selected.contains(asset.id)) const Icon(Icons.check_circle_rounded, color: _cyan, size: 19),
            ]),
          ),
        );
      },
    );
  }

  Widget _buildAlbumGrid() {
    if (_albums.isEmpty) {
      return const _EmptyPanel(icon: Icons.folder_open_rounded, title: 'NO ALBUMS FOUND', message: 'No separate photo albums were found on this device.', action: null);
    }
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 2, 16, 18),
      itemCount: _albums.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.18),
      itemBuilder: (context, index) {
        final album = _albums[index];
        return FutureBuilder<List<AssetEntity>>(
          future: album.getAssetListRange(start: 0, end: 1),
          builder: (context, snapshot) {
            final cover = snapshot.data?.isNotEmpty == true ? snapshot.data!.first : null;
            return InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => _openAlbum(album),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Stack(fit: StackFit.expand, children: [
                  if (cover != null) AssetEntityImage(cover, isOriginal: false, fit: BoxFit.cover) else Container(color: _surface2, child: const Icon(Icons.photo_album_rounded, size: 42, color: _purple)),
                  DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withOpacity(.03), Colors.black.withOpacity(.82)]))),
                  Positioned(left: 12, right: 12, bottom: 12, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(album.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 3),
                    FutureBuilder<int>(
                      future: album.assetCountAsync,
                      builder: (context, countSnapshot) => Text(
                        '${countSnapshot.data ?? '—'} ITEMS',
                        style: const TextStyle(color: _cyan, fontSize: 9, letterSpacing: 1, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ])),
                  Positioned(top: 9, right: 9, child: Container(padding: const EdgeInsets.all(7), decoration: BoxDecoration(color: Colors.black.withOpacity(.38), borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.arrow_outward_rounded, color: Colors.white, size: 15))),
                ]),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildBottomNavigation() {
    const tabs = [
      _TabSpec(Icons.photo_library_rounded, 'PHOTOS'),
      _TabSpec(Icons.folder_copy_rounded, 'ALBUMS'),
      _TabSpec(Icons.favorite_rounded, 'SAVED'),
      _TabSpec(Icons.videocam_rounded, 'VIDEOS'),
    ];
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          padding: const EdgeInsets.fromLTRB(8, 9, 8, 8),
          decoration: BoxDecoration(color: const Color(0xF2121725), border: Border(top: BorderSide(color: Colors.white.withOpacity(.07)))),
          child: SafeArea(
            top: false,
            child: Row(children: List.generate(tabs.length, (index) {
              final active = _tab == index && _activeAlbum == null;
              return Expanded(child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => _changeTab(index),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(vertical: 9),
                  decoration: BoxDecoration(color: active ? _purple.withOpacity(.14) : Colors.transparent, borderRadius: BorderRadius.circular(16)),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(tabs[index].icon, color: active ? _cyan : _muted, size: 21),
                    const SizedBox(height: 4),
                    Text(tabs[index].label, style: TextStyle(color: active ? _white : _muted, fontSize: 8, letterSpacing: .9, fontWeight: FontWeight.w800)),
                  ]),
                ),
              ));
            })),
          ),
        ),
      ),
    );
  }
}

class _TabSpec {
  final IconData icon;
  final String label;
  const _TabSpec(this.icon, this.label);
}

class _StatPill extends StatelessWidget {
  final IconData icon;
  final String number;
  final String label;
  const _StatPill({required this.icon, required this.number, required this.label});

  @override
  Widget build(BuildContext context) {
    return Expanded(child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 9),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.07), borderRadius: BorderRadius.circular(13), border: Border.all(color: Colors.white.withOpacity(.05))),
      child: Row(children: [
        Icon(icon, color: _cyan, size: 15),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(number, style: const TextStyle(color: _white, fontSize: 13, fontWeight: FontWeight.w900)),
          Text(label, style: const TextStyle(color: _muted, fontSize: 7, letterSpacing: .7, fontWeight: FontWeight.w700)),
        ])),
      ]),
    ));
  }
}

class _AssetTile extends StatelessWidget {
  final AssetEntity asset;
  final bool selected;
  final bool favorite;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  const _AssetTile({required this.asset, required this.selected, required this.favorite, required this.onTap, required this.onLongPress});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: Stack(fit: StackFit.expand, children: [
          AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover),
          if (asset.type == AssetType.video)
            Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black.withOpacity(.5)])))),
          if (asset.type == AssetType.video)
            Positioned(bottom: 7, left: 7, child: Row(children: [const Icon(Icons.play_arrow_rounded, size: 14, color: Colors.white), Text(_formatDuration(asset.duration), style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700))])),
          if (favorite) Positioned(top: 7, left: 7, child: Container(padding: const EdgeInsets.all(5), decoration: BoxDecoration(color: Colors.black.withOpacity(.45), shape: BoxShape.circle), child: const Icon(Icons.favorite_rounded, color: Color(0xFFFF6F9D), size: 12))),
          if (selected) Positioned.fill(child: Container(color: _cyan.withOpacity(.2), child: const Align(alignment: Alignment.topRight, child: Padding(padding: EdgeInsets.all(6), child: Icon(Icons.check_circle_rounded, color: _cyan, size: 21))))),
        ]),
      ),
    );
  }
}

class PhotoViewerPage extends StatefulWidget {
  final List<AssetEntity> assets;
  final int initialIndex;
  final bool Function(String) isFavorite;
  final void Function(String) onFavorite;
  final Future<void> Function(List<AssetEntity>) onShare;
  const PhotoViewerPage({super.key, required this.assets, required this.initialIndex, required this.isFavorite, required this.onFavorite, required this.onShare});

  @override
  State<PhotoViewerPage> createState() => _PhotoViewerPageState();
}

class _PhotoViewerPageState extends State<PhotoViewerPage> {
  late final PageController _controller = PageController(initialPage: widget.initialIndex);
  late int _index = widget.initialIndex;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  AssetEntity get _current => widget.assets[_index];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        PageView.builder(
          controller: _controller,
          itemCount: widget.assets.length,
          onPageChanged: (value) => setState(() => _index = value),
          itemBuilder: (context, index) => Center(child: InteractiveViewer(
            minScale: 1,
            maxScale: 5,
            child: Hero(tag: widget.assets[index].id, child: AssetEntityImage(widget.assets[index], isOriginal: true, fit: BoxFit.contain, width: double.infinity, height: double.infinity)),
          )),
        ),
        Positioned(top: 0, left: 0, right: 0, child: SafeArea(child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
          child: Row(children: [
            IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded, color: Colors.white)),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_current.title ?? 'NEON PIXEL', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              Text('${_index + 1} / ${widget.assets.length}', style: const TextStyle(color: _cyan, fontSize: 10)),
            ])),
            IconButton(onPressed: () => _showAssetInfo(context, _current), icon: const Icon(Icons.info_outline_rounded, color: Colors.white)),
          ]),
        ))),
        Positioned(left: 0, right: 0, bottom: 0, child: SafeArea(top: false, child: Container(
          margin: const EdgeInsets.fromLTRB(25, 0, 25, 18),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(color: const Color(0xD9192030), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white.withOpacity(.12))),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _ViewerAction(icon: widget.isFavorite(_current.id) ? Icons.favorite_rounded : Icons.favorite_border_rounded, label: 'Favorite', color: const Color(0xFFFF6F9D), onTap: () { widget.onFavorite(_current.id); setState(() {}); }),
            _ViewerAction(icon: Icons.share_rounded, label: 'Share', color: _cyan, onTap: () => widget.onShare([_current])),
            _ViewerAction(icon: Icons.info_outline_rounded, label: 'Details', color: _purple, onTap: () => _showAssetInfo(context, _current)),
          ]),
        ))),
      ]),
    );
  }
}

class _ViewerAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _ViewerAction({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(14),
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: color, size: 21),
      const SizedBox(height: 4),
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 9)),
    ])),
  );
}

class VideoPlayerPage extends StatefulWidget {
  final AssetEntity asset;
  const VideoPlayerPage({super.key, required this.asset});

  @override
  State<VideoPlayerPage> createState() => _VideoPlayerPageState();
}

class _VideoPlayerPageState extends State<VideoPlayerPage> {
  VideoPlayerController? _controller;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initialiseVideo();
  }

  Future<void> _initialiseVideo() async {
    try {
      final file = await widget.asset.file;
      if (file == null) throw Exception('Video file unavailable');
      final controller = VideoPlayerController.file(file);
      _controller = controller;
      await controller.initialize();
      await controller.setLooping(false);
      if (mounted) setState(() {});
      await controller.play();
    } catch (e) {
      if (mounted) setState(() => _error = 'This video could not be opened.');
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: Text(widget.asset.title ?? 'Video', style: const TextStyle(fontSize: 14))),
      body: Center(child: _error != null
          ? Text(_error!, style: const TextStyle(color: Colors.white70))
          : controller == null || !controller.value.isInitialized
              ? const CircularProgressIndicator(color: _cyan)
              : Padding(padding: const EdgeInsets.all(14), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  AspectRatio(aspectRatio: controller.value.aspectRatio, child: VideoPlayer(controller)),
                  const SizedBox(height: 18),
                  VideoProgressIndicator(controller, allowScrubbing: true, colors: const VideoProgressColors(playedColor: _cyan, bufferedColor: _purple, backgroundColor: Colors.white24)),
                  const SizedBox(height: 8),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    IconButton(onPressed: () => controller.seekTo(controller.value.position - const Duration(seconds: 10)), icon: const Icon(Icons.replay_10_rounded, color: Colors.white)),
                    IconButton(onPressed: () { setState(() { controller.value.isPlaying ? controller.pause() : controller.play(); }); }, iconSize: 42, icon: Icon(controller.value.isPlaying ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded, color: _cyan)),
                    IconButton(onPressed: () => controller.seekTo(controller.value.position + const Duration(seconds: 10)), icon: const Icon(Icons.forward_10_rounded, color: Colors.white)),
                  ]),
                ]))),
    );
  }
}

Future<void> _showAssetInfo(BuildContext context, AssetEntity asset) async {
  final file = await asset.file;
  String fileSize = 'Unavailable';
  if (file != null) {
    try {
      final bytes = await file.length();
      fileSize = bytes > 1024 * 1024 ? '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB' : '${(bytes / 1024).toStringAsFixed(0)} KB';
    } catch (_) {}
  }
  if (!context.mounted) return;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: _surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
    builder: (context) => Padding(
      padding: const EdgeInsets.fromLTRB(22, 14, 22, 30),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
        const SizedBox(height: 20),
        const Text('MEDIA DETAILS', style: TextStyle(color: _cyan, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Text(asset.title ?? 'Untitled media', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 16, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        _InfoRow(label: 'Created', value: _formatDate(asset.createDateTime)),
        _InfoRow(label: 'Resolution', value: '${asset.width} × ${asset.height}'),
        _InfoRow(label: 'File size', value: fileSize),
        _InfoRow(label: 'Type', value: asset.type == AssetType.video ? 'Video • ${_formatDuration(asset.duration)}' : 'Photo'),
      ]),
    ),
  );
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(children: [Text(label, style: const TextStyle(color: _muted, fontSize: 12)), const Spacer(), Flexible(child: Text(value, textAlign: TextAlign.right, style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w600)))],),
  );
}

class _EmptyPanel extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String? action;
  final VoidCallback? onTap;
  const _EmptyPanel({required this.icon, required this.title, required this.message, this.action, this.onTap});

  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(30),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 76, height: 76, decoration: BoxDecoration(color: _surface2, borderRadius: BorderRadius.circular(24)), child: Icon(icon, color: _cyan, size: 35)),
      const SizedBox(height: 18),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(color: _white, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1)),
      const SizedBox(height: 9),
      Text(message, textAlign: TextAlign.center, style: const TextStyle(color: _muted, height: 1.5, fontSize: 12)),
      if (action != null && onTap != null) ...[
        const SizedBox(height: 19),
        FilledButton(onPressed: onTap, style: FilledButton.styleFrom(backgroundColor: _purple, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)), child: Text(action!, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1))),
      ],
    ]),
  ));
}

String _formatDate(DateTime date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final local = date.toLocal();
  final hour = local.hour % 12 == 0 ? 12 : local.hour % 12;
  final minute = local.minute.toString().padLeft(2, '0');
  final suffix = local.hour >= 12 ? 'PM' : 'AM';
  return '${local.day} ${months[local.month - 1]} ${local.year} • $hour:$minute $suffix';
}

String _formatDuration(int seconds) {
  final minutes = seconds ~/ 60;
  final remaining = seconds % 60;
  return '$minutes:${remaining.toString().padLeft(2, '0')}';
}
