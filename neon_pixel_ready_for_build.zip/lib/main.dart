import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'widgets/vortex_logo.dart';
import 'package:cross_file/cross_file.dart';
import 'package:flutter/services.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';

part 'screens/home_screen.dart';
part 'screens/video_player_screen.dart';
part 'screens/external_video_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Bundled libmpv/FFmpeg engine for broad codec support, including E-AC-3.
  MediaKit.ensureInitialized();
  runApp(const VortexPlayerApp());
}

const _bg = Color(0xFF080409);
const _surface = Color(0xFF160810);
const _surface2 = Color(0xFF28101B);
const _secondary = Color(0xFF7E2038);
const _primary = Color(0xFFC51F45);
const _muted = Color(0xFFB79AA4);
const _white = Color(0xFFFFF4F6);
const _softAccent = Color(0xFFE88A9B);
const MethodChannel _externalChannel = MethodChannel('vortex_player/external');

class VortexPlayerApp extends StatelessWidget {
  const VortexPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VORTEX PLAYER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bg,
        colorScheme: ColorScheme.fromSeed(seedColor: _primary, brightness: Brightness.dark, surface: _surface),
        fontFamily: 'Roboto',
      ),
      home: const VortexLaunchScreen(),
    );
  }
}


class VortexLaunchScreen extends StatefulWidget {
  const VortexLaunchScreen({super.key});

  @override
  State<VortexLaunchScreen> createState() => _VortexLaunchScreenState();
}

class _VortexLaunchScreenState extends State<VortexLaunchScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;
  late final Animation<double> _fade;
  late final Animation<double> _pulse;
  bool _showHome = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1450));
    _scale = Tween<double>(begin: .72, end: 1).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutBack));
    _fade = CurvedAnimation(parent: _controller, curve: const Interval(0, .90, curve: Curves.easeInOut));
    _pulse = Tween<double>(begin: .88, end: 1.02).animate(CurvedAnimation(parent: _controller, curve: Curves.elasticOut));
    _controller.forward();
    Timer(const Duration(milliseconds: 1650), () {
      if (mounted) setState(() => _showHome = true);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _buildSplash() => Scaffold(
    backgroundColor: _bg,
    body: Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(center: Alignment.center, radius: 1.0,
          colors: [Color(0xFF5B1228), Color(0xFF260B16), _bg]),
      ),
      child: Center(child: FadeTransition(
        opacity: _fade,
        child: ScaleTransition(scale: _scale, child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) => Transform.scale(
                scale: _pulse.value,
                child: VortexLogoMark(size: 118, progress: _controller.value),
              ),
            ),
            const SizedBox(height: 20),
            const Text('VORTEX PLAYER', style: TextStyle(
              color: _white, fontSize: 16, fontWeight: FontWeight.w900,
              letterSpacing: 3.2,
            )),
            const SizedBox(height: 8),
            Text('PLAY WITHOUT LIMITS', style: TextStyle(
              color: _primary.withValues(alpha: .96), fontSize: 11,
              fontWeight: FontWeight.w800, letterSpacing: 2.8,
            )),
            const SizedBox(height: 20),
            SizedBox(width: 82, child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) => ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(value: _controller.value, minHeight: 2, backgroundColor: Colors.white12,
                  valueColor: const AlwaysStoppedAnimation<Color>(_primary)),
              ),
            )),
          ],
        )),
      )),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const VortexHome(),
        if (!_showHome)
          AnimatedOpacity(
            opacity: _showHome ? 0 : 1,
            duration: const Duration(milliseconds: 260),
            child: IgnorePointer(child: _buildSplash()),
          ),
      ],
    );
  }
}

Future<void> _showAssetInfo(BuildContext context, AssetEntity asset) async {
  final file = await asset.file;
  String fileSize = 'Unavailable';
  if (file != null) {
    try {
      final bytes = await file.length();
      fileSize = bytes > 1024 * 1024 ? '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB' : '${(bytes / 1024).toStringAsFixed(0)} KB';
    } catch (_) {}
  }
  if (!context.mounted) return;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: _surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
    builder: (context) => Padding(
      padding: const EdgeInsets.fromLTRB(22, 14, 22, 30),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
        const SizedBox(height: 20),
        const Text('VIDEO DETAILS', style: TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Text(asset.title ?? 'Untitled video', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 16, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        _InfoRow(label: 'Created', value: _formatDate(asset.createDateTime)),
        _InfoRow(label: 'Resolution', value: '${asset.width} × ${asset.height}'),
        _InfoRow(label: 'Duration', value: _formatDuration(asset.duration)),
        _InfoRow(label: 'File size', value: fileSize),
      ]),
    ),
  );
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(children: [Text(label, style: const TextStyle(color: _muted, fontSize: 12)), const Spacer(), Flexible(child: Text(value, textAlign: TextAlign.right, style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w600)))],),
  );
}

String _formatDate(DateTime date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final local = date.toLocal();
  return '${local.day} ${months[local.month - 1]} ${local.year}';
}

String _formatClock(Duration duration) {
  final totalSeconds = duration.inSeconds < 0 ? 0 : duration.inSeconds;
  final hours = totalSeconds ~/ 3600;
  final minutes = (totalSeconds % 3600) ~/ 60;
  final seconds = totalSeconds % 60;
  final mm = minutes.toString().padLeft(2, '0');
  final ss = seconds.toString().padLeft(2, '0');
  return hours > 0 ? '${hours.toString()}:$mm:$ss' : '$mm:$ss';
}

String _formatDuration(int seconds) {
  final hours = seconds ~/ 3600;
  final minutes = (seconds % 3600) ~/ 60;
  final remaining = seconds % 60;
  if (hours > 0) return '$hours:${minutes.toString().padLeft(2, '0')}:${remaining.toString().padLeft(2, '0')}';
  return '$minutes:${remaining.toString().padLeft(2, '0')}';
}
