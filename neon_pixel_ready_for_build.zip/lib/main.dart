import 'dart:async';
import 'dart:math' as math;
import 'dart:io';
import 'dart:ui' as ui;
import 'package:package_info_plus/package_info_plus.dart';

import 'package:flutter/material.dart';
import 'widgets/vortex_logo.dart';
import 'package:cross_file/cross_file.dart';
import 'package:flutter/services.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';

part 'screens/home_screen.dart';
part 'screens/video_player_screen.dart';
part 'screens/external_video_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Bundled libmpv/FFmpeg engine for broad codec support, including E-AC-3.
  MediaKit.ensureInitialized();
  runApp(const VortexPlayerApp());
}

const _bg = Color(0xFF090714);
const _surface = Color(0xC51E1930);
const _surface2 = Color(0xE52C2343);
const _secondary = Color(0xFF4A2B83);
const _primary = Color(0xFF9B6BFF);
const _muted = Color(0xFFC4BDD5);
const _white = Color(0xFFFBF8FF);
const _softAccent = Color(0xFFE0CAFF);
// Cinematic player palette: deep ink, electric teal and warm amber.
const _playerAccent = Color(0xFF49E0D0);
const _playerAccentSecondary = Color(0xFFFFC36B);
const _playerSoftAccent = Color(0xFFC7FFF5);
const _playerPanelTop = Color(0x553A5E69);
const _playerPanelBottom = Color(0x660B1422);
const _cyan = Color(0xFF7CE4FF);
const _gold = Color(0xFFFFD58B);


// Subtitle text is drawn by media_kit_video's Flutter SubtitleView.
// The user can adjust text size; captions stay anchored near the bottom for a
// familiar, predictable viewing experience.
SubtitleViewConfiguration _vortexSubtitleViewConfiguration(
  BuildContext context, {
  required double scale,
}) {
  final screenHeight = MediaQuery.sizeOf(context).height;
  final bottomPadding = (screenHeight * .035).clamp(20.0, 34.0).toDouble();
  final fontSize = (28.0 * scale).clamp(14.0, 70.0).toDouble();
  return SubtitleViewConfiguration(
    visible: true,
    style: TextStyle(
      fontSize: fontSize,
      height: 1.22,
      color: Colors.white,
      fontWeight: FontWeight.w800,
      letterSpacing: 0.1,
      backgroundColor: const Color(0x99000000),
      shadows: const [Shadow(color: Colors.black, blurRadius: 5, offset: Offset(1, 2))],
    ),
    textAlign: TextAlign.center,
    padding: EdgeInsets.fromLTRB(18, 0, 18, bottomPadding),
  );
}
const MethodChannel _externalChannel = MethodChannel('vortex_player/external');
const MethodChannel _audioFocusChannel = MethodChannel('vortex_player/audio_focus');
const MethodChannel _pipChannel = MethodChannel('vortex_player/pip');

class VortexPlayerApp extends StatelessWidget {
  const VortexPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VORTEX PLAYER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bg,
        colorScheme: ColorScheme.fromSeed(seedColor: _primary, brightness: Brightness.dark, surface: _surface),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: _bg, foregroundColor: _white, elevation: 0, centerTitle: false,
          titleTextStyle: TextStyle(color: _white, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: .3),
        ),
        sliderTheme: SliderThemeData(
          activeTrackColor: _primary, inactiveTrackColor: Colors.white12,
          thumbColor: _white, overlayColor: _primary.withValues(alpha: .16),
          trackHeight: 4.2,
        ),
        snackBarTheme: SnackBarThemeData(
          backgroundColor: _surface2, contentTextStyle: const TextStyle(color: _white, fontWeight: FontWeight.w600),
          behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        dialogTheme: DialogThemeData(
          backgroundColor: _surface2, surfaceTintColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          titleTextStyle: const TextStyle(color: _white, fontSize: 18, fontWeight: FontWeight.w900),
          contentTextStyle: const TextStyle(color: _muted, fontSize: 13, height: 1.45),
        ),
      ),
      home: const VortexLaunchScreen(),
    );
  }
}


class VortexLaunchScreen extends StatefulWidget {
  const VortexLaunchScreen({super.key});

  @override
  State<VortexLaunchScreen> createState() => _VortexLaunchScreenState();
}

class _VortexLaunchScreenState extends State<VortexLaunchScreen>
    with TickerProviderStateMixin {
  late final AnimationController _controller;
  late final AnimationController _ambienceController;
  late final Animation<double> _scale;
  late final Animation<double> _fade;
  late final Animation<double> _pulse;
  Timer? _transitionTimer;
  bool _showHome = false;
  bool _splashRemoved = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2850),
    );
    _ambienceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 5200),
    )..repeat();
    _scale = Tween<double>(begin: .58, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );
    _fade = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0, .90, curve: Curves.easeInOutCubic),
    );
    _pulse = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: .82, end: 1.10).chain(CurveTween(curve: Curves.easeOutBack)), weight: 64),
      TweenSequenceItem(tween: Tween(begin: 1.10, end: 1.0).chain(CurveTween(curve: Curves.easeInOut)), weight: 36),
    ]).animate(_controller);
    _controller.forward();
    _transitionTimer = Timer(const Duration(milliseconds: 3350), _finishSplash);
  }

  // Shows the library when the intro ends, or immediately when the viewer taps the screen.
  void _finishSplash() {
    if (!mounted || _showHome) return;
    _transitionTimer?.cancel();
    setState(() => _showHome = true);
  }

  // After the fade-out the intro is removed completely, so its animations stop using the CPU.
  void _onSplashFaded() {
    if (!mounted || !_showHome || _splashRemoved) return;
    _controller.stop();
    _ambienceController.stop();
    setState(() => _splashRemoved = true);
  }

  @override
  void dispose() {
    _transitionTimer?.cancel();
    _controller.dispose();
    _ambienceController.dispose();
    super.dispose();
  }

  Widget _buildAnimatedTitle() {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final reveal = Curves.easeOutCubic.transform(
          ((_controller.value - .40) / .38).clamp(0.0, 1.0).toDouble(),
        );
        return Opacity(
          opacity: reveal,
          child: Transform.translate(
            offset: Offset(0, (1 - reveal) * 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: [Color(0xFFF7F7FF), Color(0xFFBFAEFF), Color(0xFF56D5F5)],
                  ).createShader(bounds),
                  child: const Text(
                    'VORTEX',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      height: 1,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 5.2,
                      shadows: [Shadow(color: Color(0xFF8057F5), blurRadius: 22)],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(width: 18, height: 1.5, decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0x00FFFF9A), Color(0xFFC9B9FF)]))),
                    const SizedBox(width: 9),
                    const Text('PLAYER', style: TextStyle(color: Color(0xFFE7EAF3), fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 5.0)),
                    const SizedBox(width: 9),
                    Container(width: 18, height: 1.5, decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFC9B9FF), Color(0x00FFFF9A)]))),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildSplash() => Scaffold(
    backgroundColor: _bg,
    body: Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0, -.05),
          radius: 1.12,
          colors: [Color(0xFF2A1A58), Color(0xFF17132C), Color(0xFF0D0E19), _bg],
          stops: [0, .34, .72, 1],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Positioned.fill(
            child: RepaintBoundary(
              child: AnimatedBuilder(
                animation: Listenable.merge([_controller, _ambienceController]),
                builder: (context, _) => CustomPaint(
                  painter: _VortexLaunchPainter(
                    intro: _controller.value,
                    phase: _ambienceController.value,
                  ),
                ),
              ),
            ),
          ),
          Center(
            child: FadeTransition(
              opacity: _fade,
              child: ScaleTransition(
                scale: _scale,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: Listenable.merge([_controller, _ambienceController]),
                      builder: (context, child) => Transform.scale(
                        scale: _pulse.value * (1 + math.sin(_ambienceController.value * math.pi * 2) * .012),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(color: const Color(0xFF8057F5).withValues(alpha: .22 + _ambienceController.value * .08), blurRadius: 54, spreadRadius: 9),
                              BoxShadow(color: const Color(0xFF56D5F5).withValues(alpha: .12), blurRadius: 88, spreadRadius: 18),
                            ],
                          ),
                          child: VortexLogoMark(size: 158, progress: _controller.value),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    _buildAnimatedTitle(),
                    const SizedBox(height: 12),
                    AnimatedBuilder(
                      animation: _controller,
                      builder: (context, child) => Opacity(
                        opacity: Curves.easeIn.transform(((_controller.value - .58) / .30).clamp(0.0, 1.0).toDouble()),
                        child: child,
                      ),
                      child: const Text(
                        'YOUR MEDIA. YOUR WAY.',
                        style: TextStyle(color: Color(0xFFC9B9FF), fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 3.0),
                      ),
                    ),
                    const SizedBox(height: 34),
                    SizedBox(
                      width: 176,
                      child: AnimatedBuilder(
                        animation: _controller,
                        builder: (context, child) => Column(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Stack(children: [
                                Container(height: 4, color: Colors.white.withValues(alpha: .12)),
                                FractionallySizedBox(
                                  widthFactor: _controller.value,
                                  child: Container(
                                    height: 4,
                                    decoration: const BoxDecoration(
                                      gradient: LinearGradient(colors: [Color(0xFF56D5F5), Color(0xFF8057F5), Color(0xFF9C1740)]),
                                      boxShadow: [BoxShadow(color: Color(0xFF8057F5), blurRadius: 12, spreadRadius: 2)],
                                    ),
                                  ),
                                ),
                              ]),
                            ),
                            const SizedBox(height: 11),
                            Text(
                              _controller.value < .34 ? 'STARTING YOUR LIBRARY' : _controller.value < .72 ? 'GETTING THINGS READY' : 'READY WHEN YOU ARE',
                              style: const TextStyle(color: Color(0xFFC9B9FF), fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 2.0),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 34,
            child: AnimatedBuilder(
              animation: _ambienceController,
              builder: (context, child) => Opacity(
                opacity: .42 + math.sin(_ambienceController.value * math.pi * 2) * .12,
                child: child,
              ),
              child: const Text(
                'V O R T E X   •   MEDIA PLAYER',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 8, fontWeight: FontWeight.w700, letterSpacing: 1.5),
              ),
            ),
          ),
        ],
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const VortexHome(),
        if (!_splashRemoved)
          AnimatedOpacity(
            opacity: _showHome ? 0 : 1,
            duration: const Duration(milliseconds: 760),
            curve: Curves.easeInOutCubic,
            onEnd: _onSplashFaded,
            child: IgnorePointer(
              ignoring: _showHome,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _finishSplash,
                child: _buildSplash(),
              ),
            ),
          ),
      ],
    );
  }
}

class _VortexLaunchPainter extends CustomPainter {
  final double intro;
  final double phase;
  const _VortexLaunchPainter({required this.intro, required this.phase});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height * .43);
    final unit = math.min(size.width, size.height).toDouble();
    final t = phase * math.pi * 2;
    final reveal = Curves.easeOutCubic.transform(intro.clamp(0.0, 1.0).toDouble());

    // A soft violet halo keeps the opening screen atmospheric without visual clutter.
    final glowRect = Rect.fromCenter(
      center: Offset(center.dx, center.dy + unit * .02),
      width: unit * .92,
      height: unit * .72,
    );
    canvas.drawOval(glowRect, Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF8057F5).withValues(alpha: .22 * reveal),
          const Color(0xFF56D5F5).withValues(alpha: .07 * reveal),
          Colors.transparent,
        ],
        stops: const [0, .46, 1],
      ).createShader(glowRect));

    // Two thin orbital paths move slowly behind the new V logo.
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(t * .11);
    for (var i = 0; i < 2; i++) {
      final rect = Rect.fromCenter(
        center: Offset.zero,
        width: unit * (.62 + i * .16),
        height: unit * (.30 + i * .10),
      );
      canvas.drawOval(rect, Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = i == 0 ? 1.3 : .8
        ..color = (i == 0 ? const Color(0xFFBDAAFF) : const Color(0xFF56D5F5))
            .withValues(alpha: .24 + .10 * math.sin(t + i).abs()));
      final angle = t * (i == 0 ? 1 : -1) + i * math.pi;
      final dot = Offset(math.cos(angle) * rect.width / 2, math.sin(angle) * rect.height / 2);
      canvas.drawCircle(dot, unit * .009, Paint()
        ..color = i == 0 ? const Color(0xFFD7C9FF) : const Color(0xFF8AE8FF)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, unit * .018));
      canvas.drawCircle(dot, unit * .0045, Paint()..color = Colors.white.withValues(alpha: .9));
    }
    canvas.restore();

    // A short accent line gently appears under the wordmark.
    final lineRect = Rect.fromCenter(
      center: Offset(center.dx, size.height * .77),
      width: unit * .32,
      height: 2,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(lineRect, const Radius.circular(8)),
      Paint()
        ..shader = const LinearGradient(colors: [Color(0x008057F5), Color(0xFF8057F5), Color(0xFF56D5F5), Color(0x0056D5F5)]).createShader(lineRect)
        ..color = Colors.white.withValues(alpha: reveal),
    );
  }

  @override
  bool shouldRepaint(covariant _VortexLaunchPainter oldDelegate) =>
      oldDelegate.intro != intro || oldDelegate.phase != phase;
}

Future<void> _showAssetInfo(BuildContext context, AssetEntity asset) async {
  String fileSize = 'Unavailable';
  try {
    final path = await _resolveAssetPath(asset);
    if (path != null) fileSize = _formatFileSize(await File(path).length());
  } catch (_) {}
  final format = _assetText(asset, 'mimeType');
  final folder = _assetText(asset, 'relativePath');
  if (!context.mounted) return;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: _surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
    builder: (context) => Padding(
      padding: const EdgeInsets.fromLTRB(22, 14, 22, 30),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
        const SizedBox(height: 20),
        const Text('VIDEO DETAILS', style: TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Text(asset.title ?? 'Untitled video', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 16, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        _InfoRow(label: 'Created', value: _formatDate(asset.createDateTime)),
        _InfoRow(label: 'Resolution', value: '${asset.width} × ${asset.height}'),
        _InfoRow(label: 'Duration', value: _formatDuration(asset.duration)),
        _InfoRow(label: 'File size', value: fileSize),
        if (format != null) _InfoRow(label: 'Format', value: format),
        if (folder != null) _InfoRow(label: 'Folder', value: folder),
      ]),
    ),
  );
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(children: [Text(label, style: const TextStyle(color: _muted, fontSize: 12)), const Spacer(), Flexible(child: Text(value, textAlign: TextAlign.right, style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w600)))],),
  );
}

String _formatDate(DateTime date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final local = date.toLocal();
  return '${local.day} ${months[local.month - 1]} ${local.year}';
}

String _formatClock(Duration duration) {
  final totalSeconds = duration.inSeconds < 0 ? 0 : duration.inSeconds;
  final hours = totalSeconds ~/ 3600;
  final minutes = (totalSeconds % 3600) ~/ 60;
  final seconds = totalSeconds % 60;
  final mm = minutes.toString().padLeft(2, '0');
  final ss = seconds.toString().padLeft(2, '0');
  return hours > 0 ? '${hours.toString()}:$mm:$ss' : '$mm:$ss';
}

String _formatDuration(int seconds) {
  final hours = seconds ~/ 3600;
  final minutes = (seconds % 3600) ~/ 60;
  final remaining = seconds % 60;
  if (hours > 0) return '$hours:${minutes.toString().padLeft(2, '0')}:${remaining.toString().padLeft(2, '0')}';
  return '$minutes:${remaining.toString().padLeft(2, '0')}';
}

String _formatFileSize(int bytes) {
  if (bytes >= 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  if (bytes >= 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  return '${(bytes / 1024).toStringAsFixed(0)} KB';
}

/// Formats a playback speed without rounding errors, for example 0.75×, 1×, 1.25×.
String _speedLabel(double value) {
  var text = value.toStringAsFixed(2);
  while (text.endsWith('0')) {
    text = text.substring(0, text.length - 1);
  }
  if (text.endsWith('.')) text = text.substring(0, text.length - 1);
  return '$text×';
}

// Thumbnails are requested at a higher resolution than the plugin default (200 px)
// so previews stay sharp on high-density screens.
final ThumbnailSize _cardThumbnailSize = ThumbnailSize(480, 360);
final ThumbnailSize _tileThumbnailSize = ThumbnailSize(300, 220);

/// English names for the language codes stored inside video files, so audio and
/// subtitle tracks read "English" or "Hindi" instead of "eng" or "hin".
const Map<String, String> _languageNames = {
  'en': 'English', 'eng': 'English',
  'hi': 'Hindi', 'hin': 'Hindi',
  'gu': 'Gujarati', 'guj': 'Gujarati',
  'mr': 'Marathi', 'mar': 'Marathi',
  'bn': 'Bengali', 'ben': 'Bengali',
  'ta': 'Tamil', 'tam': 'Tamil',
  'te': 'Telugu', 'tel': 'Telugu',
  'kn': 'Kannada', 'kan': 'Kannada',
  'ml': 'Malayalam', 'mal': 'Malayalam',
  'pa': 'Punjabi', 'pan': 'Punjabi',
  'ur': 'Urdu', 'urd': 'Urdu',
  'ne': 'Nepali', 'nep': 'Nepali',
  'si': 'Sinhala', 'sin': 'Sinhala',
  'ar': 'Arabic', 'ara': 'Arabic',
  'fa': 'Persian', 'fas': 'Persian', 'per': 'Persian',
  'tr': 'Turkish', 'tur': 'Turkish',
  'he': 'Hebrew', 'heb': 'Hebrew',
  'es': 'Spanish', 'spa': 'Spanish',
  'fr': 'French', 'fra': 'French', 'fre': 'French',
  'de': 'German', 'deu': 'German', 'ger': 'German',
  'it': 'Italian', 'ita': 'Italian',
  'pt': 'Portuguese', 'por': 'Portuguese',
  'ru': 'Russian', 'rus': 'Russian',
  'uk': 'Ukrainian', 'ukr': 'Ukrainian',
  'pl': 'Polish', 'pol': 'Polish',
  'nl': 'Dutch', 'nld': 'Dutch', 'dut': 'Dutch',
  'sv': 'Swedish', 'swe': 'Swedish',
  'no': 'Norwegian', 'nor': 'Norwegian',
  'da': 'Danish', 'dan': 'Danish',
  'fi': 'Finnish', 'fin': 'Finnish',
  'el': 'Greek', 'ell': 'Greek', 'gre': 'Greek',
  'cs': 'Czech', 'ces': 'Czech', 'cze': 'Czech',
  'hu': 'Hungarian', 'hun': 'Hungarian',
  'ro': 'Romanian', 'ron': 'Romanian', 'rum': 'Romanian',
  'bg': 'Bulgarian', 'bul': 'Bulgarian',
  'sr': 'Serbian', 'srp': 'Serbian',
  'hr': 'Croatian', 'hrv': 'Croatian',
  'ja': 'Japanese', 'jpn': 'Japanese',
  'ko': 'Korean', 'kor': 'Korean',
  'zh': 'Chinese', 'zho': 'Chinese', 'chi': 'Chinese',
  'th': 'Thai', 'tha': 'Thai',
  'vi': 'Vietnamese', 'vie': 'Vietnamese',
  'id': 'Indonesian', 'ind': 'Indonesian',
  'ms': 'Malay', 'msa': 'Malay', 'may': 'Malay',
  'fil': 'Filipino', 'tl': 'Filipino', 'tgl': 'Filipino',
  'sw': 'Swahili', 'swa': 'Swahili',
};

/// Returns an English language name for a track, or null when it is unknown.
String? _languageName(String? code) {
  final raw = code?.trim();
  if (raw == null || raw.isEmpty) return null;
  final key = raw.toLowerCase().split(RegExp(r'[-_]')).first;
  if (key == 'und' || key == 'zxx' || key == 'mul') return null;
  return _languageNames[key] ?? (raw.length <= 3 ? raw.toUpperCase() : raw);
}

/// Builds an English track label such as "English • Dolby Digital 5.1".
String _trackLabel({required String fallback, String? language, String? title}) {
  final languageName = _languageName(language);
  final cleanTitle = title?.trim() ?? '';
  final rawLanguage = (language ?? '').trim().toLowerCase();
  final parts = <String>[
    if (languageName != null) languageName,
    if (cleanTitle.isNotEmpty &&
        cleanTitle.toLowerCase() != rawLanguage &&
        cleanTitle.toLowerCase() != (languageName ?? '').toLowerCase())
      cleanTitle,
  ];
  return parts.isEmpty ? fallback : parts.join(' • ');
}

/// Reads optional text properties of an asset. They are read dynamically so a
/// plugin version without the property simply returns null instead of failing.
String? _assetText(AssetEntity asset, String field) {
  try {
    final dynamic probe = asset;
    final dynamic value = field == 'relativePath' ? probe.relativePath : probe.mimeType;
    if (value is String && value.trim().isNotEmpty) return value.trim();
  } catch (_) {}
  return null;
}

/// Finds a path mpv can play. On Android 11+ the video can usually be read directly
/// from shared storage, which avoids copying a multi-gigabyte file into the app cache
/// before playback. Anything unusual falls back to the plugin's own file handling.
Future<String?> _resolveAssetPath(AssetEntity asset) async {
  try {
    final dynamic probe = asset;
    final dynamic relative = probe.relativePath;
    final name = asset.title;
    if (Platform.isAndroid && relative is String && relative.isNotEmpty && name != null && name.isNotEmpty) {
      final folder = relative.endsWith('/') ? relative : '$relative/';
      final candidate = File('/storage/emulated/0/$folder$name');
      if (await candidate.exists()) {
        final dynamic indexed = probe.modifiedDateSecond;
        final stat = await candidate.stat();
        final fileSeconds = stat.modified.millisecondsSinceEpoch ~/ 1000;
        final sameFile = indexed is! int || (fileSeconds - indexed).abs() <= 3;
        if (sameFile) {
          final handle = await candidate.open();
          try {
            await handle.read(1);
          } finally {
            await handle.close();
          }
          return candidate.path;
        }
      }
    }
  } catch (_) {
    // Fall through to the plugin's own file resolution.
  }
  final file = await asset.file;
  return file?.path;
}
