import 'dart:async';

import 'package:flutter/material.dart';
import 'package:cross_file/cross_file.dart';
import 'package:flutter/services.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:open_filex/open_filex.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Bundled libmpv/FFmpeg engine for broad codec support, including E-AC-3.
  MediaKit.ensureInitialized();
  runApp(const VortexPlayerApp());
}

const _bg = Color(0xFF05060B);
const _surface = Color(0xFF101321);
const _surface2 = Color(0xFF191D30);
const _purple = Color(0xFF8B5CF6);
const _cyan = Color(0xFF31E6FF);
const _muted = Color(0xFF9098B0);
const _white = Color(0xFFF5F7FF);

class VortexPlayerApp extends StatelessWidget {
  const VortexPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VORTEX PLAYER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bg,
        colorScheme: ColorScheme.fromSeed(seedColor: _purple, brightness: Brightness.dark, surface: _surface),
        fontFamily: 'Roboto',
      ),
      home: const VortexHome(),
    );
  }
}

class VortexHome extends StatefulWidget {
  const VortexHome({super.key});

  @override
  State<VortexHome> createState() => _VortexHomeState();
}

class _VortexHomeState extends State<VortexHome> {
  List<AssetEntity> _videos = [];
  List<AssetPathEntity> _folders = [];
  AssetPathEntity? _selectedFolder;
  final Set<String> _favorites = {};
  final TextEditingController _searchController = TextEditingController();
  bool _loading = true;
  bool _searchOpen = false;
  bool _favoritesOnly = false;
  bool _grid = true;
  bool _newestFirst = true;
  String? _error;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _loadFavorites();
    _loadVideos();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _favorites.addAll(prefs.getStringList('vortex_player_favorites') ?? []));
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('vortex_player_favorites', _favorites.toList());
  }

  Future<void> _loadVideos() async {
    if (mounted) setState(() { _loading = true; _error = null; });
    try {
      final permission = await PhotoManager.requestPermissionExtend();
      if (!permission.isAuth && !permission.hasAccess) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = 'Allow video access so VORTEX can build your local video library.';
        });
        return;
      }
      final paths = await PhotoManager.getAssetPathList(
        type: RequestType.video,
        hasAll: false,
      );
      final selected = _selectedFolder;
      final clips = <AssetEntity>[];
      if (selected != null) {
        clips.addAll(await selected.getAssetListRange(start: 0, end: 5000));
      }
      clips.sort((a, b) => b.createDateTime.compareTo(a.createDateTime));
      if (!mounted) return;
      setState(() {
        _folders = paths;
        _videos = clips;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Could not load video folders. Please try again.\n$e'; });
    }
  }

  Future<void> _openFolder(AssetPathEntity folder) async {
    setState(() { _selectedFolder = folder; _favoritesOnly = false; _query = ''; _searchController.clear(); });
    await _loadVideos();
  }

  Future<void> _leaveFolder() async {
    setState(() { _selectedFolder = null; _favoritesOnly = false; _query = ''; _searchController.clear(); });
    await _loadVideos();
  }

  List<AssetEntity> get _visibleVideos {
    var items = List<AssetEntity>.from(_videos);
    if (_favoritesOnly) items = items.where((v) => _favorites.contains(v.id)).toList();
    final q = _query.trim().toLowerCase();
    if (q.isNotEmpty) items = items.where((v) => (v.title ?? '').toLowerCase().contains(q)).toList();
    items.sort((a, b) => _newestFirst
        ? b.createDateTime.compareTo(a.createDateTime)
        : a.createDateTime.compareTo(b.createDateTime));
    return items;
  }

  void _toggleFavorite(String id) {
    setState(() {
      if (!_favorites.add(id)) _favorites.remove(id);
    });
    _saveFavorites();
  }

  Future<void> _shareVideo(AssetEntity asset) async {
    final file = await asset.file;
    if (file == null) return;
    await Share.shareXFiles([XFile(file.path)], text: 'Shared with VORTEX PLAYER');
  }

  void _openVideo(AssetEntity asset) {
    final playlist = _visibleVideos;
    final index = playlist.indexWhere((item) => item.id == asset.id);
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => VideoPlayerPage(
        asset: asset,
        playlist: playlist,
        initialIndex: index < 0 ? 0 : index,
        isFavorite: (id) => _favorites.contains(id),
        initiallyFavorite: _favorites.contains(asset.id),
        onFavorite: _toggleFavorite,
        onShare: (items) async {
          if (items.isNotEmpty) await _shareVideo(items.first);
        },
      ),
    ));
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    final items = _visibleVideos;
    return Scaffold(
      backgroundColor: _bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF111229), _bg, Color(0xFF080D18)], stops: [0, .42, 1]),
        ),
        child: SafeArea(
          child: Column(children: [
            _buildHeader(),
            if (_searchOpen) _buildSearch(),
            _buildHero(),
            _buildLibraryToolbar(items.length),
            Expanded(child: _buildVideoLibrary(items)),
          ]),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 16, 8),
      child: Row(children: [
        if (_selectedFolder != null)
          IconButton(
            tooltip: 'Back to folders',
            onPressed: _leaveFolder,
            icon: const Icon(Icons.arrow_back_rounded, color: _cyan),
          ),
        Container(
          width: 46, height: 46,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            gradient: const LinearGradient(colors: [_cyan, _purple]),
            boxShadow: [BoxShadow(color: _cyan.withOpacity(.22), blurRadius: 20, spreadRadius: 1)],
          ),
          child: const Icon(Icons.play_arrow_rounded, color: Colors.black, size: 32),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('VORTEX', style: TextStyle(color: _white, fontSize: 22, height: 1, fontWeight: FontWeight.w900, letterSpacing: 2.1)),
          const SizedBox(height: 4),
          Text('PREMIUM VIDEO PLAYER', style: TextStyle(color: _cyan.withOpacity(.9), fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 2.0)),
        ])),
        IconButton(
          tooltip: _searchOpen ? 'Close search' : 'Search videos',
          onPressed: () => setState(() {
            _searchOpen = !_searchOpen;
            if (!_searchOpen) { _query = ''; _searchController.clear(); }
          }),
          style: IconButton.styleFrom(backgroundColor: Colors.white.withOpacity(.07)),
          icon: Icon(_searchOpen ? Icons.close_rounded : Icons.search_rounded, color: _white),
        ),
        const SizedBox(width: 6),
        PopupMenuButton<String>(
          color: _surface2,
          icon: const Icon(Icons.more_vert_rounded, color: _white),
          onSelected: (v) {
            if (v == 'refresh') _loadVideos();
            if (v == 'newest') setState(() => _newestFirst = true);
            if (v == 'oldest') setState(() => _newestFirst = false);
            if (v == 'grid') setState(() => _grid = true);
            if (v == 'list') setState(() => _grid = false);
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'newest', child: Text('Newest first')),
            PopupMenuItem(value: 'oldest', child: Text('Oldest first')),
            PopupMenuDivider(),
            PopupMenuItem(value: 'grid', child: Text('Grid view')),
            PopupMenuItem(value: 'list', child: Text('List view')),
            PopupMenuDivider(),
            PopupMenuItem(value: 'refresh', child: Text('Refresh library')),
          ],
        ),
      ]),
    );
  }

  Widget _buildSearch() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 8),
      child: TextField(
        controller: _searchController,
        onChanged: (v) => setState(() => _query = v),
        style: const TextStyle(color: _white, fontSize: 13),
        decoration: InputDecoration(
          hintText: 'Search video names…',
          hintStyle: const TextStyle(color: _muted, fontSize: 12),
          prefixIcon: const Icon(Icons.search_rounded, color: _cyan),
          filled: true, fillColor: _surface,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withOpacity(.05))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withOpacity(.06))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: _cyan, width: 1)),
        ),
      ),
    );
  }

  Widget _buildHero() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 14),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(20, 20, 18, 18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF20254A), Color(0xFF11182C), Color(0xFF171126)]),
          border: Border.all(color: Colors.white.withOpacity(.09)),
          boxShadow: [BoxShadow(color: _purple.withOpacity(.13), blurRadius: 26, offset: const Offset(0, 12))],
        ),
        child: Stack(children: [
          Positioned(right: -4, top: -12, child: Icon(Icons.play_circle_outline_rounded, size: 112, color: _cyan.withOpacity(.10))),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: _cyan.withOpacity(.11), borderRadius: BorderRadius.circular(20), border: Border.all(color: _cyan.withOpacity(.22))), child: const Text('YOUR CINEMA. YOUR RULES.', style: TextStyle(color: _cyan, fontSize: 8, letterSpacing: 1.5, fontWeight: FontWeight.w900))),
            const SizedBox(height: 13),
            const Text('EVERY FRAME.\nFULL POWER.', style: TextStyle(color: _white, fontSize: 25, height: 1.03, fontWeight: FontWeight.w900, letterSpacing: -.5)),
            const SizedBox(height: 9),
            const Text('A powerful home for every video on your phone.', style: TextStyle(color: Color(0xFFABB4CC), fontSize: 11)),
            const SizedBox(height: 18),
            Row(children: [
              _HeroStat(value: '${_selectedFolder == null ? _folders.length : _videos.length}', label: _selectedFolder == null ? 'FOLDERS' : 'VIDEOS'),
              const SizedBox(width: 22),
              Container(width: 1, height: 27, color: Colors.white12),
              const SizedBox(width: 22),
              _HeroStat(value: '${_favorites.length}', label: 'FAVOURITES'),
              const Spacer(),
              const Icon(Icons.graphic_eq_rounded, color: _cyan, size: 24),
            ]),
          ]),
        ]),
      ),
    );
  }

  Widget _buildLibraryToolbar(int count) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 2, 18, 12),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(_selectedFolder == null ? 'VIDEO FOLDERS' : 'VIDEOS', style: const TextStyle(color: _white, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
          const SizedBox(height: 3),
          Text(_selectedFolder == null ? '${_folders.length} folders on your device' : '$count videos ready to play', style: const TextStyle(color: _muted, fontSize: 10)),
        ])),
        if (_selectedFolder != null) ...[
          _FilterChip(label: 'ALL', active: !_favoritesOnly, onTap: () => setState(() => _favoritesOnly = false)),
          const SizedBox(width: 7),
          _FilterChip(label: '♥', active: _favoritesOnly, onTap: () => setState(() => _favoritesOnly = true)),
          const SizedBox(width: 8),
          IconButton(
            tooltip: _grid ? 'List view' : 'Grid view',
            onPressed: () => setState(() => _grid = !_grid),
            style: IconButton.styleFrom(backgroundColor: Colors.white.withOpacity(.06), minimumSize: const Size(38, 38)),
            icon: Icon(_grid ? Icons.view_list_rounded : Icons.grid_view_rounded, color: _cyan, size: 20),
          ),
        ],
      ]),
    );
  }

  Widget _buildVideoLibrary(List<AssetEntity> items) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _cyan));
    if (_error != null) {
      return _VideoEmptyState(
        icon: Icons.video_library_rounded,
        title: 'VIDEO ACCESS REQUIRED',
        message: _error!,
        action: 'OPEN SETTINGS',
        onTap: () async { await PhotoManager.openSetting(); await _loadVideos(); },
      );
    }
    if (_selectedFolder == null) {
      if (_folders.isEmpty) {
        return _VideoEmptyState(
          icon: Icons.folder_off_rounded,
          title: 'NO VIDEO FOLDERS',
          message: 'Create or copy video folders on your phone, then refresh the library.',
          action: 'REFRESH LIBRARY',
          onTap: _loadVideos,
        );
      }
      return RefreshIndicator(
        color: _cyan,
        backgroundColor: _surface,
        onRefresh: _loadVideos,
        child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          itemCount: _folders.length,
          itemBuilder: (context, index) => _FolderCard(
            folder: _folders[index],
            onTap: () => _openFolder(_folders[index]),
          ),
        ),
      );
    }
    if (items.isEmpty) {
      return _VideoEmptyState(
        icon: _favoritesOnly ? Icons.favorite_border_rounded : Icons.movie_creation_outlined,
        title: _favoritesOnly ? 'NO FAVOURITES YET' : 'NO VIDEOS FOUND',
        message: _favoritesOnly ? 'Tap the heart on any video to add it to your favourites.' : 'Videos saved on your phone will appear here automatically.',
        action: 'REFRESH LIBRARY',
        onTap: _loadVideos,
      );
    }
    return RefreshIndicator(
      color: _cyan, backgroundColor: _surface, onRefresh: _loadVideos,
      child: _grid
          ? GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 13, childAspectRatio: 1.06),
              itemCount: items.length,
              itemBuilder: (context, index) => _VideoCard(
                asset: items[index], favorite: _favorites.contains(items[index].id),
                onTap: () => _openVideo(items[index]), onFavorite: () => _toggleFavorite(items[index].id),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) => _VideoListTile(
                asset: items[index], favorite: _favorites.contains(items[index].id),
                onTap: () => _openVideo(items[index]), onFavorite: () => _toggleFavorite(items[index].id),
              ),
            ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String value;
  final String label;
  const _HeroStat({required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(value, style: const TextStyle(color: _white, fontSize: 20, fontWeight: FontWeight.w900)),
    Text(label, style: const TextStyle(color: _muted, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
  ]);
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(30), onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: active ? const LinearGradient(colors: [_cyan, _purple]) : null,
        color: active ? null : Colors.white.withOpacity(.055),
        border: Border.all(color: active ? Colors.transparent : Colors.white.withOpacity(.08)),
        boxShadow: active ? [BoxShadow(color: _cyan.withOpacity(.20), blurRadius: 12)] : const [],
      ),
      child: Text(label, style: TextStyle(color: active ? Colors.black : _muted, fontSize: 10, fontWeight: FontWeight.w900)),
    ),
  );
}

class _FolderCard extends StatelessWidget {
  final AssetPathEntity folder;
  final VoidCallback onTap;
  const _FolderCard({required this.folder, required this.onTap});

  @override
  Widget build(BuildContext context) => FutureBuilder<int>(
    future: folder.assetCountAsync,
    builder: (context, snapshot) => Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _cyan.withOpacity(.16)),
      ),
      child: ListTile(
        onTap: onTap,
        leading: Container(width: 48, height: 48, decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: const LinearGradient(colors: [_cyan, _purple]),
        ), child: const Icon(Icons.folder_rounded, color: Colors.black, size: 27)),
        title: Text(folder.name, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: _white, fontWeight: FontWeight.w800, fontSize: 13)),
        subtitle: Text('${snapshot.data ?? '…'} videos', style: const TextStyle(color: _muted, fontSize: 10)),
        trailing: const Icon(Icons.chevron_right_rounded, color: _cyan),
      ),
    ),
  );
}

class _VideoCard extends StatelessWidget {
  final AssetEntity asset;
  final bool favorite;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  const _VideoCard({required this.asset, required this.favorite, required this.onTap, required this.onFavorite});

  @override
  Widget build(BuildContext context) => Material(
    color: _surface,
    borderRadius: BorderRadius.circular(18),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Stack(fit: StackFit.expand, children: [
          AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover),
          const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0x99000000)]))),
          Center(child: Container(width: 43, height: 43, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black.withOpacity(.50), border: Border.all(color: _cyan.withOpacity(.8), width: 1.2), boxShadow: [BoxShadow(color: _cyan.withOpacity(.25), blurRadius: 16)]), child: const Icon(Icons.play_arrow_rounded, color: _white, size: 28))),
          Positioned(left: 9, bottom: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4), decoration: BoxDecoration(color: Colors.black.withOpacity(.70), borderRadius: BorderRadius.circular(7)), child: Text(_formatDuration(asset.duration), style: const TextStyle(color: _white, fontSize: 9, fontWeight: FontWeight.w800)))),
          Positioned(right: 5, top: 5, child: IconButton(onPressed: onFavorite, visualDensity: VisualDensity.compact, style: IconButton.styleFrom(backgroundColor: Colors.black.withOpacity(.48)), icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: favorite ? const Color(0xFFFF6F9D) : _white, size: 17))),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 10, fontWeight: FontWeight.w700))),
      ]),
    ),
  );
}

class _VideoListTile extends StatelessWidget {
  final AssetEntity asset;
  final bool favorite;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  const _VideoListTile({required this.asset, required this.favorite, required this.onTap, required this.onFavorite});
  @override
  Widget build(BuildContext context) => Material(
    color: _surface, borderRadius: BorderRadius.circular(16), clipBehavior: Clip.antiAlias,
    child: ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.all(7),
      leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: SizedBox(width: 82, height: 58, child: Stack(fit: StackFit.expand, children: [AssetEntityImage(asset, isOriginal: false, fit: BoxFit.cover), const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 27))]))),
      title: Text(asset.title ?? 'Untitled video', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w800)),
      subtitle: Text('${_formatDuration(asset.duration)}  •  ${_formatDate(asset.createDateTime)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _muted, fontSize: 9)),
      trailing: IconButton(onPressed: onFavorite, icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: favorite ? const Color(0xFFFF6F9D) : _muted, size: 19)),
    ),
  );
}

class _VideoEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String action;
  final VoidCallback onTap;
  const _VideoEmptyState({required this.icon, required this.title, required this.message, required this.action, required this.onTap});
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(30),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 86, height: 86, decoration: BoxDecoration(shape: BoxShape.circle, color: _surface2, border: Border.all(color: _cyan.withOpacity(.24)), boxShadow: [BoxShadow(color: _purple.withOpacity(.13), blurRadius: 24)]), child: Icon(icon, color: _cyan, size: 39)),
      const SizedBox(height: 18),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(color: _white, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
      const SizedBox(height: 9),
      Text(message, textAlign: TextAlign.center, style: const TextStyle(color: _muted, height: 1.5, fontSize: 11)),
      const SizedBox(height: 18),
      FilledButton(onPressed: onTap, style: FilledButton.styleFrom(backgroundColor: _cyan, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)), child: Text(action, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1))),
    ]),
  ));
}

class VideoPlayerPage extends StatefulWidget {
  final AssetEntity asset;
  final List<AssetEntity> playlist;
  final int initialIndex;
  final bool Function(String) isFavorite;
  final bool initiallyFavorite;
  final void Function(String) onFavorite;
  final Future<void> Function(List<AssetEntity>) onShare;

  const VideoPlayerPage({
    super.key,
    required this.asset,
    required this.playlist,
    required this.initialIndex,
    required this.isFavorite,
    required this.initiallyFavorite,
    required this.onFavorite,
    required this.onShare,
  });

  @override
  State<VideoPlayerPage> createState() => _VideoPlayerPageState();
}

class _VideoPlayerPageState extends State<VideoPlayerPage> {
  late AssetEntity _currentAsset;
  late int _currentIndex;
  bool _locked = false;
  int _fitMode = 0; // 0 contain, 1 cover, 2 16:9 frame.
  Player? _player;
  VideoController? _videoController;
  StreamSubscription<bool>? _playingSubscription;
  StreamSubscription<String>? _errorSubscription;
  String? _error;
  bool _loading = true;
  bool _isMuted = false;
  bool _fullScreen = false;
  bool _favorite = false;
  double _volume = 1.0;
  double _speed = 1.0;
  Duration? _dragPosition;
  bool _controlsVisible = true;
  Timer? _controlsTimer;

  // Gesture controls: left-side vertical drag = brightness, right-side = volume.
  static const MethodChannel _brightnessChannel = MethodChannel('vortex_player/brightness');
  double _brightness = 0.5;
  double _gestureStartValue = 0.5;
  double _gestureStartY = 0.0;
  String? _gestureKind;
  bool _temporarySpeedActive = false;
  bool _showGestureHud = false;
  String _gestureHudText = '';
  Timer? _gestureHudTimer;
  int _boostPercent = 100;

  @override
  void initState() {
    super.initState();
    _currentAsset = widget.asset;
    _currentIndex = widget.playlist.isEmpty ? 0 : widget.initialIndex.clamp(0, widget.playlist.length - 1).toInt();
    _favorite = widget.initiallyFavorite;
    SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _readSystemBrightness();
    _initialiseVideo();
  }

  Future<void> _readSystemBrightness() async {
    try {
      final value = await _brightnessChannel.invokeMethod<double>('getSystemBrightness');
      if (mounted && value != null) {
        setState(() => _brightness = value.clamp(0.05, 1.0).toDouble());
      }
    } catch (_) {
      // Brightness gestures remain unavailable if the native channel is unavailable.
    }
  }

  Future<void> _applyScreenBrightness(double value) async {
    try {
      await _brightnessChannel.invokeMethod<void>('setBrightness', {'value': value});
    } catch (_) {
      // Keep video playback working even if a device rejects brightness changes.
    }
  }

  Future<void> _resetScreenBrightness() async {
    try {
      await _brightnessChannel.invokeMethod<void>('resetBrightness');
    } catch (_) {}
  }

  void _showGestureMessage(String message) {
    _gestureHudTimer?.cancel();
    if (mounted) {
      setState(() {
        _showGestureHud = true;
        _gestureHudText = message;
      });
    }
    _gestureHudTimer = Timer(const Duration(milliseconds: 1100), () {
      if (mounted && _gestureKind == null && !_temporarySpeedActive) {
        setState(() => _showGestureHud = false);
      }
    });
  }

  void _cancelControlsTimer() {
    _controlsTimer?.cancel();
    _controlsTimer = null;
  }

  void _scheduleControlsHide() {
    _cancelControlsTimer();
    final player = _player;
    if (!mounted || !_controlsVisible || player == null || !player.state.playing || _dragPosition != null || _gestureKind != null || _temporarySpeedActive) {
      return;
    }
    _controlsTimer = Timer(const Duration(seconds: 3), () {
      if (!mounted) return;
      final current = _player;
      if (current != null && current.state.playing && _dragPosition == null) {
        setState(() => _controlsVisible = false);
      }
    });
  }

  void _toggleControls() {
    if (!_controlsVisible) {
      setState(() => _controlsVisible = true);
      _scheduleControlsHide();
    } else if (_player?.state.playing == true) {
      _cancelControlsTimer();
      setState(() => _controlsVisible = false);
    } else {
      _cancelControlsTimer();
      setState(() => _controlsVisible = true);
    }
  }

  Future<void> _initialiseVideo() async {
    _cancelControlsTimer();
    await _readSystemBrightness();
    final previous = _player;
    _player = null;
    _videoController = null;
    await _playingSubscription?.cancel();
    await _errorSubscription?.cancel();
    if (previous != null) {
      await previous.dispose();
    }
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
      _controlsVisible = true;
    });

    Player? pendingPlayer;
    try {
      final file = await _currentAsset.file;
      if (file == null) throw Exception('Video file unavailable');

      // media_kit uses bundled libmpv/FFmpeg decoders rather than relying only
      // on Android's built-in codecs, allowing formats such as E-AC-3 (EAC3).
      final player = Player();
      pendingPlayer = player;
      final videoController = VideoController(player);
      _player = player;
      _videoController = videoController;

      _volume = 1.0;
      _isMuted = false;
      _speed = 1.0;
      if (player.platform is NativePlayer) {
        try {
          await (player.platform as NativePlayer).setProperty('volume-max', '200');
        } catch (_) {
          // Playback remains available even if this mpv build cannot raise its volume ceiling.
        }
      }
      await player.setVolume(_boostPercent.toDouble());
      await player.setRate(1.0);

      _playingSubscription = player.stream.playing.listen((playing) {
        if (!mounted) return;
        if (playing) {
          _scheduleControlsHide();
        } else {
          _cancelControlsTimer();
          if (!_controlsVisible) setState(() => _controlsVisible = true);
        }
      });
      _errorSubscription = player.stream.error.listen((message) {
        if (!mounted || message.trim().isEmpty) return;
        setState(() {
          _error = 'આ વિડિયો ચલાવવામાં સમસ્યા આવી: $message';
          _loading = false;
        });
      });

      await player.open(Media(file.path));
      if (!mounted) {
        await player.dispose();
        return;
      }
      setState(() => _loading = false);
      _scheduleControlsHide();
    } catch (e) {
      await _playingSubscription?.cancel();
      await _errorSubscription?.cancel();
      if (pendingPlayer != null) {
        await pendingPlayer.dispose();
      }
      if (mounted) {
        setState(() {
          _player = null;
          _videoController = null;
          _loading = false;
          _error = 'આ વિડિયો ખોલી શકાયો નથી. ફાઇલ અથવા video format તપાસો. ($e)';
        });
      }
    }
  }

  Future<void> _setVolume(double value) async {
    final player = _player;
    if (player == null) return;
    setState(() {
      _volume = value.clamp(0.0, 1.0).toDouble();
      _isMuted = _volume <= 0.001;
    });
    await player.setVolume(_volume * _boostPercent);
    _scheduleControlsHide();
  }

  Future<void> _toggleMute() async {
    final player = _player;
    if (player == null) return;
    if (_isMuted) {
      await _setVolume(_volume <= 0.001 ? 1.0 : _volume);
    } else {
      setState(() => _isMuted = true);
      await player.setVolume(0.0);
    }
    _scheduleControlsHide();
  }

  Future<void> _togglePlay() async {
    final player = _player;
    if (player == null) return;
    if (player.state.playing) {
      await player.pause();
      _cancelControlsTimer();
      if (mounted) setState(() => _controlsVisible = true);
    } else {
      if (player.state.completed ||
          (player.state.duration > Duration.zero && player.state.position >= player.state.duration)) {
        await player.seek(Duration.zero);
      }
      await player.play();
      if (mounted) {
        setState(() => _controlsVisible = true);
        _scheduleControlsHide();
      }
    }
  }

  Future<void> _playAdjacent(int delta) async {
    if (widget.playlist.isEmpty) return;
    final next = (_currentIndex + delta).clamp(0, widget.playlist.length - 1).toInt();
    if (next == _currentIndex) return;
    setState(() {
      _currentIndex = next;
      _currentAsset = widget.playlist[next];
      _favorite = widget.isFavorite(widget.playlist[next].id);
      _controlsVisible = true;
    });
    await _initialiseVideo();
  }

  void _cycleFitMode() {
    setState(() => _fitMode = (_fitMode + 1) % 3);
    _showGestureMessage(['FIT: CONTAIN', 'FIT: FILL', 'FIT: 16:9'][_fitMode]);
  }

  void _toggleLock() {
    setState(() {
      _locked = !_locked;
      if (_locked) _controlsVisible = false;
      else _controlsVisible = true;
    });
    if (_locked) _cancelControlsTimer(); else _scheduleControlsHide();
  }

  Future<void> _skipBy(int seconds) async {
    final player = _player;
    if (player == null) return;
    final target = player.state.position + Duration(seconds: seconds);
    final max = player.state.duration;
    final clamped = target < Duration.zero ? Duration.zero : (target > max ? max : target);
    await player.seek(clamped);
    _scheduleControlsHide();
  }

  Future<void> _changeSpeed(double value) async {
    final player = _player;
    if (player == null) return;
    await player.setRate(value);
    if (mounted) setState(() => _speed = value);
    _scheduleControlsHide();
  }

  void _onVideoVerticalDragStart(DragStartDetails details, double videoHeight) {
    final screenWidth = MediaQuery.of(context).size.width;
    _gestureKind = details.localPosition.dx < screenWidth / 2 ? 'brightness' : 'volume';
    _gestureStartY = details.localPosition.dy;
    _gestureStartValue = _gestureKind == 'brightness' ? _brightness : _volume;
    _gestureHudTimer?.cancel();
    _cancelControlsTimer();
    setState(() {
      _controlsVisible = false;
      _showGestureHud = true;
      _gestureHudText = _gestureKind == 'brightness'
          ? '☀  Brightness ${( _brightness * 100).round()}%'
          : '🔊  Volume ${(_volume * 100).round()}%';
    });
  }

  void _onVideoVerticalDragUpdate(DragUpdateDetails details, double videoHeight) {
    if (_gestureKind == null) return;
    final delta = (_gestureStartY - details.localPosition.dy) / (videoHeight * 0.72).clamp(140.0, 520.0);
    if (_gestureKind == 'brightness') {
      final next = (_gestureStartValue + delta).clamp(0.05, 1.0).toDouble();
      if ((next - _brightness).abs() >= 0.012) {
        setState(() {
          _brightness = next;
          _gestureHudText = '☀  Brightness ${(next * 100).round()}%';
        });
        unawaited(_applyScreenBrightness(next));
      }
    } else {
      final next = (_gestureStartValue + delta).clamp(0.0, 1.0).toDouble();
      if ((next - _volume).abs() >= 0.012) {
        setState(() {
          _volume = next;
          _isMuted = next <= 0.001;
          _gestureHudText = '🔊  Volume ${(next * 100).round()}%';
        });
        unawaited(_player?.setVolume(next * _boostPercent) ?? Future<void>.value());
      }
    }
  }

  void _onVideoVerticalDragEnd(DragEndDetails details) {
    _gestureKind = null;
    _showGestureMessage(_gestureHudText);
    _scheduleControlsHide();
  }

  Future<void> _startTemporary2x(LongPressStartDetails details) async {
    final width = MediaQuery.of(context).size.width;
    if (details.localPosition.dx < width * 0.52) return;
    final player = _player;
    if (player == null) return;
    _temporarySpeedActive = true;
    _gestureHudTimer?.cancel();
    await player.setRate(2.0);
    if (!mounted) return;
    setState(() {
      _speed = 2.0;
      _showGestureHud = true;
      _gestureHudText = '2.0×  SPEED';
      _controlsVisible = false;
    });
    _cancelControlsTimer();
  }

  Future<void> _endTemporary2x() async {
    if (!_temporarySpeedActive) return;
    _temporarySpeedActive = false;
    final player = _player;
    if (player != null) await player.setRate(1.0);
    if (!mounted) return;
    setState(() {
      _speed = 1.0;
      _gestureHudText = '1.0×  NORMAL';
    });
    _showGestureMessage(_gestureHudText);
    _scheduleControlsHide();
  }

  Future<void> _setVolumeBoost(int percent, {bool notify = true}) async {
    final player = _player;
    if (player == null) return;
    final safePercent = percent.clamp(100, 200).toInt();
    try {
      // Use mpv's native volume ceiling instead of an FFmpeg/LAVFI audio filter.
      // Some E-AC-3 streams/devices cannot initialise that filter graph.
      final platform = player.platform;
      if (platform is NativePlayer) {
        await platform.setProperty('volume-max', '200');
      }
      await player.setVolume(_isMuted ? 0.0 : _volume * safePercent);
      if (mounted) setState(() => _boostPercent = safePercent);
    } catch (e) {
      if (notify && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Volume boost could not be applied: $e')),
        );
      }
    }
  }

  String _audioTrackName(AudioTrack track) {
    if (track.id == 'auto') return 'Automatic';
    if (track.id == 'no') return 'Off';
    final language = track.language?.trim();
    final title = track.title?.trim();
    final details = [if (language != null && language.isNotEmpty) language, if (title != null && title.isNotEmpty) title];
    return details.isEmpty ? 'Audio track ${track.id}' : details.join(' • ');
  }

  String _subtitleTrackName(SubtitleTrack track) {
    if (track.id == 'auto') return 'Automatic';
    if (track.id == 'no') return 'Off';
    final language = track.language?.trim();
    final title = track.title?.trim();
    final details = [if (language != null && language.isNotEmpty) language, if (title != null && title.isNotEmpty) title];
    return details.isEmpty ? 'Subtitle ${track.id}' : details.join(' • ');
  }

  Future<void> _openAudioSubtitleSettings(Player player) async {
    _cancelControlsTimer();
    final audioTracks = player.state.tracks.audio;
    final subtitleTracks = player.state.tracks.subtitle;
    var sheetBoost = _boostPercent.toDouble();
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: _surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 26),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
              const SizedBox(height: 18),
              const Text('AUDIO & SUBTITLES', style: TextStyle(color: _cyan, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
              const SizedBox(height: 16),
              const Text('AUDIO LANGUAGE', style: TextStyle(color: _white, fontWeight: FontWeight.w800, fontSize: 12)),
              const SizedBox(height: 6),
              if (audioTracks.where((track) => track.id != 'auto' && track.id != 'no').isEmpty)
                const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('This video has only one audio track.', style: TextStyle(color: _muted, fontSize: 12)))
              else
                ...audioTracks.map((track) => ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: Text(_audioTrackName(track), style: const TextStyle(color: _white, fontSize: 13)),
                  trailing: player.state.track.audio.id == track.id ? const Icon(Icons.check_circle_rounded, color: _cyan) : null,
                  onTap: () async {
                    await player.setAudioTrack(track);
                    if (mounted) setState(() {});
                    if (sheetContext.mounted) Navigator.pop(sheetContext);
                  },
                )),
              const Divider(color: Colors.white12, height: 22),
              const Text('CAPTIONS / SUBTITLES', style: TextStyle(color: _white, fontWeight: FontWeight.w800, fontSize: 12)),
              const SizedBox(height: 6),
              if (subtitleTracks.where((track) => track.id != 'auto' && track.id != 'no').isEmpty)
                const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('No embedded subtitles found in this video.', style: TextStyle(color: _muted, fontSize: 12)))
              else
                ...subtitleTracks.map((track) => ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: Text(_subtitleTrackName(track), style: const TextStyle(color: _white, fontSize: 13)),
                  trailing: player.state.track.subtitle.id == track.id ? const Icon(Icons.check_circle_rounded, color: _cyan) : null,
                  onTap: () async {
                    await player.setSubtitleTrack(track);
                    if (mounted) setState(() {});
                    if (sheetContext.mounted) Navigator.pop(sheetContext);
                  },
                )),
              const Divider(color: Colors.white12, height: 22),
              Row(children: [
                const Expanded(child: Text('VOLUME BOOST', style: TextStyle(color: _white, fontWeight: FontWeight.w800, fontSize: 12))),
                Text('${sheetBoost.round()}%', style: const TextStyle(color: _cyan, fontSize: 12, fontWeight: FontWeight.w900)),
              ]),
              Slider(
                value: sheetBoost,
                min: 100,
                max: 200,
                divisions: 4,
                activeColor: _purple,
                inactiveColor: Colors.white24,
                onChanged: (value) {
                  setSheetState(() => sheetBoost = value);
                  setState(() => _boostPercent = value.round());
                },
                onChangeEnd: (value) async => _setVolumeBoost(value.round()),
              ),
              const Text('Boost may cause distortion on some videos or speakers. Keep it low when possible.', style: TextStyle(color: _muted, fontSize: 10)),
            ]),
          ),
        ),
      ),
    );
    _scheduleControlsHide();
  }

  Future<void> _toggleFullScreen() async {
    final next = !_fullScreen;
    _cancelControlsTimer();
    setState(() {
      _fullScreen = next;
      _controlsVisible = true;
    });
    if (next) {
      await SystemChrome.setPreferredOrientations(const [
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      await SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp]);
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
    _scheduleControlsHide();
  }

  Future<void> _openInAnotherPlayer() async {
    final file = await _currentAsset.file;
    if (!mounted) return;
    if (file == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Video file not available.')),
      );
      return;
    }
    await _player?.pause();
    await OpenFilex.open(file.path);
  }

  Future<void> _shareVideo() async {
    await widget.onShare([_currentAsset]);
  }

  @override
  void dispose() {
    _cancelControlsTimer();
    _gestureHudTimer?.cancel();
    unawaited(_brightnessChannel.invokeMethod<void>('resetBrightness').catchError((_) {}));
    final player = _player;
    if (player != null) {
      unawaited(_playingSubscription?.cancel());
      unawaited(_errorSubscription?.cancel());
      unawaited(player.dispose());
    }
    SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Widget _buildControls(Player player, Duration position, Duration duration, bool playing) {
    final shownPosition = _dragPosition ?? position;
    final totalMs = duration.inMilliseconds > 0 ? duration.inMilliseconds.toDouble() : 1.0;
    final progress = shownPosition.inMilliseconds.clamp(0, duration.inMilliseconds).toDouble();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      decoration: BoxDecoration(
        color: const Color(0xEE062A3A),
        border: Border(top: BorderSide(color: _cyan.withOpacity(.35))),
        boxShadow: [BoxShadow(color: _cyan.withOpacity(.12), blurRadius: 18, offset: const Offset(0, -3))],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          Text(_formatClock(shownPosition), style: const TextStyle(color: _white, fontSize: 10)),
          Expanded(child: Slider(
            value: progress.clamp(0.0, totalMs).toDouble(), min: 0, max: totalMs,
            activeColor: _cyan, inactiveColor: Colors.white24,
            onChanged: (value) { _cancelControlsTimer(); setState(() => _dragPosition = Duration(milliseconds: value.round())); },
            onChangeEnd: (value) async { await player.seek(Duration(milliseconds: value.round())); if (mounted) { setState(() => _dragPosition = null); _scheduleControlsHide(); } },
          )),
          Text(_formatClock(duration), style: const TextStyle(color: _white, fontSize: 10)),
        ]),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton(tooltip: 'Previous video', onPressed: _currentIndex > 0 ? () => _playAdjacent(-1) : null, icon: const Icon(Icons.skip_previous_rounded, color: Colors.white, size: 30)),
          IconButton(tooltip: '10 seconds back', onPressed: () => _skipBy(-10), icon: const Icon(Icons.replay_10_rounded, color: Colors.white, size: 28)),
          const SizedBox(width: 8),
          IconButton(tooltip: playing ? 'Pause' : 'Play', onPressed: _togglePlay, iconSize: 48,
            icon: Icon(playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded, color: _cyan)),
          const SizedBox(width: 8),
          IconButton(tooltip: '10 seconds forward', onPressed: () => _skipBy(10), icon: const Icon(Icons.forward_10_rounded, color: Colors.white, size: 28)),
          IconButton(tooltip: 'Next video', onPressed: _currentIndex < widget.playlist.length - 1 ? () => _playAdjacent(1) : null, icon: const Icon(Icons.skip_next_rounded, color: Colors.white, size: 30)),
        ]),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          IconButton(tooltip: _isMuted ? 'Unmute' : 'Mute', onPressed: _toggleMute,
            icon: Icon(_isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded, color: _cyan)),
          PopupMenuButton<double>(
            tooltip: 'Playback speed', initialValue: _speed, color: _surface2, onSelected: _changeSpeed,
            itemBuilder: (_) => const [PopupMenuItem(value: .5, child: Text('0.5×')), PopupMenuItem(value: .75, child: Text('0.75×')), PopupMenuItem(value: 1.0, child: Text('1.0× Normal')), PopupMenuItem(value: 1.25, child: Text('1.25×')), PopupMenuItem(value: 1.5, child: Text('1.5×')), PopupMenuItem(value: 2.0, child: Text('2.0×'))],
            child: Padding(padding: const EdgeInsets.all(8), child: Text('${_speed}×', style: const TextStyle(color: _white, fontSize: 11, fontWeight: FontWeight.w800))),
          ),
          IconButton(tooltip: _locked ? 'Unlock controls' : 'Lock controls', onPressed: _toggleLock,
            icon: Icon(_locked ? Icons.lock_rounded : Icons.lock_open_rounded, color: _cyan)),
          IconButton(tooltip: 'Fit: ${_fitMode == 0 ? 'Contain' : _fitMode == 1 ? 'Fill' : '16:9'}', onPressed: _cycleFitMode,
            icon: const Icon(Icons.fit_screen_rounded, color: _cyan)),
          IconButton(tooltip: 'Audio, subtitles and boost', onPressed: () => _openAudioSubtitleSettings(player),
            icon: const Icon(Icons.subtitles_rounded, color: _cyan)),
          IconButton(tooltip: _fullScreen ? 'Exit fullscreen' : 'Fullscreen', onPressed: _toggleFullScreen,
            icon: Icon(_fullScreen ? Icons.fullscreen_exit_rounded : Icons.fullscreen_rounded, color: _cyan)),
        ]),
      ]),
    );
  }

  Widget _buildPlayer(Player player, VideoController videoController) {
    return StreamBuilder<bool>(
      stream: player.stream.playing,
      initialData: player.state.playing,
      builder: (context, playingSnapshot) {
        final playing = playingSnapshot.data ?? player.state.playing;
        return StreamBuilder<Duration>(
          stream: player.stream.duration,
          initialData: player.state.duration,
          builder: (context, durationSnapshot) {
            final duration = durationSnapshot.data ?? player.state.duration;
            return StreamBuilder<Duration>(
              stream: player.stream.position,
              initialData: player.state.position,
              builder: (context, positionSnapshot) {
                final position = positionSnapshot.data ?? player.state.position;
                return Stack(fit: StackFit.expand, children: [
                  Positioned.fill(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: _locked ? null : _toggleControls,
                      onLongPressStart: _locked ? null : _startTemporary2x,
                      onLongPressEnd: _locked ? null : (_) => _endTemporary2x(),
                      onVerticalDragStart: _locked ? null : (details) => _onVideoVerticalDragStart(details, MediaQuery.of(context).size.height),
                      onVerticalDragUpdate: _locked ? null : (details) => _onVideoVerticalDragUpdate(details, MediaQuery.of(context).size.height),
                      onVerticalDragEnd: _locked ? null : _onVideoVerticalDragEnd,
                      child: _fitMode == 2
                          ? Center(child: AspectRatio(
                              aspectRatio: 16 / 9,
                              child: Video(controller: videoController, controls: NoVideoControls, fit: BoxFit.contain),
                            ))
                          : Video(
                              controller: videoController,
                              controls: NoVideoControls,
                              fit: _fitMode == 1 ? BoxFit.cover : BoxFit.contain,
                            ),
                    ),
                  ),
                  if (player.state.buffering)
                    const IgnorePointer(child: Center(child: CircularProgressIndicator(color: _cyan))),
                  if (_showGestureHud)
                    IgnorePointer(child: Center(child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
                      decoration: BoxDecoration(color: const Color(0xDD111827), borderRadius: BorderRadius.circular(18), border: Border.all(color: _cyan.withOpacity(.55))),
                      child: Text(_gestureHudText, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800)),
                    ))),
                  if (_controlsVisible && !_locked)
                    Positioned(left: 0, right: 0, top: 0, child: SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        child: Row(children: [
                          Expanded(child: Text(_currentAsset.title ?? 'Video', maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w700))),
                          IconButton(tooltip: 'Audio, subtitles and boost', onPressed: () => _openAudioSubtitleSettings(player),
                            icon: const Icon(Icons.subtitles_rounded, color: _cyan)),
                          IconButton(tooltip: _favorite ? 'Remove from favorites' : 'Add to favorites', onPressed: () {
                            widget.onFavorite(_currentAsset.id);
                            setState(() => _favorite = !_favorite);
                          }, icon: Icon(_favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                            color: _favorite ? const Color(0xFFFF6F9D) : Colors.white)),
                          IconButton(tooltip: 'Share video', onPressed: _shareVideo, icon: const Icon(Icons.share_rounded, color: Colors.white)),
                          IconButton(tooltip: 'Video details', onPressed: () => _showAssetInfo(context, _currentAsset),
                            icon: const Icon(Icons.info_outline_rounded, color: Colors.white)),
                        ]),
                      ),
                    )),
                  if (_locked)
                    Positioned(top: 12, right: 14, child: SafeArea(child: IconButton.filledTonal(
                      tooltip: 'Unlock player controls', onPressed: _toggleLock,
                      icon: const Icon(Icons.lock_rounded),
                    ))),
                  if (_controlsVisible && !_locked)
                    Positioned(left: 0, right: 0, bottom: 0,
                      child: Listener(
                        behavior: HitTestBehavior.translucent,
                        onPointerDown: (_) => _cancelControlsTimer(),
                        onPointerUp: (_) => _scheduleControlsHide(),
                        onPointerCancel: (_) => _scheduleControlsHide(),
                        child: _buildControls(player, position, duration, playing),
                      ),
                    ),
                ]);
              },
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final player = _player;
    final videoController = _videoController;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: null,
      body: SafeArea(
        top: false,
        bottom: false,
        child: _error != null
            ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.video_file_outlined, color: _muted, size: 48),
                const SizedBox(height: 12),
                Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                const SizedBox(height: 16),
                FilledButton.icon(onPressed: _initialiseVideo, icon: const Icon(Icons.refresh_rounded), label: const Text('Try again')),
              ])))
            : _loading || player == null || videoController == null
                ? const Center(child: CircularProgressIndicator(color: _cyan))
                : _buildPlayer(player, videoController),
      ),
    );
  }
}

Future<void> _showAssetInfo(BuildContext context, AssetEntity asset) async {
  final file = await asset.file;
  String fileSize = 'Unavailable';
  if (file != null) {
    try {
      final bytes = await file.length();
      fileSize = bytes > 1024 * 1024 ? '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB' : '${(bytes / 1024).toStringAsFixed(0)} KB';
    } catch (_) {}
  }
  if (!context.mounted) return;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: _surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
    builder: (context) => Padding(
      padding: const EdgeInsets.fromLTRB(22, 14, 22, 30),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
        const SizedBox(height: 20),
        const Text('VIDEO DETAILS', style: TextStyle(color: _cyan, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Text(asset.title ?? 'Untitled video', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 16, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        _InfoRow(label: 'Created', value: _formatDate(asset.createDateTime)),
        _InfoRow(label: 'Resolution', value: '${asset.width} × ${asset.height}'),
        _InfoRow(label: 'Duration', value: _formatDuration(asset.duration)),
        _InfoRow(label: 'File size', value: fileSize),
      ]),
    ),
  );
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(children: [Text(label, style: const TextStyle(color: _muted, fontSize: 12)), const Spacer(), Flexible(child: Text(value, textAlign: TextAlign.right, style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w600)))],),
  );
}

String _formatDate(DateTime date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final local = date.toLocal();
  return '${local.day} ${months[local.month - 1]} ${local.year}';
}

String _formatClock(Duration duration) {
  final totalSeconds = duration.inSeconds < 0 ? 0 : duration.inSeconds;
  final hours = totalSeconds ~/ 3600;
  final minutes = (totalSeconds % 3600) ~/ 60;
  final seconds = totalSeconds % 60;
  final mm = minutes.toString().padLeft(2, '0');
  final ss = seconds.toString().padLeft(2, '0');
  return hours > 0 ? '${hours.toString()}:$mm:$ss' : '$mm:$ss';
}

String _formatDuration(int seconds) {
  final hours = seconds ~/ 3600;
  final minutes = (seconds % 3600) ~/ 60;
  final remaining = seconds % 60;
  if (hours > 0) return '$hours:${minutes.toString().padLeft(2, '0')}:${remaining.toString().padLeft(2, '0')}';
  return '$minutes:${remaining.toString().padLeft(2, '0')}';
}
