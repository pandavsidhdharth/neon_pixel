import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';

void main() => runApp(const NeonPixelApp());

const neon = Color(0xFF32F5FF);
const bg = Color(0xFF070B13);
const panel = Color(0xFF111927);

class NeonPixelApp extends StatelessWidget {
  const NeonPixelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NEON PIXEL',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: neon, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const GalleryHome(),
    );
  }
}

class GalleryHome extends StatefulWidget {
  const GalleryHome({super.key});
  @override
  State<GalleryHome> createState() => _GalleryHomeState();
}

class _GalleryHomeState extends State<GalleryHome> {
  List<AssetEntity> photos = [];
  bool loading = true;
  String error = '';
  String query = '';
  int tab = 0;
  final Set<String> favorites = {};

  @override
  void initState() {
    super.initState();
    loadPhotos();
  }

  Future<void> loadPhotos() async {
    setState(() { loading = true; error = ''; });
    final permission = await PhotoManager.requestPermissionExtend();
    if (!permission.isAuth && !permission.hasAccess) {
      setState(() {
        loading = false;
        error = 'Photo permission is needed to show your gallery.';
      });
      return;
    }
    final albums = await PhotoManager.getAssetPathList(
      type: RequestType.image,
      hasAll: true,
      onlyAll: true,
    );
    final all = <AssetEntity>[];
    if (albums.isNotEmpty) {
      all.addAll(await albums.first.getAssetListRange(start: 0, end: 500));
    }
    if (!mounted) return;
    setState(() { photos = all; loading = false; });
  }

  List<AssetEntity> get visiblePhotos {
    final source = tab == 1 ? photos.where((p) => favorites.contains(p.id)).toList() : photos;
    if (query.trim().isEmpty) return source;
    return source.where((p) => (p.title ?? '').toLowerCase().contains(query.toLowerCase())).toList();
  }

  @override
  Widget build(BuildContext context) {
    final shown = visiblePhotos;
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: const LinearGradient(colors: [neon, Color(0xFF5678FF)]),
                      boxShadow: [BoxShadow(color: neon.withOpacity(.2), blurRadius: 18)],
                    ),
                    child: const Icon(Icons.photo_library_rounded, color: bg, size: 25),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('NEON PIXEL', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 2)),
                    SizedBox(height: 3),
                    Text('YOUR WORLD. IN EVERY FRAME.', style: TextStyle(color: neon, fontSize: 9, letterSpacing: 1.5)),
                  ])),
                  IconButton(
                    tooltip: 'Refresh gallery',
                    onPressed: loadPhotos,
                    icon: const Icon(Icons.refresh_rounded, color: neon),
                  ),
                ]),
                const SizedBox(height: 24),
                const Text('YOUR VISUAL', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
                const Text('UNIVERSE', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: neon)),
                const SizedBox(height: 7),
                Text('${shown.length} PHOTOS  •  LIVE GALLERY', style: const TextStyle(color: Colors.white54, letterSpacing: 1.4, fontSize: 11)),
                const SizedBox(height: 20),
                Container(
                  decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: neon.withOpacity(.25))),
                  child: TextField(
                    onChanged: (v) => setState(() => query = v),
                    decoration: const InputDecoration(
                      hintText: 'Search photos by filename...',
                      prefixIcon: Icon(Icons.search_rounded, color: neon),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 16),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Row(children: [
                  const Expanded(child: Text('YOUR GALLERY', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.2))),
                  _GlowTag(text: tab == 1 ? 'FAVORITES' : 'ALL PHOTOS'),
                ]),
                const SizedBox(height: 14),
              ]),
            )),
            if (loading)
              const SliverFillRemaining(child: Center(child: CircularProgressIndicator(color: neon)))
            else if (error.isNotEmpty)
              SliverFillRemaining(child: _EmptyState(
                icon: Icons.photo_library_outlined,
                title: 'PERMISSION NEEDED',
                subtitle: error,
                action: 'TRY AGAIN',
                onTap: loadPhotos,
              ))
            else if (shown.isEmpty)
              SliverFillRemaining(child: _EmptyState(
                icon: tab == 1 ? Icons.favorite_border : Icons.photo_outlined,
                title: tab == 1 ? 'NO FAVORITES YET' : 'NO PHOTOS FOUND',
                subtitle: tab == 1 ? 'Open a photo and tap the heart to save it here.' : 'Photos stored on your phone will appear here.',
                action: 'REFRESH GALLERY',
                onTap: loadPhotos,
              ))
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 110),
                sliver: SliverGrid(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final photo = shown[index];
                      return GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => PhotoViewer(
                            photos: shown,
                            initialIndex: index,
                            isFavorite: (id) => favorites.contains(id),
                            onFavorite: (id) => setState(() {
                              if (!favorites.add(id)) favorites.remove(id);
                            }),
                          ),
                        )),
                        child: Hero(
                          tag: photo.id,
                          child: Container(
                            decoration: BoxDecoration(
                              color: panel,
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(color: neon.withOpacity(.22)),
                              boxShadow: [BoxShadow(color: neon.withOpacity(.04), blurRadius: 14)],
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: Stack(fit: StackFit.expand, children: [
                              AssetEntityImage(photo, isOriginal: false, fit: BoxFit.cover),
                              Positioned(
                                left: 0, right: 0, bottom: 0, height: 70,
                                child: DecoratedBox(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black.withOpacity(.88)]),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 10, right: 8, bottom: 10,
                                child: Row(children: [
                                  Expanded(child: Text(photo.title ?? 'PHOTO ${index + 1}', maxLines: 1, overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700))),
                                  if (favorites.contains(photo.id)) const Icon(Icons.favorite, color: neon, size: 14),
                                ]),
                              ),
                              Positioned(
                                top: 9, right: 9,
                                child: Container(
                                  padding: const EdgeInsets.all(5),
                                  decoration: BoxDecoration(color: Colors.black.withOpacity(.5), borderRadius: BorderRadius.circular(8)),
                                  child: const Icon(Icons.open_in_full_rounded, size: 13, color: neon),
                                ),
                              ),
                            ]),
                          ),
                        ),
                      );
                    },
                    childCount: shown.length,
                  ),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .78,
                  ),
                ),
              ),
          ],
        ),
      ),
      bottomNavigationBar: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            decoration: BoxDecoration(color: const Color(0xEE0B111D), border: Border(top: BorderSide(color: neon.withOpacity(.2)))),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _NavItem(icon: Icons.grid_view_rounded, label: 'GALLERY', active: tab == 0, onTap: () => setState(() => tab = 0)),
                  _NavItem(icon: Icons.favorite_rounded, label: 'FAVORITES', active: tab == 1, onTap: () => setState(() => tab = 1)),
                  _NavItem(icon: Icons.refresh_rounded, label: 'REFRESH', active: false, onTap: loadPhotos),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class PhotoViewer extends StatefulWidget {
  final List<AssetEntity> photos;
  final int initialIndex;
  final bool Function(String) isFavorite;
  final void Function(String) onFavorite;
  const PhotoViewer({super.key, required this.photos, required this.initialIndex, required this.isFavorite, required this.onFavorite});
  @override
  State<PhotoViewer> createState() => _PhotoViewerState();
}

class _PhotoViewerState extends State<PhotoViewer> {
  late final PageController controller = PageController(initialPage: widget.initialIndex);
  late int index = widget.initialIndex;

  @override
  Widget build(BuildContext context) {
    final photo = widget.photos[index];
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(photo.title ?? 'PHOTO ${index + 1}', style: const TextStyle(fontSize: 13, letterSpacing: 1)),
          Text('${index + 1} / ${widget.photos.length}', style: const TextStyle(fontSize: 10, color: neon)),
        ]),
        actions: [
          IconButton(
            onPressed: () { widget.onFavorite(photo.id); setState(() {}); },
            icon: Icon(widget.isFavorite(photo.id) ? Icons.favorite : Icons.favorite_border, color: neon),
          ),
          IconButton(
            onPressed: () async {
              final file = await photo.file;
              if (file != null) {
                // Share can be added with a share plugin; this button opens system photo details for now.
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Photo is available in your phone gallery.')));
              }
            },
            icon: const Icon(Icons.info_outline, color: neon),
          ),
        ],
      ),
      body: PageView.builder(
        controller: controller,
        itemCount: widget.photos.length,
        onPageChanged: (i) => setState(() => index = i),
        itemBuilder: (context, i) => Center(
          child: InteractiveViewer(
            minScale: 1,
            maxScale: 5,
            child: Hero(
              tag: widget.photos[i].id,
              child: AssetEntityImage(widget.photos[i], isOriginal: true, fit: BoxFit.contain, width: double.infinity, height: double.infinity),
            ),
          ),
        ),
      ),
    );
  }
}

class _GlowTag extends StatelessWidget {
  final String text;
  const _GlowTag({required this.text});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(color: neon.withOpacity(.08), borderRadius: BorderRadius.circular(8), border: Border.all(color: neon.withOpacity(.35))),
    child: Text(text, style: const TextStyle(color: neon, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
  );
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _NavItem({required this.icon, required this.label, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: active ? neon : Colors.white54, size: 22),
        const SizedBox(height: 5),
        Text(label, style: TextStyle(fontSize: 9, letterSpacing: 1, color: active ? neon : Colors.white54, fontWeight: FontWeight.bold)),
      ]),
    ),
  );
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String action;
  final VoidCallback onTap;
  const _EmptyState({required this.icon, required this.title, required this.subtitle, required this.action, required this.onTap});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(30),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: neon, size: 52),
        const SizedBox(height: 18),
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
        const SizedBox(height: 10),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, height: 1.5)),
        const SizedBox(height: 20),
        OutlinedButton(onPressed: onTap, style: OutlinedButton.styleFrom(foregroundColor: neon, side: const BorderSide(color: neon)), child: Text(action)),
      ]),
    ),
  );
}
