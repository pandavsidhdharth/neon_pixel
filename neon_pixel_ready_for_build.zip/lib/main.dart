import 'dart:async';
import 'dart:math' as math;
import 'dart:io';
import 'package:package_info_plus/package_info_plus.dart';

import 'package:flutter/material.dart';
import 'widgets/vortex_logo.dart';
import 'package:cross_file/cross_file.dart';
import 'package:flutter/services.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';

part 'screens/home_screen.dart';
part 'screens/video_player_screen.dart';
part 'screens/external_video_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Bundled libmpv/FFmpeg engine for broad codec support, including E-AC-3.
  MediaKit.ensureInitialized();
  runApp(const VortexPlayerApp());
}

const _bg = Color(0xFF080409);
const _surface = Color(0xFF160810);
const _surface2 = Color(0xFF28101B);
const _secondary = Color(0xFF7E2038);
const _primary = Color(0xFFC51F45);
const _muted = Color(0xFFB79AA4);
const _white = Color(0xFFFFF4F6);
const _softAccent = Color(0xFFE88A9B);
const MethodChannel _externalChannel = MethodChannel('vortex_player/external');

class VortexPlayerApp extends StatelessWidget {
  const VortexPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VORTEX PLAYER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bg,
        colorScheme: ColorScheme.fromSeed(seedColor: _primary, brightness: Brightness.dark, surface: _surface),
        fontFamily: 'Roboto',
      ),
      home: const VortexLaunchScreen(),
    );
  }
}


class VortexLaunchScreen extends StatefulWidget {
  const VortexLaunchScreen({super.key});

  @override
  State<VortexLaunchScreen> createState() => _VortexLaunchScreenState();
}

class _VortexLaunchScreenState extends State<VortexLaunchScreen>
    with TickerProviderStateMixin {
  late final AnimationController _controller;
  late final AnimationController _ambienceController;
  late final Animation<double> _scale;
  late final Animation<double> _fade;
  late final Animation<double> _pulse;
  Timer? _transitionTimer;
  bool _showHome = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2850),
    );
    _ambienceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 5200),
    )..repeat();
    _scale = Tween<double>(begin: .58, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );
    _fade = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0, .90, curve: Curves.easeInOutCubic),
    );
    _pulse = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: .82, end: 1.10).chain(CurveTween(curve: Curves.easeOutBack)), weight: 64),
      TweenSequenceItem(tween: Tween(begin: 1.10, end: 1.0).chain(CurveTween(curve: Curves.easeInOut)), weight: 36),
    ]).animate(_controller);
    _controller.forward();
    _transitionTimer = Timer(const Duration(milliseconds: 3350), () {
      if (mounted) setState(() => _showHome = true);
    });
  }

  @override
  void dispose() {
    _transitionTimer?.cancel();
    _controller.dispose();
    _ambienceController.dispose();
    super.dispose();
  }

  Widget _buildAnimatedTitle() {
    const title = 'VORTEX PLAYER';
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(title.length, (index) {
          final character = title[index];
          if (character == ' ') return const SizedBox(width: 9);
          final start = .48 + index * .025;
          final value = Curves.easeOutBack.transform(
            ((_controller.value - start) / .30).clamp(0.0, 1.0).toDouble(),
          ).clamp(0.0, 1.0).toDouble();
          return Opacity(
            opacity: value,
            child: Transform.translate(
              offset: Offset(0, (1 - value) * 22),
              child: Text(
                character,
                style: const TextStyle(
                  color: _white,
                  fontSize: 21,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.7,
                  shadows: [
                    Shadow(color: Color(0xFFFF315F), blurRadius: 20),
                    Shadow(color: Color(0xFFB91543), blurRadius: 34),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildSplash() => Scaffold(
    backgroundColor: _bg,
    body: Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0, -.05),
          radius: 1.12,
          colors: [Color(0xFF76132F), Color(0xFF310B1B), Color(0xFF10050B), _bg],
          stops: [0, .34, .72, 1],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Positioned.fill(
            child: RepaintBoundary(
              child: AnimatedBuilder(
                animation: Listenable.merge([_controller, _ambienceController]),
                builder: (context, _) => CustomPaint(
                  painter: _VortexLaunchPainter(
                    intro: _controller.value,
                    phase: _ambienceController.value,
                  ),
                ),
              ),
            ),
          ),
          Center(
            child: FadeTransition(
              opacity: _fade,
              child: ScaleTransition(
                scale: _scale,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: Listenable.merge([_controller, _ambienceController]),
                      builder: (context, child) => Transform.scale(
                        scale: _pulse.value * (1 + math.sin(_ambienceController.value * math.pi * 2) * .012),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(color: const Color(0xFFFF315F).withValues(alpha: .22 + _ambienceController.value * .08), blurRadius: 54, spreadRadius: 9),
                              BoxShadow(color: const Color(0xFFFFA16C).withValues(alpha: .12), blurRadius: 88, spreadRadius: 18),
                            ],
                          ),
                          child: VortexLogoMark(size: 158, progress: _controller.value),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    _buildAnimatedTitle(),
                    const SizedBox(height: 12),
                    AnimatedBuilder(
                      animation: _controller,
                      builder: (context, child) => Opacity(
                        opacity: Curves.easeIn.transform(((_controller.value - .58) / .30).clamp(0.0, 1.0).toDouble()),
                        child: child,
                      ),
                      child: const Text(
                        'NEXT-GEN CINEMATIC PLAYBACK',
                        style: TextStyle(color: Color(0xFFFF9AAE), fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 3.0),
                      ),
                    ),
                    const SizedBox(height: 34),
                    SizedBox(
                      width: 176,
                      child: AnimatedBuilder(
                        animation: _controller,
                        builder: (context, child) => Column(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Stack(children: [
                                Container(height: 4, color: Colors.white.withValues(alpha: .12)),
                                FractionallySizedBox(
                                  widthFactor: _controller.value,
                                  child: Container(
                                    height: 4,
                                    decoration: const BoxDecoration(
                                      gradient: LinearGradient(colors: [Color(0xFFFFA16C), Color(0xFFFF315F), Color(0xFF9C1740)]),
                                      boxShadow: [BoxShadow(color: Color(0xFFFF315F), blurRadius: 12, spreadRadius: 2)],
                                    ),
                                  ),
                                ),
                              ]),
                            ),
                            const SizedBox(height: 11),
                            Text(
                              _controller.value < .34 ? 'IGNITING MEDIA ENGINE' : _controller.value < .72 ? 'ASSEMBLING VORTEX CORE' : 'READY TO PLAY',
                              style: const TextStyle(color: Color(0xFFFFC2CE), fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 2.0),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 34,
            child: AnimatedBuilder(
              animation: _ambienceController,
              builder: (context, child) => Opacity(
                opacity: .42 + math.sin(_ambienceController.value * math.pi * 2) * .12,
                child: child,
              ),
              child: const Text(
                'V O R T E X   •   P R E M I U M   E D I T I O N',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 8, fontWeight: FontWeight.w700, letterSpacing: 1.5),
              ),
            ),
          ),
        ],
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const VortexHome(),
        AnimatedOpacity(
          opacity: _showHome ? 0 : 1,
          duration: const Duration(milliseconds: 760),
          curve: Curves.easeInOutCubic,
          child: IgnorePointer(ignoring: _showHome, child: _buildSplash()),
        ),
      ],
    );
  }
}

class _VortexLaunchPainter extends CustomPainter {
  final double intro;
  final double phase;
  const _VortexLaunchPainter({required this.intro, required this.phase});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height * .43);
    final unit = math.min(size.width, size.height).toDouble();
    final t = phase * math.pi * 2;
    final reveal = Curves.easeOutCubic.transform(intro.clamp(0.0, 1.0).toDouble());

    // Rotating orbital energy rings behind the Vortex emblem.
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(t * .22);
    for (var i = 0; i < 4; i++) {
      final radius = unit * (.19 + i * .055);
      final rect = Rect.fromCenter(center: Offset.zero, width: radius * 2.0, height: radius * (1.28 + i * .08));
      final ringPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = i == 0 ? 1.5 : .8
        ..color = (i.isEven ? const Color(0xFFFF5478) : const Color(0xFFFFB078)).withValues(alpha: .10 + .10 * math.sin(t + i).abs());
      canvas.drawOval(rect, ringPaint);
      final sparkAngle = t * (i.isEven ? 1.0 : -1.0) + i * 1.67;
      final spark = Offset(math.cos(sparkAngle) * radius, math.sin(sparkAngle) * radius * .64);
      canvas.drawCircle(spark, 2.0 + (i % 2), Paint()
        ..color = const Color(0xFFFFB88A).withValues(alpha: .85)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5));
    }
    canvas.restore();

    // Long neon streaks converge from both edges during the logo reveal.
    final beamProgress = Curves.easeInOutCubic.transform((reveal / .72).clamp(0.0, 1.0).toDouble());
    final beamAlpha = (1 - Curves.easeOut.transform((reveal - .34).clamp(0.0, 1.0).toDouble())).clamp(0.0, 1.0).toDouble();
    for (var i = 0; i < 7; i++) {
      final offset = (i - 3) * unit * .025;
      final leftStart = Offset(-unit * .18, center.dy + offset - unit * .12);
      final rightStart = Offset(size.width + unit * .18, center.dy - offset + unit * .12);
      final leftEnd = Offset.lerp(leftStart, Offset(center.dx - unit * .13, center.dy + offset * .12), beamProgress)!;
      final rightEnd = Offset.lerp(rightStart, Offset(center.dx + unit * .13, center.dy - offset * .12), beamProgress)!;
      final color = i.isEven ? const Color(0xFFFF4773) : const Color(0xFFFFB16F);
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = i == 3 ? 2.8 : 1.0
        ..color = color.withValues(alpha: beamAlpha * (i == 3 ? .52 : .22))
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, i == 3 ? 8 : 3);
      final leftPath = Path()..moveTo(leftStart.dx, leftStart.dy)..quadraticBezierTo(center.dx - unit * .34, center.dy - offset, leftEnd.dx, leftEnd.dy);
      final rightPath = Path()..moveTo(rightStart.dx, rightStart.dy)..quadraticBezierTo(center.dx + unit * .34, center.dy + offset, rightEnd.dx, rightEnd.dy);
      canvas.drawPath(leftPath, paint);
      canvas.drawPath(rightPath, paint);
    }

    // Ember particles drift along orbital paths; deterministic positions avoid per-frame allocations from RNG.
    for (var i = 0; i < 58; i++) {
      final seed = i * 2.399963229728653;
      final orbit = unit * (.16 + (i % 9) * .045);
      final speed = (i % 5 + 1) * .10;
      final angle = seed + t * speed * (i.isEven ? 1 : -1);
      final drift = math.sin(t * .7 + seed) * unit * .018;
      final x = center.dx + math.cos(angle) * (orbit + drift);
      final y = center.dy + math.sin(angle) * (orbit * .66 + drift);
      final radius = .7 + (i % 4) * .42;
      final alpha = (.10 + .42 * ((math.sin(t * 1.3 + seed) + 1) / 2)) * (.35 + reveal * .65);
      final color = i % 3 == 0 ? const Color(0xFFFFC18D) : const Color(0xFFFF527A);
      final dot = Paint()
        ..color = color.withValues(alpha: alpha)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, radius * 2.2);
      canvas.drawCircle(Offset(x, y), radius * 2.6, dot);
      canvas.drawCircle(Offset(x, y), radius * .72, Paint()..color = Colors.white.withValues(alpha: alpha * .86));
    }

    // Fine scan lines and a cinematic bottom glow.
    final glowRect = Rect.fromCenter(center: Offset(center.dx, size.height * .86), width: size.width * .92, height: unit * .22);
    canvas.drawOval(glowRect, Paint()
      ..shader = RadialGradient(colors: [const Color(0xFFFF315F).withValues(alpha: .16), Colors.transparent]).createShader(glowRect));
    final scanPaint = Paint()..color = const Color(0xFFFF8FA7).withValues(alpha: .035);
    for (var i = 0; i < 18; i++) {
      final y = size.height * .08 + i * size.height * .047;
      canvas.drawRect(Rect.fromLTWH(0, y, size.width, .6), scanPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _VortexLaunchPainter oldDelegate) =>
      oldDelegate.intro != intro || oldDelegate.phase != phase;
}

Future<void> _showAssetInfo(BuildContext context, AssetEntity asset) async {
  final file = await asset.file;
  String fileSize = 'Unavailable';
  if (file != null) {
    try {
      final bytes = await file.length();
      fileSize = bytes > 1024 * 1024 ? '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB' : '${(bytes / 1024).toStringAsFixed(0)} KB';
    } catch (_) {}
  }
  if (!context.mounted) return;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: _surface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
    builder: (context) => Padding(
      padding: const EdgeInsets.fromLTRB(22, 14, 22, 30),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10)))),
        const SizedBox(height: 20),
        const Text('VIDEO DETAILS', style: TextStyle(color: _primary, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
        const SizedBox(height: 8),
        Text(asset.title ?? 'Untitled video', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _white, fontSize: 16, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        _InfoRow(label: 'Created', value: _formatDate(asset.createDateTime)),
        _InfoRow(label: 'Resolution', value: '${asset.width} × ${asset.height}'),
        _InfoRow(label: 'Duration', value: _formatDuration(asset.duration)),
        _InfoRow(label: 'File size', value: fileSize),
      ]),
    ),
  );
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(children: [Text(label, style: const TextStyle(color: _muted, fontSize: 12)), const Spacer(), Flexible(child: Text(value, textAlign: TextAlign.right, style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.w600)))],),
  );
}

String _formatDate(DateTime date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final local = date.toLocal();
  return '${local.day} ${months[local.month - 1]} ${local.year}';
}

String _formatClock(Duration duration) {
  final totalSeconds = duration.inSeconds < 0 ? 0 : duration.inSeconds;
  final hours = totalSeconds ~/ 3600;
  final minutes = (totalSeconds % 3600) ~/ 60;
  final seconds = totalSeconds % 60;
  final mm = minutes.toString().padLeft(2, '0');
  final ss = seconds.toString().padLeft(2, '0');
  return hours > 0 ? '${hours.toString()}:$mm:$ss' : '$mm:$ss';
}

String _formatDuration(int seconds) {
  final hours = seconds ~/ 3600;
  final minutes = (seconds % 3600) ~/ 60;
  final remaining = seconds % 60;
  if (hours > 0) return '$hours:${minutes.toString().padLeft(2, '0')}:${remaining.toString().padLeft(2, '0')}';
  return '$minutes:${remaining.toString().padLeft(2, '0')}';
}
