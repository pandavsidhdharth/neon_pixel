# V48 Changes

- Player palette refreshed to cinematic ink / electric teal / warm amber.
- Main and Open With player controls use lighter translucent glass surfaces, blur and lower-opacity button fills.
- Resume / Start over prompt is now a compact left-side chip, not a full-width banner.
- Playback controls remain visible briefly, then auto-hide after 3 seconds while playback is active; touching the top or bottom controls restarts the hide timer.
- Automatic next-video playback remains enabled for the current library playlist after completion. Repeat One and Repeat All behavior is retained.
- App ID `com.vortex.player` is unchanged; signing configuration is unchanged.

## Validation

Source-level checks and archive integrity are run. Flutter/Dart SDK is not available in the build environment, so APK compilation, device playback, and signing-certificate matching are not claimed.
