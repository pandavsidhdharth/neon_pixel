# Third-party media playback notices

VORTEX PLAYER uses the following open-source Flutter packages for media playback:

- `media_kit` – see https://pub.dev/packages/media_kit and its MIT license.
- `media_kit_video` – see https://pub.dev/packages/media_kit_video and its MIT license.
- `media_kit_libs_video` – see https://pub.dev/packages/media_kit_libs_video for the native playback libraries and their applicable notices.

The native playback stack includes libmpv/FFmpeg components. Their component-specific licenses and notices must be retained when redistributing builds; do not assume the full native stack is covered only by the Flutter wrapper's MIT license.
