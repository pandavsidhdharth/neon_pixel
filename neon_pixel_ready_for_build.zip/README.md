# VORTEX PLAYER V47

- **Version:** `2.3.0+36`
- **Android application ID:** `com.vortex.player`
- **Android namespace:** `com.neonpixel.app`
- **Target:** Android / OnePlus Nord 5

## V47 – Liquid Glass redesign

- Reworked the Home screen with a deep violet / midnight gradient and soft ambient glow.
- Replaced the standard bottom navigation with a floating Liquid Glass bar for Library, Favourites and Settings.
- Restyled video cards, folder cards, library toolbar and search surface with translucent surfaces, fine borders and softer highlights.
- Added matching glass surfaces to the main player's top and bottom controls and the Open-with player's controls.
- Preserved the existing library, favourites, sorting, playback, subtitles, resume, audio-track, PiP, screenshot, bookmark, timer and gesture features.
- The redesign is presentation-only; existing media and user preference keys are unchanged.

## V46 – Notification audio focus and PiP

- Short duckable notification sounds lower media volume rather than forcing a pause; calls and stronger audio-focus losses still pause.
- Temporary inactive lifecycle overlays no longer pause playback.
- Added Picture-in-Picture entry controls and automatic PiP where the Android version supports it.

## Build and upgrade safety

Upload this source ZIP to the repository root using the workflow's expected filename `neon_pixel_ready_for_build.zip`, replacing the previous source ZIP. Keep the repository's existing `.github/workflows` folder and workflow file unchanged. The archive has root-level `android/`, `lib/`, and `pubspec.yaml` files, and `android/gradlew` is executable.

The Android `applicationId` remains `com.vortex.player`. For an in-place update, the APK must also be signed with the same release keystore / signing certificate as the installed app. Do not uninstall the working version to work around a signature conflict.

## Validation limits

ZIP integrity, YAML parsing, Android XML parsing, and source delimiter / structural checks were run. Flutter, Dart and Gradle SDKs are not available in this environment, so `flutter analyze`, APK compilation, signing compatibility and OnePlus Nord 5 runtime rendering have not been verified here.
