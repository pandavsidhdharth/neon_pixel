# VORTEX PLAYER

A premium Android video player built with Flutter and media_kit.

## V20 changes
- Playback position is saved separately for every video and restored when that video is opened again.
- A **Continue Watching** button on the home screen opens the last-played video at its saved position.
- Swipe left/right across the video to seek backward/forward in 5-second steps (each approximately 70 logical pixels of movement).
- Swipe vertically on the left side to adjust brightness; swipe vertically on the right side to adjust playback volume from 0% up to 200% using mpv's native volume ceiling.
- Volume boost is controlled directly by the right-side vertical gesture; the separate boost slider/settings entry has been removed.
- Audio-track and subtitle-track selectors are separate buttons in the top-right toolbar.
- Lock is at the far left of the bottom playback-control row; Fit is at the far right.
- Playback, skip, previous/next, speed, mute, lock, fullscreen and fit controls share one row below the seek bar.
- The bottom panel is translucent with background blur so the video remains visible behind it.
- V19 features remain: folder-first library, overlay controls, MPV native volume ceiling (no FFmpeg/LAVFI boost filter), and Android application ID `com.vortex.player`.

## Build
GitHub Actions uses Flutter 3.38.10, Java 17, Android NDK 27.0.12077973 and builds a release APK.

The app's Android application ID remains `com.vortex.player`, and the version is `2.0.2+9`. Keep the GitHub Actions debug-signing-key cache in the repository's root workflow so later VORTEX builds can update the installed VORTEX app. The CI debug key is suitable for personal sideload testing, not production distribution.

## Validation note
The source archive and configuration files were checked for ZIP/YAML/XML integrity. A Flutter/Dart toolchain was not available in the creation environment, so this archive has not been run through `flutter analyze` or built into an APK here. The GitHub Actions build is still required.
