# NEON PIXEL — Flutter Photo Gallery

A dark, cyan-neon photo gallery starter app for Android.

## Features
- Reads local phone photos with permission
- Neon dark gallery grid and filename search
- Full-screen swipe viewer
- Pinch-to-zoom photo viewing
- In-app favorites (session-only in this starter)
- Refresh gallery

## Run
1. Install Flutter SDK and Android Studio.
2. Create/open this project folder.
3. Run `flutter pub get`
4. Run `flutter run` with an Android phone connected or emulator open.

## Android permissions
`photo_manager` handles photo permission prompts on Android. If your target SDK or plugin version requires manual manifest configuration, follow the current `photo_manager` Android setup instructions.

This is source code, not an installed APK. Build an APK with:
`flutter build apk --release`
