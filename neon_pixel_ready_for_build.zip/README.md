# VORTEX PLAYER V49

- **Version:** `2.4.0+38`
- **Android application ID:** `com.vortex.player`
- **Android namespace:** `com.neonpixel.app`
- **Target:** Android / OnePlus Nord 5

## V48 – Cinematic player polish and autoplay queue

- Replaced the player-only purple accents with a cinematic deep-ink, electric-teal and warm-amber palette; the Home screen palette is unchanged.
- Made the playback top bar and bottom control deck more transparent with stronger background blur and fine glass borders, so the video remains visible behind controls.
- Reduced the resume prompt to a compact left-aligned glass chip with a shorter label and smaller Start over action.
- Kept automatic control hiding after three seconds of playback and re-arms the hide timer when the top or bottom controls are touched.
- Kept automatic next-video playback enabled for the active library playlist; when a video completes the next visible video starts automatically. Repeat One and Repeat All remain supported.
- Applied the same compact resume prompt and translucent player styling to Open With playback.
- Kept `applicationId` and the Gradle signing configuration unchanged. The signing certificate still needs to be checked against the installed V47 APK before update installation.

## V47 – Liquid Glass redesign

- Reworked the Home screen with a deep violet / midnight gradient and soft ambient glow.
- Replaced the standard bottom navigation with a floating Liquid Glass bar for Library, Favourites and Settings.
- Restyled video cards, folder cards, library toolbar and search surface with translucent surfaces, fine borders and softer highlights.
- Added matching glass surfaces to the main player's top and bottom controls and the Open-with player's controls.
- Preserved the existing library, favourites, sorting, playback, subtitles, resume, audio-track, PiP, screenshot, bookmark, timer and gesture features.
- The redesign is presentation-only; existing media and user preference keys are unchanged.

## V46 – Notification audio focus and PiP

- Short duckable notification sounds lower media volume rather than forcing a pause; calls and stronger audio-focus losses still pause.
- Temporary inactive lifecycle overlays no longer pause playback.
- Added Picture-in-Picture entry controls and automatic PiP where the Android version supports it.

## Build and upgrade safety

Upload this source ZIP to the repository root using the workflow's expected filename `neon_pixel_ready_for_build.zip`, replacing the previous source ZIP. Keep the repository's existing `.github/workflows` folder and workflow file unchanged. The archive has root-level `android/`, `lib/`, and `pubspec.yaml` files, and `android/gradlew` is executable.

The Android `applicationId` remains `com.vortex.player`. For an in-place update, the APK must also be signed with the same release keystore / signing certificate as the installed app. Do not uninstall the working version to work around a signature conflict.

## Validation limits

ZIP integrity, YAML parsing, Android XML parsing, and source delimiter / structural checks were run. Flutter, Dart and Gradle SDKs are not available in this environment, so `flutter analyze`, APK compilation, signing compatibility and OnePlus Nord 5 runtime rendering have not been verified here.


## V49 – Ion-Core visual identity refresh
- Unified the app palette to obsidian, ion-cyan and molten amber.
- Replaced the in-app logo and Android launcher foreground artwork with the new orbital V / play-core emblem.
- Refreshed the animated launch screen palette and orbit effects.
- Made every player control button surface lightly transparent, including Play/Pause, Previous/Next, speed, rotate, fit, PiP, audio and subtitle actions.
- App ID and Gradle signing configuration remain unchanged; verify the new APK certificate matches the installed app before update.
