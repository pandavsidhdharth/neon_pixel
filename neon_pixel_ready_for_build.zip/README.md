# NEON PIXEL — Personal Photo & Video Gallery

A premium, dark-themed local gallery app for Android, built with Flutter.

## Included features
- Browse photos and videos stored on the phone
- Album browser with album cover previews and item counts
- Persistent favorites saved on the device
- Full-screen photo viewer with swipe navigation and pinch-to-zoom
- Video playback with timeline scrubbing and 10-second skip controls
- Share one item or select multiple items to share
- Multi-select photos and videos and add/remove favorites in bulk
- Search by media filename/title
- Grid and list layouts
- Newest-first and oldest-first sorting
- Media details: creation date, resolution, file size and type
- Pull-to-refresh and gallery permission recovery

## Build
1. Install Flutter SDK and Android Studio.
2. Run `flutter pub get`.
3. Run `flutter build apk --release`.

The GitHub Actions workflow in `.github/workflows/build-apk.yml` builds the release APK from this project ZIP.
