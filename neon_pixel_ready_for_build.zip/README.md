# VORTEX PLAYER V32

- **Version:** `2.0.14+21`
- **Android application ID:** `com.vortex.player`
- **Target device:** Android, including OnePlus Nord 5

## V32 highlight — cinematic launch experience
- 3.35-second crimson-and-amber launch sequence with converging light beams, rotating energy rings, ember particles, scan lines, a glowing logo assembly, letter-by-letter wordmark reveal, and a smooth cross-fade into the library.
- Video and folder cards use staggered fade/slide/scale entry transitions.
- Swipe-seek HUD values animate with a translucent crimson glass treatment.

## Player and library features included
- Long-press starts temporary `2×`; drag upward increases in `0.5×` steps to `4×`, drag downward reduces to `1×`; release restores the saved normal speed.
- Horizontal swipe seeks with a configurable interval: 5, 10, 15, 20, 30, 45, or 60 seconds.
- Left/right vertical swipe controls brightness and volume, with translucent side indicators.
- Subtitle size and vertical position can be changed in the subtitle panel; subtitles can also be repositioned by dragging over the lower-center subtitle zone.
- Select multiple videos, Select All, delete selected, delete one video, or delete the videos inside a folder, with confirmation before deletion.
- Continue Watching excludes completed videos and retains the resume/start-over prompt.
- Repeat controls are in the More menu rather than the bottom control row.
- Folder-first library, favorites, search, grid/list modes, and newest/oldest sorting. Grid/list and sort preferences are remembered.
- Portrait-safe fit, landscape fit behavior, audio/subtitle track selection, external subtitles, resume progress, bookmarks, and sleep timer.
- Android package ID remains `com.vortex.player`.

## Build note
Upload this ZIP as `neon_pixel_ready_for_build.zip` in the repository root and run the repository's existing GitHub Actions workflow. The workflow stored in the repository root is separate from this project ZIP; this package does not replace it.

Flutter/Dart SDK is not available in the current build environment, so this source has not been compiled into an APK or device-tested here. Do not uninstall an installed VORTEX app until GitHub Actions produces the new APK successfully and signing compatibility is confirmed.
