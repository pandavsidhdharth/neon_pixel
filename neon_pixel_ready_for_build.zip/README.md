# VORTEX PLAYER

A premium Android video player built with Flutter and media_kit.

## V19 changes
- Folder-first video library: choose a video folder, then browse its clips.
- Player canvas remains full-size when controls appear; controls overlay the video.
- Cyan bottom control panel, seek bar, previous/next clip buttons.
- Volume slider removed from the control panel; volume remains available through mute and right-side swipe gestures.
- Audio/subtitle/boost settings remain accessible from the top-right subtitles button.
- Screen lock and Fit modes (Contain, Fill, 16:9).
- Volume boost now uses mpv native volume ceiling instead of an FFmpeg/LAVFI audio filter, avoiding the prior filter-initialization failure path.
- New Android application ID `com.vortex.player` lets VORTEX install alongside the legacy NEON PIXEL app.
- GitHub Actions caches the debug signing key for subsequent VORTEX updates.

## Build
GitHub Actions uses Flutter 3.38.10, Java 17, Android NDK 27.0.12077973 and builds a release APK.

Note: the first VORTEX build creates the persistent CI debug signing key in the GitHub Actions cache; subsequent builds should use that same cached key. This is suitable for personal sideload testing, not production distribution.
