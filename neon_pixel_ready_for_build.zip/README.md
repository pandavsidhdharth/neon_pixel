# VORTEX PLAYER V36

- **Version:** `2.0.18+25`
- **Android application ID:** `com.vortex.player`
- **Target:** Android / OnePlus Nord 5

## V36 updates

- Subtitle position can now be changed **only through Settings**. The center-screen vertical subtitle drag mode and its old preference are no longer used.
- Vertical swipes on the player are reserved for brightness (left half) and volume (right half).
- Added a dedicated Settings page with clearly labelled subtitle size and position sliders, a live preview, reset action, configurable horizontal seek interval, and library Grid/List and sort preferences.
- Subtitle size and position are applied to `media_kit_video` using its `SubtitleViewConfiguration` styling and padding properties.
- Refreshed the full app theme to midnight navy, crimson, and ice-blue; redesigned the Home header, action buttons, collection toolbar, and video cards.
- Preserves the prior V35/V34 player functions including 2×–4× long-press speed, left/right swipe seek, audio focus, bulk selection/delete, Continue/Start Over/X resume prompt, external subtitles, fit mode, favourites, and the cinematic splash animation.

## Build and safety notes

- Android application ID remains `com.vortex.player`.
- Upload this ZIP to the repository root using the exact name `neon_pixel_ready_for_build.zip`; the existing root GitHub Actions workflow is separate and must remain in place.
- This source was not compiled here because Flutter/Dart SDK is unavailable. ZIP, YAML, XML, and static source checks are not a substitute for `flutter analyze`, APK build, or testing on the OnePlus Nord 5.
- The previous GitHub Actions signing-key cache reported a cache miss and missing keystore path. Signing continuity remains unresolved. Do not uninstall or install an APK until the new build and signing compatibility have been verified.


## V37 Home controls update

The Home header no longer shows the three-dot overflow menu. Bulk delete now uses a plain trash icon instead of the trash-with-lines sweep icon. Refresh and About are available inside Settings; Grid/List and sorting controls remain in Settings.
