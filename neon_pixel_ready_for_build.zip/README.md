# VORTEX PLAYER 2.0.8+15

Flutter Android local video player.

## Build

The repository root workflow builds a single Android ARM64 APK. The build workflow should use the original signing keystore saved in GitHub Actions secrets to preserve install/update compatibility. Keep `pubspec.lock` committed.

## Features in this update

- Folder-name search, global favorites, and recent Continue Watching row.
- Playback speed/repeat settings persistence, repeat-one/repeat-all, automatic next, and temporary 2x that restores the selected speed.
- Serialized next/previous switching, brightness continuity, lifecycle auto-pause, and persistent progress.
- External SRT/VTT subtitles and Android Open with support for shared video files.
- System media-volume control, volume boost above system maximum, bookmarks with delete, and sleep timer countdown.
- About/licenses page, adaptive launcher icon, and 1.2-second animated launch overlay with the home library loading underneath.

External content URI playback copies the selected/shared source file into the application's cache before opening it. Test large files and OEM-specific share intents on the target device.


## V26 Player refinements
- Removed dedicated 10-second buttons from the bottom control row; double-tap seek remains.
- Full-bleed video is the default fit to avoid side black bars; Fit cycles through Fill, 16:9, and Contain.
- Tap the right-side duration label to toggle total duration and remaining time.
- Refreshed dark-crimson theme and converging-orbit logo animation.
- Auto-next advances exactly one item in the current playlist; Repeat One and Repeat All remain supported.
