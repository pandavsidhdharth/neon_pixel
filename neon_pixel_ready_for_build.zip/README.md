# NEON PIXEL — Personal Photo & Video Gallery

A premium dark-themed local photo and video gallery for Android, built with Flutter.

## Gallery features
- Browse photos and videos stored on the phone
- Albums include photos and videos
- Persistent favorites saved locally on the device
- Full-screen photo viewer with swipe navigation and pinch-to-zoom
- Search media by filename/title
- Grid and list layouts, with 2/3/4-column grid choices
- Newest-first and oldest-first sorting
- Multi-select, select all, bulk favorite and share
- Media details: creation date, resolution, file size and duration
- Pull-to-refresh and permission recovery

## Video player features
- Explicit full-volume initialization for local videos
- Play and pause, 10-second rewind and forward
- Scrubbable timeline with elapsed and total time
- Volume slider and mute/unmute control
- Playback speeds: 0.5×, 0.75×, 1×, 1.25×, 1.5× and 2×
- Landscape immersive full-screen mode
- Favorite, share, media details and retry on playback error

## Build
1. Install Flutter SDK and Android Studio.
2. Run `flutter pub get`.
3. Run `flutter build apk --release --no-tree-shake-icons`.

The GitHub Actions workflow in `.github/workflows/build-apk.yml` can build the release APK.
