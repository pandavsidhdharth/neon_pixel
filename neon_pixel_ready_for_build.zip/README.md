# VORTEX PLAYER V22

Personal Android video player built with Flutter and media_kit.

## V22 updates
- Folder library supports both Grid and List layouts.
- Tapping a video with saved progress asks Continue or Start from Beginning.
- The floating bottom-right play button resumes the most recently watched video directly, without a prompt.
- Playback waits for media duration to load before seeking, retries a missed seek, and saves progress every 2 seconds and when the app is paused.
- Android Back returns one level: video player to library, folder to folder list, search to library.
- Animated VORTEX PLAYER launch screen with a compact title.
- Refined folder cards with per-folder video counts.

Package ID: `com.vortex.player`
Version: `2.0.4+11`

Build using the repository's root GitHub Actions workflow and upload this archive as `neon_pixel_ready_for_build.zip`.
