# VORTEX PLAYER V23

Personal Android video player built with Flutter and media_kit.

## V23 updates
- Refined Midnight Aurora visual theme and animated orbital VORTEX launch logo.
- Kept the player focused on core playback controls: play/pause, previous/next, ±10-second seek, speed, fit mode, lock, and mute.
- Added a Playing Queue sheet for the current folder/playlist.
- Added per-video playback bookmarks with one-tap seek.
- Added an optional sleep timer (15, 30, 45, 60, or 90 minutes).
- Kept the existing subtitle/audio track selectors, favourites, sharing, video information, swipe seeking, brightness and volume gestures, and resume support.
- Removed an unused external-player integration dependency.
- Deliberately did not add low-value clutter such as video cutting, mirror/flip, screenshot tools, A-B editing, or audio effects/equalizer.

Package ID: `com.vortex.player`
Version: `2.0.5+12`

Upload this archive to the repository root as `neon_pixel_ready_for_build.zip` and run the repository's existing GitHub Actions workflow. The workflow file in the repository remains separate from the workflow file embedded in this archive.

Build note: source checks have been run in the available environment, but a Flutter Android compile and on-device playback test still need to be completed by GitHub Actions and the phone.
