# VORTEX PLAYER V45

- **Version:** `2.1.0+34`
- **Android application ID:** `com.vortex.player`
- **Android namespace:** `com.neonpixel.app`
- **Target:** Android / OnePlus Nord 5

## V42 update

- Rebuilt the visual identity with a new electric-purple / cyan V-play vector logo.
- The new logo is shared by the launcher icon, splash screen and Home header.
- Added a softer orbit animation and matching splash wordmark.
- Simplified Home navigation into **Folders**, **Favourites** and **Settings**.
- Updated shared colours and surfaces across the library, settings, subtitles and player.
- Preserved existing folders, favourites, search, grid/list, playback controls, subtitle tracks and size adjustment, external subtitle loading, and other player features.
- When a user taps an unfinished video, playback starts immediately from the saved position. A compact one-line “Want to start from the beginning?” hint appears briefly at the bottom with a one-tap restart action; there is no blocking dialog.

## GitHub build

Upload this source ZIP to the repository root using the workflow's expected filename `neon_pixel_ready_for_build.zip`, replacing the previous source ZIP. Keep the repository's existing `.github/workflows` folder and workflow file unchanged. The archive has root-level `android/`, `lib/`, and `pubspec.yaml` folders/files, and `android/gradlew` is executable.

## Upgrade safety

The Android `applicationId` is unchanged and the build number is incremented. **The APK must also be signed with the same release keystore / signing certificate as the installed VORTEX PLAYER** for an in-place update. The signing-key cache issue noted in earlier builds remains something to verify in GitHub Actions. Do not uninstall the installed app just to work around a signature conflict.

## Validation limits

ZIP integrity, YAML parsing, Android XML parsing and source-structure checks passed. Flutter and Dart SDKs were not available in this environment, so `flutter analyze`, APK compilation, signing compatibility and OnePlus Nord 5 runtime behavior have not been verified here.


## V43 playback behavior
Videos resume immediately from the last saved position. A compact one-line English “Want to start from the beginning?” hint appears briefly at the bottom, with a one-tap “Start over” action. There is no blocking resume dialog.


## V44 – English-only UI

- All remaining Gujarati player labels and error messages were translated into English.
- Restart hint: “Want to start from the beginning?”
- Restart action: “Start over”.
- Version: `2.0.26+33`; Android applicationId remains `com.vortex.player`.


## V45 – Fixes, faster playback start, and new player tools

- **Fixes:** playback speed menu and hold-for-2× gesture, lock-mode Back button, rotate button, Home Back-button order, refresh without a full-screen spinner (also on returning to the app), parallel library loading, sharper thumbnails, lighter progress saving, “Preparing” banner for Open-with videos, and a fuller Open-with player page (speed, audio tracks, auto-hiding controls, Back button).
- **Faster start:** videos play directly from shared storage when possible instead of being copied into the app cache first (automatic fallback to the old method); stale cache files are cleaned up in the background.
- **New:** subtitle delay, audio delay, Save screenshot (Pictures/VORTEX), six library sort orders, Format/Folder in video details, English language names for audio/subtitle tracks, tap-to-skip intro.
- Whole app remains English-only.
- Version: `2.1.0+34`; Android applicationId remains `com.vortex.player`.
- Full details: `V45_CHANGES.md`.
