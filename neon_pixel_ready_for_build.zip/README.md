# VORTEX PLAYER

Premium local video player for Android.

Version: 2.0.9+16
Application ID: `com.vortex.player`

V27 updates: edge-to-edge landscape video layout for display cutouts, a back arrow before the enlarged title, and a redesigned animated V-ribbon play logo shared by the home header, launch animation and Android launcher icon.
