# VORTEX PLAYER

VORTEX PLAYER is a Flutter-based local Android video player.

## V21 changes
- Removed the large home hero/statistics panel and count labels.
- Replaced the continue-watching banner with a compact round resume button.
- Shows saved playback progress on each video card/list row.
- Prompts to continue from the saved position or restart from the beginning when opening an unfinished video.
- Made player controls fully transparent over the video; only the seek/time row and controls remain visible.
- Uses device orientation automatically in portrait and landscape; removed the manual rotate/fullscreen toggle.
- Removed Automatic audio/subtitle track entries.
- Improved volume/brightness swipe HUD with a visible percentage and level bar.
- Changed the overall palette to graphite, amber and coral.

## Build
The project uses Flutter, media_kit, photo_manager, shared_preferences and other dependencies listed in `pubspec.yaml`. Build an Android release APK with:

```bash
flutter pub get
flutter build apk --release --no-tree-shake-icons
```

The Android application ID is `com.vortex.player`.
