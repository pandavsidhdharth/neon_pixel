# NEON PIXEL — Personal Photo & Video Gallery

A premium dark-themed local photo and video gallery for Android, built with Flutter.

## Gallery features
- Browse photos and videos stored on the phone
- Albums include photos and videos
- Persistent favorites saved locally on the device
- Full-screen photo viewer with swipe navigation and pinch-to-zoom
- Search media by filename/title
- Grid and list layouts, with 2/3/4-column grid choices
- Newest-first and oldest-first sorting
- Multi-select, select all, bulk favorite and share
- Media details: creation date, resolution, file size and duration
- Pull-to-refresh and permission recovery

## Video player features
- Explicit full-volume initialization for local videos
- Play and pause, 10-second rewind and forward
- Scrubbable timeline with elapsed and total time
- Volume slider and mute/unmute control
- Playback speeds: 0.5×, 0.75×, 1×, 1.25×, 1.5× and 2×
- Landscape immersive full-screen mode
- Favorite, share, media details and retry on playback error

## Build
1. Install Flutter SDK and Android Studio.
2. Run `flutter pub get`.
3. Run `flutter build apk --release --no-tree-shake-icons`.

The GitHub Actions workflow in `.github/workflows/build-apk.yml` can build the release APK.


## NEON PIXEL 1.3.0 updates
- Video controls auto-hide after 3 seconds while playing and return on a tap.
- Controls remain visible while paused and while the controls are being touched.
- Added an option to open the current video in another installed player for codec/audio compatibility testing.
- Corrected the two Flutter color type compile errors in the video player.


## NEON PIXEL 1.4.0 – EAC3-capable playback engine

Video playback now uses `media_kit` with its bundled native video/audio libraries instead of Android's platform-only `video_player` decoder path. The media_kit supported-format list includes E-AC-3 (`eac3`), so the player can software-decode EAC3 tracks on supported builds/devices. Device testing is still required for the user's specific file, track layout, and output route.

The app uses the media_kit, media_kit_video, and media_kit_libs_video packages. See their package notices and the bundled native-library license notices before redistribution.

## Android build note

The project pins `package_info_plus` to 8.3.1. The Android root Gradle script also patches the `wakelock_plus` 1.4.0 SDK placeholders before that plugin is evaluated, using compileSdk 36 and minSdk 21.
