# VORTEX PLAYER

A premium, video-only Android player built with Flutter and media_kit.

## Features
- Local video library with lazy-built thumbnail grid and list view
- Search, newest/oldest sorting, and persistent video favourites
- Full-screen landscape playback with auto-hiding controls
- Play/pause, seek timeline, 10-second rewind/forward, mute and volume
- Playback speed presets, including 2×
- Left-side vertical swipe for screen brightness
- Right-side vertical swipe for volume
- Press-and-hold on the right side for temporary 2× playback
- Audio track/language selection and embedded subtitle selection
- Optional software volume boost (up to 200%; may distort audio)
- Bundled libmpv/FFmpeg playback engine for broad format support, including E-AC-3 where supported
- Share video, open in another installed player, and view video details

## Build
The GitHub Actions workflow in `.github/workflows/build-apk.yml` builds the release APK with Flutter 3.38.10 and Android NDK 27.

Run locally with Flutter installed:
1. `flutter pub get`
2. `flutter build apk --release --no-tree-shake-icons`

The package id remains `com.neonpixel.app` so a new VORTEX PLAYER build can update the existing installed app rather than appearing as a separate app.
