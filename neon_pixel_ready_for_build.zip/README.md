# VORTEX PLAYER V34

- **Version:** `2.0.16+23`
- **Android application ID:** `com.vortex.player`
- **Target:** Android / OnePlus Nord 5

## V34 updates

- Requests Android audio focus before playback and pauses playback when audio focus is lost, so music from another app should stop/duck rather than overlap where the other app respects Android audio focus. Focus is released on pause, completion, app backgrounding, and player disposal.
- Removes per-item video/folder delete controls. Long-press to select items, tap more items, use Select All, then Delete Selected with a confirmation dialog. Selecting a folder and deleting it removes the videos contained in that album; Android may show its own permission/confirmation UI.
- Resume prompt shows the saved timestamp, has Continue, START OVER, and X actions, and automatically continues from the saved timestamp after 7 seconds if left untouched. X dismisses the prompt and cancels opening that video.
- Continue resumes after the media duration becomes available and the player seeks to the saved position; completed videos are not treated as partially watched.
- Audio settings include audio-track selection and a 0–200% volume/boost control. Subtitle settings include embedded/external subtitle selection, subtitle size, and vertical position; dragging in the lower-center subtitle zone adjusts position.
- Long-press playback starts at 2×. Drag upward/downward in 0.5× steps to adjust from 1× to 4×; release returns to 1×. A translucent top speed indicator appears briefly when speed changes.
- Horizontal swipes seek using a saved setting of 5, 10, 15, 20, 30, 45, or 60 seconds. The seek HUD uses a translucent animated crimson treatment.
- Retains the V32 cinematic launch animation: 3.35-second crimson/amber launch sequence, 58 ember particles, converging light beams, orbital rings, logo reveal, letter-by-letter wordmark, and smooth transition into the library.
- Retains portrait-safe video fit, grid/list preferences, folder-first library, favourites, search, bookmarks, sleep timer, external Open With playback, and Repeat in the More menu.

## Build and safety notes

- Android application ID remains `com.vortex.player`.
- Upload this ZIP as `neon_pixel_ready_for_build.zip` in the repository root and run the existing root GitHub Actions workflow. The workflow stored in the repository root is separate from this project ZIP; this package does not replace it.
- Flutter/Dart SDK is not available in the current build environment. This source has **not** been compiled into an APK or tested on a physical device here.
- GitHub Actions signing-key cache has previously reported a cache miss and a missing keystore path. Signing continuity is **not** fixed by this source archive. A new APK may conflict with an already installed package until a stable signing key is configured. Do not uninstall or install over an existing app until a successful build and signing compatibility are confirmed.


## V35 Subtitle controls fix

- Subtitle size and vertical placement are now applied through media_kit_video `SubtitleViewConfiguration` (Flutter subtitle overlay), rather than MPV `sub-scale` / `sub-pos` properties.
- Added an always-visible tune/settings button to the Home header and a dedicated tune button beside SUB in the player toolbar.
- Added the same subtitle defaults panel for external playback.
- Subtitle drag remains enabled in the center area; left and right screen edges remain available for brightness and volume gestures.

Build verification: source-level/static checks only. Flutter SDK was not available in the authoring environment, so no APK compilation or device runtime test is claimed.
