# VORTEX PLAYER V28

Version: 2.0.10+17
Android package: com.vortex.player

## V28 changes
- Hold anywhere on the video surface for temporary 2.0x playback. The speed indicator is shown at the very top and the saved playback rate is restored on release.
- Vertical swipe from the left half controls brightness; vertical swipe from the right half controls system volume / player boost.
- Both sides show slim vertical level rails while adjusting; the active side is highlighted and the other remains dimmed.
- Added subtle haptic feedback for gesture start/end.
- Retains V27 features and the existing package ID for same-app updates.

Build with the repository root GitHub Actions workflow. The ZIP's embedded workflow is not a replacement for the repository workflow.
