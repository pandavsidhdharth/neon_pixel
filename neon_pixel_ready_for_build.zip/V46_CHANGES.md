# VORTEX PLAYER V46 – Notification playback fix and Picture-in-Picture

## Playback interruption fix

- Changed the Android audio-focus request to `willPauseWhenDucked(false)`. Duckable interruptions such as brief notification sounds are no longer treated as a reason to pause the video; Android may briefly lower media volume instead.
- Permanent and transient audio-focus losses still pause playback and save progress, which is appropriate for calls and stronger audio interruptions.
- Removed pausing on Flutter `inactive` lifecycle events in both the main player and Android “Open with” player. Notification shade and temporary overlay transitions do not by themselves pause playback.
- Actual app backgrounding still pauses playback and saves resume progress, unless PiP is active/being entered.

## Picture-in-Picture

- Added Android Picture-in-Picture manifest support and a native method channel.
- Added a PiP button in both the library player and Android “Open with” player.
- Added automatic PiP when the user leaves the app while video is playing on supported Android versions. Android 12+ uses `setAutoEnterEnabled`; Android 8–11 enter PiP from `onUserLeaveHint`. The player defers background pausing only while the OS decides whether auto-PiP can enter, and returns to normal background pause behavior if PiP is denied.
- Player touch controls are hidden in the compact PiP view and restored when returning to the full player.

## Version / upgrade safety

- Flutter version: `2.2.0+35`.
- Android application ID remains `com.vortex.player`; namespace remains `com.neonpixel.app`.
- The app must be signed with the same signing key as the currently installed version for an in-place update. Do not uninstall the working app to bypass a signature mismatch.

## Validation limits

- Source-level checks and Android XML parsing should be run before build.
- Flutter/Dart SDK is not available in this environment, and no OnePlus Nord 5 device is attached; therefore APK compilation, actual notification interruption behaviour, PiP transitions and media rendering inside PiP remain unverified on-device.
