# V44 – English-only UI text

- Kept the entire app UI in English; replaced the remaining Gujarati player strings.
- The playback restart hint now reads: “Want to start from the beginning?”
- The action button now reads: “Start over”.
- Translated player error messages to English.
- Playback behavior is unchanged: unfinished videos start immediately from the saved position; the one-line restart hint remains non-blocking and auto-hides.
- Android applicationId remains `com.vortex.player`.
- Version updated to `2.0.26+33`.

## Validation

Source-level scan found no Gujarati Unicode characters in Dart UI files. Flutter/Dart SDK compilation and device testing were not available in this environment.
