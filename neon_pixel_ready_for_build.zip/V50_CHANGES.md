# VORTEX PLAYER V50

## Changes

1. Auto-play next video: the in-app Library/Folder/Playing Queue advances to the next item automatically when a video completes. Repeat One restarts the same item; Repeat All wraps to the first queue item. Repeat Off stops at the end of the queue.
2. Completion reliability: completion stream events and a lightweight 450 ms state watchdog converge through a one-shot guard, preventing duplicate queue advances while providing a fallback if a decoder misses the completion event.
3. Water-aqua controls: playback icons, Play/Pause, Previous/Next, speed, timeline, brightness/volume rails and top actions use aqua/cyan accents. Button fills and glass panels are reduced to low-opacity aqua so the video remains clearly visible beneath them.
4. External-file player receives the same transparent aqua styling.
5. Version bumped to 2.4.1+39. Android applicationId remains `com.vortex.player`; signing configuration is unchanged.

## Test notes

- ZIP integrity, YAML parsing, Android manifest XML parsing, App ID/version checks and source delimiter checks were run.
- Flutter/Dart SDK is not installed in this environment, so `flutter analyze`, APK build and device playback tests could not be run here.
- Automatic next-video applies to videos opened from the app's Library/Folder/Playing Queue. A single file launched externally has no queue context to advance through.
- For in-place update, V49 and V50 APKs must be signed with the same release keystore/certificate. The source archive does not include private signing keys.
