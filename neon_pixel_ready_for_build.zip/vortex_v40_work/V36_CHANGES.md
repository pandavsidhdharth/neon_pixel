# VORTEX PLAYER V36 — Subtitle & Interface Refinement

- Removed the center-screen vertical drag interaction for subtitle position. Vertical video gestures now control only brightness on the left half and volume on the right half.
- Subtitle vertical placement is controlled exclusively by the Settings page slider or the live Subtitle Settings panel.
- Added a dedicated Settings page with subtitle size, vertical position, live preview, reset action, horizontal seek interval, and library grid/list and sort preferences. Values are stored in SharedPreferences.
- Reworked the app-wide theme to a midnight navy / crimson / ice-blue palette, redesigned the Home header and action buttons, refreshed collection headings, and polished video and continue-watching cards.
- Subtitle font styling and position are sent to `media_kit_video` through `SubtitleViewConfiguration` (`style` and `padding`), which are the renderer's documented subtitle customization fields.

## Verification

- ZIP integrity, YAML parsing, Android XML parsing, source delimiter checks, and stale subtitle-drag references were checked.
- Flutter/Dart SDK is not installed in this authoring environment, so `flutter analyze`, APK compilation, and OnePlus runtime behavior are not verified.
