# VORTEX PLAYER V40 — Subtitle controls

- Subtitle control is now icon-only, visually matching the audio-track control; the `SUB` text label is removed.
- Subtitle sheet lists selectable embedded subtitle tracks first, with the active track marked. `Off` is available immediately after the track list.
- Text size has working smaller/larger step buttons and a slider. Each change immediately updates the player subtitle overlay and is saved to preferences.
- Vertical position has working up/down step buttons and a slider. Each change immediately updates the player subtitle overlay and is saved to preferences.
- Subtitle values are updated in the sheet and in the player state during interaction, rather than waiting until the sheet is closed.
- Existing external subtitle loading remains available after the controls.
- No Hidden Videos, hide/unhide, or home-screen changes are included in this version.

Build version: 2.0.22+29
Android application ID: com.vortex.player

Build/test note: Flutter/Dart SDK is not installed in this environment, so `flutter analyze`, APK compilation, and device playback testing could not be run. Verify on the OnePlus Nord 5 that the selected track, size buttons/slider, and up/down position buttons/slider update the visible subtitle overlay. Do not uninstall the existing app. An update APK must use the same signing key as the installed APK.
