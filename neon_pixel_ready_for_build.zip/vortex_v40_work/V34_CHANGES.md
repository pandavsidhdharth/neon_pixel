# V34 changes

## Audio focus
- Added Android AudioManager audio-focus channel.
- Requests media focus before playback; pauses the player on permanent/transient loss and duck requests.
- Releases focus on pause, lifecycle backgrounding, completion, disposal, and activity destruction.

## Library and deletion
- Removed individual delete affordances from video and folder rows/cards.
- Added multi-select for videos and albums/folders using long-press and tap.
- Added select-all, cancel-selection, and delete-selected controls with explicit confirmation.
- Deleting selected folders deletes the videos contained in those albums and cleans saved resume, favourites, and recent-history metadata.

## Resume prompt
- Added Continue, START OVER, and X controls.
- Shows the saved playback timestamp.
- Auto-continues from saved position after seven seconds if not touched.
- Dismiss (X) cancels opening that video.
- Existing playback initialization waits for duration and seeks to the saved position before playback.

## Player controls
- Long-press starts temporary 2×; vertical drag adjusts 1×–4× in 0.5× steps; release resets to 1×.
- Top speed indicator is translucent, animated, and only flashes briefly when changed.
- Horizontal swipe seek interval is configurable from 5 to 60 seconds.
- Audio panel contains track selection and volume/boost slider.
- Subtitle panel contains track/external file selection, font scale and position controls; lower-center vertical drag changes subtitle placement.
- Repeat remains in More menu, not the bottom row.

## Animation and identity
- Retains cinematic crimson/amber splash, particles, light beams, orbital rings, logo pulse and letter reveal.
- Android application ID remains `com.vortex.player`.
- App version: `2.0.16+23`.

## Verification limitations
- ZIP integrity, YAML parsing, Android XML parsing, and required-source checks are run before delivery.
- Flutter/Dart SDK is unavailable here; no Flutter compile, emulator test, or OnePlus runtime test has been performed.
- Signing key continuity remains unresolved: the current GitHub cache workflow had a cache miss and did not find a saved `~/.android/debug.keystore`.
