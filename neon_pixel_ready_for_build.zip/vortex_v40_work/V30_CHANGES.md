# VORTEX PLAYER V30 changes

- Right-side vertical swipe adjusts volume; left-side vertical swipe adjusts brightness. The active on-screen indicator is translucent and appears only on the side being adjusted.
- Press and hold the video to show a translucent `2×` indicator and temporarily play at 2×. Releasing restores the selected playback speed (1× by default) and briefly shows that speed.
- Removed the Repeat control from the bottom control row. Repeat Off / One / All remains available in the top-right More menu.
- Resume prompt now appears as a bottom translucent banner: tap “Continue from where you stopped.” to resume, or tap “START OVER” to restart.
- Completed videos are excluded from Continue Watching.
- Added confirmed delete actions for an individual video and for all videos in a folder.
- Deleting a folder removes its videos from the media library; on Android 11+, Android moves them to Trash. Empty directory cleanup is controlled by Android/media storage.

Version: 2.0.12+19
