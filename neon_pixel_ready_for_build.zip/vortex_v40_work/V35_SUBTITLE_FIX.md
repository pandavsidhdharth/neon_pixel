# VORTEX PLAYER V35 — Subtitle controls fix

- Fixed subtitle styling/position routing: the app uses `media_kit_video`'s Flutter `SubtitleViewConfiguration` to apply font size, text style and padding. Earlier MPV `sub-scale` / `sub-pos` options did not control this overlay.
- Added a visible tune/settings button in the Home header.
- Added a dedicated tune button next to the SUB button in the video player's top bar.
- Kept subtitle ON/OFF, font-size slider, vertical-position slider, drag-to-move toggle and external subtitle loading in the player settings sheet.
- External/Open With playback has its own subtitle size/position settings button and uses the same stored preferences.
- Subtitle drag is assigned to the center area of the video; left/right edges remain for brightness and volume.

## Verification

- Checked project ZIP integrity.
- Parsed `pubspec.yaml`.
- Parsed Android manifest and resource XML files.
- Confirmed every in-app `Video` construction supplies the subtitle view configuration.
- Flutter/Dart SDK was not available here; APK compilation and OnePlus device runtime testing remain unverified.
