# VORTEX PLAYER V37 — Home controls cleanup

- Removed the three-dot overflow button from the Home header.
- Replaced the bulk-delete `delete_sweep` icon (trash with trailing lines) with a plain outlined trash icon.
- Kept multi-select, Select All/Clear Selection, delete confirmation, and cancel selection behavior unchanged.
- Moved the former overflow actions into the Settings page: refresh video library and About VORTEX PLAYER.
- Kept Grid/List and Newest/Oldest controls in the Settings page.
- Bumped app version to 2.0.19+26.

## Verification

- Source checks confirm no `PopupMenuButton`, `more_vert_rounded`, or `delete_sweep_rounded` remains in `home_screen.dart`.
- YAML and Android XML parsing and ZIP integrity are checked.
- Flutter/Dart SDK is not available in this environment, so analyzer/build/device testing is not performed.
