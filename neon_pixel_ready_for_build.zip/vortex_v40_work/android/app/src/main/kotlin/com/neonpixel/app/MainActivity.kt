package com.neonpixel.app

import android.content.Intent
import android.database.Cursor
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : FlutterActivity() {
    private val brightnessChannelName = "vortex_player/brightness"
    private val systemVolumeChannelName = "vortex_player/system_volume"
    private val filesChannelName = "vortex_player/files"
    private val externalChannelName = "vortex_player/external"
    private val audioFocusChannelName = "vortex_player/audio_focus"
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private var pendingExternalVideo: Map<String, String>? = null
    private var externalChannel: MethodChannel? = null
    private var audioFocusChannel: MethodChannel? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS ||
            change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT ||
            change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            mainHandler.post { audioFocusChannel?.invokeMethod("focusLost", null) }
        }
    }
    private var pendingSubtitleResult: MethodChannel.Result? = null
    private val subtitleRequestCode = 48210

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Remove abandoned Open-with copies left by a previous process.
        cacheDir.listFiles()?.filter { it.isFile && it.name.startsWith("video_") }?.forEach { it.delete() }
        // Allow landscape video to draw into the display-cutout side inset.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val params = window.attributes
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = params
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, brightnessChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getSystemBrightness" -> {
                        val windowBrightness = window.attributes.screenBrightness
                        val brightness = if (windowBrightness >= 0f) windowBrightness else {
                            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
                        }
                        result.success(brightness.toDouble())
                    }
                    "setBrightness" -> {
                        val value = call.argument<Double>("value")
                        if (value == null) result.error("INVALID_ARGUMENT", "Brightness value is required", null)
                        else {
                            val params = window.attributes
                            params.screenBrightness = value.toFloat().coerceIn(0.05f, 1.0f)
                            window.attributes = params
                            result.success(true)
                        }
                    }
                    "resetBrightness" -> {
                        val params = window.attributes
                        params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                        window.attributes = params
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }

        audioFocusChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, audioFocusChannelName)
        audioFocusChannel?.setMethodCallHandler { call, result ->
            val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
            when (call.method) {
                "request" -> {
                    val focusResult = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                                    .build()
                            )
                            .setOnAudioFocusChangeListener(audioFocusListener, mainHandler)
                            .setAcceptsDelayedFocusGain(false)
                            .setWillPauseWhenDucked(true)
                            .build()
                        audioFocusRequest = request
                        audioManager.requestAudioFocus(request)
                    } else {
                        @Suppress("DEPRECATION")
                        audioManager.requestAudioFocus(
                            audioFocusListener,
                            AudioManager.STREAM_MUSIC,
                            AudioManager.AUDIOFOCUS_GAIN
                        )
                    }
                    result.success(focusResult == AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
                }
                "abandon" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                        audioFocusRequest = null
                    } else {
                        @Suppress("DEPRECATION")
                        audioManager.abandonAudioFocus(audioFocusListener)
                    }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, systemVolumeChannelName)
            .setMethodCallHandler { call, result ->
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                val stream = AudioManager.STREAM_MUSIC
                val max = audio.getStreamMaxVolume(stream).coerceAtLeast(1)
                when (call.method) {
                    "getSystemVolume" -> result.success(audio.getStreamVolume(stream).toDouble() / max.toDouble())
                    "setSystemVolume" -> {
                        val value = call.argument<Double>("value")
                        if (value == null) result.error("INVALID_ARGUMENT", "Volume value is required", null)
                        else {
                            val target = (value.coerceIn(0.0, 1.0) * max).roundToInt().coerceIn(0, max)
                            audio.setStreamVolume(stream, target, 0)
                            result.success(audio.getStreamVolume(stream).toDouble() / max.toDouble())
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, filesChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "pickSubtitleFile" -> {
                        if (pendingSubtitleResult != null) {
                            result.error("PICKER_BUSY", "A subtitle picker is already open", null)
                        } else {
                            pendingSubtitleResult = result
                            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "*/*"
                                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/x-subrip", "text/vtt", "text/plain"))
                            }
                            try {
                                startActivityForResult(intent, subtitleRequestCode)
                            } catch (error: Exception) {
                                pendingSubtitleResult = null
                                result.error("PICKER_FAILED", error.message, null)
                            }
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        externalChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, externalChannelName)
        externalChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "consumePendingExternalVideo" -> {
                    result.success(pendingExternalVideo)
                    pendingExternalVideo = null
                }
                "deleteExternalCacheFile" -> {
                    val path = call.argument<String>("path")
                    if (path != null) {
                        val file = File(path)
                        if (file.parentFile?.canonicalPath == cacheDir.canonicalPath && file.name.startsWith("video_")) file.delete()
                    }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
        handleIncomingVideoIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingVideoIntent(intent)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == subtitleRequestCode) {
            val result = pendingSubtitleResult
            pendingSubtitleResult = null
            val uri = if (resultCode == RESULT_OK) data?.data else null
            if (uri == null) {
                result?.success(null)
            } else if (queryDisplayName(uri)?.substringAfterLast('.', "")?.lowercase() !in setOf("srt", "vtt")) {
                result?.error("UNSUPPORTED_SUBTITLE", "Choose an .srt or .vtt subtitle file", null)
            } else {
                ioExecutor.execute {
                    val file = try { copyUriToCache(uri, "subtitle") } catch (_: Exception) { null }
                    mainHandler.post {
                        if (file != null) result?.success(file.absolutePath)
                        else result?.error("SUBTITLE_COPY_FAILED", "Could not read the selected subtitle file", null)
                    }
                }
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun handleIncomingVideoIntent(incoming: Intent?) {
        if (incoming == null) return
        val uri: Uri? = when (incoming.action) {
            Intent.ACTION_VIEW -> incoming.data
            Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                if (android.os.Build.VERSION.SDK_INT >= 33) incoming.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else incoming.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                @Suppress("DEPRECATION")
                val streams = if (android.os.Build.VERSION.SDK_INT >= 33)
                    incoming.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else incoming.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                streams?.firstOrNull()
            }
            else -> null
        }
        if (uri == null) return
        val mime = incoming.type ?: contentResolver.getType(uri).orEmpty()
        val name = queryDisplayName(uri).orEmpty()
        val extension = name.substringAfterLast('.', "").lowercase()
        val isVideo = mime.startsWith("video/") || extension in setOf("mp4", "mkv", "avi", "mov", "m4v", "webm", "3gp", "ts", "mpeg", "mpg")
        if (!isVideo) return
        ioExecutor.execute {
            val file = try { copyUriToCache(uri, "video") } catch (_: Exception) { null }
            if (file != null) {
                val payload = mapOf("path" to file.absolutePath, "title" to (queryDisplayName(uri) ?: file.name))
                mainHandler.post {
                    pendingExternalVideo = payload
                    externalChannel?.invokeMethod("externalVideoAvailable", null)
                }
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) cursor.getString(0) else uri.lastPathSegment
        } catch (_: Exception) {
            uri.lastPathSegment
        } finally {
            cursor?.close()
        }
    }

    private fun copyUriToCache(uri: Uri, prefix: String): File {
        val originalName = queryDisplayName(uri) ?: "$prefix.bin"
        val safeName = originalName.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(100)
        val destination = File(cacheDir, "${prefix}_${System.currentTimeMillis()}_$safeName")
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Unable to open shared file")
        input.use { source -> destination.outputStream().use { output -> source.copyTo(output) } }
        return destination
    }

    override fun onDestroy() {
        pendingSubtitleResult?.let { it.error("ACTIVITY_DESTROYED", "Activity closed", null) }
        pendingSubtitleResult = null
        try {
            val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
                audioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(audioFocusListener)
            }
        } catch (_: Exception) { }
        ioExecutor.shutdown()
        super.onDestroy()
    }
}
