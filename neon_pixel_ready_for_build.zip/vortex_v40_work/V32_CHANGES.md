# VORTEX PLAYER V32

Version: `2.0.14+21`

## Cinematic launch animation
- Extended the launch sequence to a cinematic 3.35-second intro with a longer cross-fade into the library.
- Added rotating energy rings, edge-to-core crimson/amber light beams, 58 drifting ember particles, subtle scan lines and a lower-screen glow.
- Enlarged the Vortex logo reveal and added a pulse/glow treatment.
- Reveals the VORTEX PLAYER wordmark letter-by-letter, then the cinematic playback tagline and animated launch progress/status.
- Animation effects are painted inside a RepaintBoundary and stop when the launch overlay is removed.

## Included V31 player and library improvements
- Temporary hold-to-boost starts at 2x; vertical finger movement adjusts 1x–4x in 0.5x increments; releasing restores the saved normal speed.
- Configurable horizontal swipe seek interval (5/10/15/20/30/45/60 seconds) with a translucent animated HUD.
- Left/right vertical swipe controls brightness/volume with translucent side rails.
- Subtitle size and vertical position controls, including drag repositioning over the subtitle zone.
- Multi-select video deletion, Select All, single-video delete and folder-video delete with confirmation.
- Continue Watching excludes completed videos; resume and start-over prompt remains.
- Repeat control remains in the More menu, not in the bottom control row.
- V31 also includes portrait-safe contain fit, landscape fit behavior, track selection, external subtitle selection, resume progress and folder-first library features.

## Verification
- ZIP integrity and source files checked.
- YAML and Android XML can be checked separately.
- Flutter/Dart SDK is not available in this environment; no APK compile or phone runtime test has been performed. Please run the supplied project through the repository's GitHub Actions build before installation.
