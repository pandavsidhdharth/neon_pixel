import 'dart:math' as math;
import 'package:flutter/material.dart';

/// VORTEX's current mark: two ember ribbons form a dynamic V around a play core.
/// The same painter is used by the app header and the animated launch screen.
class VortexLogoMark extends StatelessWidget {
  final double size;
  final double progress;
  const VortexLogoMark({required this.size, this.progress = 1});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: size,
    height: size,
    child: CustomPaint(
      painter: VortexLogoPainter(progress.clamp(0.0, 1.0).toDouble()),
    ),
  );
}

class VortexLogoPainter extends CustomPainter {
  final double progress;
  const VortexLogoPainter(this.progress);

  double _ease(double value) => Curves.easeOutCubic.transform(value.clamp(0.0, 1.0).toDouble());

  void _drawProgressPath(Canvas canvas, Path path, Paint paint, double value) {
    if (value <= 0) return;
    for (final metric in path.computeMetrics()) {
      canvas.drawPath(metric.extractPath(0.0, metric.length * value.clamp(0.0, 1.0).toDouble()), paint);
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    final u = size.shortestSide;
    final c = Offset(size.width / 2, size.height / 2);
    final p = progress.clamp(0.0, 1.0).toDouble();

    // A sculpted, softly-rounded crimson tile replaces the old ring/play badge.
    final tile = Rect.fromCenter(center: c, width: u * .88, height: u * .88);
    final tileShape = RRect.fromRectAndRadius(tile, Radius.circular(u * .245));
    // The mark starts as a fine outline; its crimson glass tile fills only
    // after the two side streams begin converging into the V emblem.
    final tileFill = _ease((p - .16) / .34);
    if (tileFill > 0) {
      canvas.drawRRect(
        tileShape,
        Paint()
          ..color = Colors.white.withValues(alpha: tileFill)
          ..shader = const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF3A0A1D), Color(0xFF8E1838), Color(0xFF34101B)],
          ).createShader(tile),
      );
    }
    canvas.drawRRect(
      tileShape,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = u * .016
        ..color = const Color(0xFFFFA078).withValues(alpha: .18 + .62 * p),
    );

    // Side light streams rush inward, then disappear as the emblem is assembled.
    final beamProgress = _ease(p / .42);
    final beamFade = (1 - _ease((p - .22) / .30)).clamp(0.0, 1.0).toDouble();
    if (beamFade > 0) {
      final leftStart = Offset(-u * .38, c.dy - u * .20);
      final rightStart = Offset(size.width + u * .38, c.dy + u * .20);
      final leftEnd = Offset.lerp(leftStart, Offset(c.dx - u * .19, c.dy - u * .02), beamProgress)!;
      final rightEnd = Offset.lerp(rightStart, Offset(c.dx + u * .19, c.dy + u * .02), beamProgress)!;
      final leftPath = Path()..moveTo(leftStart.dx, leftStart.dy)..quadraticBezierTo(c.dx - u * .26, c.dy - u * .36, leftEnd.dx, leftEnd.dy);
      final rightPath = Path()..moveTo(rightStart.dx, rightStart.dy)..quadraticBezierTo(c.dx + u * .26, c.dy + u * .36, rightEnd.dx, rightEnd.dy);
      final leftPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = u * .035
        ..color = const Color(0xFFFF607A).withValues(alpha: beamFade)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, u * .025);
      final rightPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = u * .035
        ..color = const Color(0xFFFFB07A).withValues(alpha: beamFade)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, u * .025);
      canvas.drawPath(leftPath, leftPaint);
      canvas.drawPath(rightPath, rightPaint);
      canvas.drawCircle(leftEnd, u * .035, Paint()..color = const Color(0xFFFF7187).withValues(alpha: beamFade));
      canvas.drawCircle(rightEnd, u * .035, Paint()..color = const Color(0xFFFFB17B).withValues(alpha: beamFade));
    }

    final assemble = _ease((p - .12) / .78);
    final leftRibbon = Path()
      ..moveTo(c.dx - u * .29, c.dy - u * .22)
      ..cubicTo(c.dx - u * .28, c.dy - u * .02, c.dx - u * .12, c.dy + u * .22, c.dx, c.dy + u * .30);
    final rightRibbon = Path()
      ..moveTo(c.dx + u * .29, c.dy - u * .22)
      ..cubicTo(c.dx + u * .28, c.dy - u * .02, c.dx + u * .12, c.dy + u * .22, c.dx, c.dy + u * .30);
    final upperSweep = Path()
      ..moveTo(c.dx - u * .25, c.dy - u * .17)
      ..cubicTo(c.dx - u * .13, c.dy - u * .38, c.dx + u * .14, c.dy - u * .37, c.dx + u * .25, c.dy - u * .13);

    final leftGlow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = u * .115
      ..color = const Color(0xFFFF456A).withValues(alpha: .30 * assemble)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, u * .085);
    final rightGlow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = u * .115
      ..color = const Color(0xFFFFA16C).withValues(alpha: .28 * assemble)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, u * .085);
    _drawProgressPath(canvas, leftRibbon, leftGlow, assemble);
    _drawProgressPath(canvas, rightRibbon, rightGlow, assemble);

    final leftPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = u * .082
      ..shader = const LinearGradient(colors: [Color(0xFFFF7890), Color(0xFFCF244F)]).createShader(tile);
    final rightPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = u * .082
      ..shader = const LinearGradient(colors: [Color(0xFFFFC08A), Color(0xFFFF6D6E)]).createShader(tile);
    _drawProgressPath(canvas, leftRibbon, leftPaint, assemble);
    _drawProgressPath(canvas, rightRibbon, rightPaint, assemble);

    final sweepProgress = _ease((p - .34) / .52);
    final sweepPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = u * .045
      ..shader = const LinearGradient(colors: [Color(0xFFFFA16C), Color(0xFFFF6B87)]).createShader(tile);
    _drawProgressPath(canvas, upperSweep, sweepPaint, sweepProgress);

    // Central play core is revealed last, after the two ribbons meet.
    final playReveal = _ease((p - .68) / .32);
    if (playReveal > 0) {
      final play = Path()
        ..moveTo(c.dx - u * .045, c.dy - u * .105)
        ..quadraticBezierTo(c.dx - u * .055, c.dy - u * .135, c.dx - u * .015, c.dy - u * .112)
        ..lineTo(c.dx + u * .145, c.dy - u * .012)
        ..quadraticBezierTo(c.dx + u * .19, c.dy + u * .012, c.dx + u * .145, c.dy + u * .042)
        ..lineTo(c.dx - u * .02, c.dy + u * .13)
        ..quadraticBezierTo(c.dx - u * .06, c.dy + u * .15, c.dx - u * .055, c.dy + u * .105)
        ..close();
      canvas.drawPath(play, Paint()..color = const Color(0xFFFFF4F0).withValues(alpha: playReveal));
    }

    // Tiny ember sparks orbit the completed V without enclosing it in a circle.
    final sparks = _ease((p - .78) / .22);
    for (var i = 0; i < 3; i++) {
      final angle = (-math.pi * .82) + i * .78;
      final point = Offset(c.dx + math.cos(angle) * u * .385, c.dy + math.sin(angle) * u * .385);
      final radius = u * (.018 + (i == 1 ? .010 : 0));
      canvas.drawCircle(point, radius, Paint()..color = const Color(0xFFFFB18A).withValues(alpha: sparks));
    }
  }

  @override
  bool shouldRepaint(covariant VortexLogoPainter oldDelegate) => oldDelegate.progress != progress;
}
