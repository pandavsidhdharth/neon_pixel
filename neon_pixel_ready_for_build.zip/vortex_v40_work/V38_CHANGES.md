# VORTEX PLAYER V38 — Subtitle controls cleanup

- Removed the duplicate tune/sliders button beside the SUB button; both previously opened the same subtitle track/settings sheet.
- Removed the duplicate Subtitle Settings entry from the three-dot More player tools menu.
- Kept the SUB button as the single direct entry point for subtitle track selection and visibility.
- Preserved subtitle size/position controls inside the subtitle sheet and global Settings.
- Kept audio settings, bookmarks, queue, repeat, sleep timer, sharing, video information, playback, and resume behavior unchanged.
- Bumped app version to 2.0.20+27.

## Verification
- Static source checks confirm the player header has one subtitle-sheet entry point and the More menu has no duplicate subtitle settings action.
- Android application ID remains `com.vortex.player`.
- Flutter/Dart SDK is not available in this environment, so `flutter analyze`, APK build, and device testing are not performed.
- Signing compatibility with the installed APK remains unverified. Do not uninstall the existing app; an update APK must use the same signing key as the installed version.
