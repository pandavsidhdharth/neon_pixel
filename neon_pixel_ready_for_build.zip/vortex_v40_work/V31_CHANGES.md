# VORTEX PLAYER V31 changes

Version: `2.0.13+20`

## Player gestures
- Long-press starts temporary playback at 2x and shows a larger translucent speed indicator near the top edge.
- While the long-press remains active, dragging upward increases speed in 0.5x steps up to 4x; dragging downward decreases it to 1x.
- Releasing restores the user's normal playback speed.
- Horizontal left/right swipe seeks by the configured interval. Longer swipes can move through multiple intervals. The translucent seek HUD is shown near the top with a larger animated indicator.
- Swipe seek interval can be selected in the home menu: 5, 10, 15, 20, 30, 45 or 60 seconds.
- Subtitle size and vertical position can be adjusted from the subtitle panel. When subtitles are active, dragging vertically over the lower-center subtitle zone moves their vertical position.

## Library selection and delete
- Long-press a video card or list row to enter multi-select mode.
- Tap more videos to add/remove them from selection; Select All and Delete Selected are available in the selection toolbar.
- Bulk deletion uses Android PhotoManager's delete request and clears resume, recent, bookmark and favourite metadata for items Android confirms as deleted.
- Existing single-video and folder delete actions remain available.

## Verification status
- ZIP archive integrity checked.
- Dart source delimiter balance checked.
- YAML and Android XML validation checked separately.
- Flutter/Dart SDK is not available in this environment, so a Flutter compile, Android APK build, device test, media-kit subtitle-property runtime test and real gallery-delete confirmation test have not been performed.
